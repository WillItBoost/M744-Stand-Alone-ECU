//#include <stdio.h>                /* standard I/O .h-file              */
#include "reg167.h"               /* special function register 80C167  */
#include "main.h"
#include "memloc.c"


/*
Injector 1 = P7.6 (active low)
Injector 2 = P7.5 (active low)
Injector 3 = P7.4 (active low) [ME744 only, hardware is still there but no flyback diode fitted on the M744 so only suitable for relay control / boost solenoid etc]
Injector 4 = P8.7 (active low) [ME744 only, hardware is still there but no flyback diode fitted on the M744 so only suitable for relay control / boost solenoid etc]

	P8 ^= 1<<7;//K15 relay
	
	P7 ^= 1<<4;//Starter Relay Control (Fan control)
	

Ignition driver 1 = P2.0
Ignition driver 2 = P2.1

P2.13 = Tacho output

Cannister Purge Valve = P7.3
Intake Manifold Flap / Wastegate Solenoid = P7.1
O2 Heater = P2.4

Crank trigger input = P3.0 (T0IN)  & P2.15 (CC15)

Engine coolant temp = P5.10 (ADC10)
Battery voltage = P5.5 (ADC5) 1 Byte [0...17V], 1Inc = 0.067V

Fuel Pump Relay 8.1

MAP = P5.0 (ADC0)
IAT = P5.4
TPS1 = P5.1
TPS2 = P5.3
coolant temp = P5.4
EGR Temp = P5.14 (ADC14)

Unpopulated Low Level driver
Pin3 = P8.3
pin4 = ASIC pin 16
Pin8 = P6.6 (fault detection serial)
Pin9 = P6.5 (fault detection serial)

pin17 = P8.6
pin18 = ASIC pin 12

P8.2 = steper motor CS

P6.4 = Black D2 (intercooler fan relay control)
P8.3 = Brown M2 (Reverse Controller) C19 used for PWM control

*/
#define FuelPumpPrimeTime 3
#define ForceRefTiming 0x02
#define ApplySTFC 0x04
#define VEAutoCorrect 0x08
#define UseAlphaN 0x10

unsigned char EngineStalled=1; //1= stalled, 0= running. Disable injectors and coils if stalled.
unsigned char EngineStalledShw=1; //Shaddow register used for one time stall code execution
unsigned char Overrun=0; //set when TPS is 0% and or Manifold vacuum is <30kpa and RPM > 2000rpm
unsigned char FanState=0;
unsigned char FuelPumpState=0;
unsigned char CrankFuelFlag=0;
unsigned long RunTimer=0;
unsigned char PrimeTimer=FuelPumpPrimeTime;

extern char SendMonitor;
extern void sendMonitorPacket();
extern char SendADC;
extern void sendADCPacket();
extern unsigned char BoostTable;
unsigned char SubLoopCnt=0;
int StepperPosition=0;
int RequestedSteps=20;
char IAChome=1; //send IAC home at startup / stall
unsigned char IAChomeCount=64;
unsigned char IAChomeCountShadow=64;

extern unsigned char reqAFR;

extern void copyFlash2RAM();
extern unsigned char TPS;
extern char CLT;
extern unsigned char AlphaN;
unsigned char CycleCounter=0;
unsigned char FloodClear=0;
void calculateTemps();
extern void calculateTPS();
char StartUpIACincrease=40;
unsigned char	CrankEnrichDecayCount=0;
unsigned char	FanCutInTemp=0;
unsigned char	FanCutOutTemp=0;
extern unsigned int ShortToothInterval;
extern void calculateSparkTiming();
char IATretardValue=0;
extern volatile unsigned int rpmScale[];
unsigned char LossOfSyncCount=0;
int systick=100;
#define T6_Interrupt 0x26 // 10mS system tick
unsigned int TempShortToothInterval=0;
unsigned char TPSLearnFlag=0;
unsigned char TPSlearnTimer=0;
extern unsigned int TPSmax;
extern unsigned int TPSmin;
int DeltaTPS;
extern unsigned int AccelEnrich;
unsigned char OldTPS;
unsigned int KPAold;
extern unsigned char interpolateBoostDuty();
unsigned char BoostDuty=0;
unsigned char TachoTest=0;
unsigned int TachoTestCount=513;
unsigned char TPSsavePending=0;     /* PATCH */

/* PATCH: requested AFR = table - warm-up trim, done signed so it cannot wrap
   to a lean value or reach zero (calculateFuel divides by it). The floor is
   below anything your tune asks for (your minimum is 4.0 at -20C). */
static unsigned char clampAFR(int a){
	if (a < MIN_REQ_AFRx10) a = MIN_REQ_AFRx10;
	if (a > MAX_REQ_AFRx10) a = MAX_REQ_AFRx10;
	return (unsigned char)a;
}
static unsigned char coil1Ticks=0, coil2Ticks=0;
static unsigned char startupDecayTicks=0, iacTicks=0;

/* PATCH v0.7: idle closed-loop fuel trim state */
int           IdleFuelTrim=0;        /* 0.01% units */
unsigned char IdleCLActive=0;        /* 1 = trim is being applied this moment */
unsigned char IdleCLStatus=0;        /* logged: see sendMonitorPacket */
static unsigned char idleSettle=0;
static unsigned int stftMult=256;      /* v0.9.1: STFT multiplier, 256 = no trim */
signed char STFTapplied=0;             /* v0.9.1: logged, 0.2% per count */
unsigned char stftTipHold=0;           /* v0.9.1: learner hold-off after a real throttle move */

/* PATCH v0.8: the boost solenoid click.
   "if (FuelPumpState==1) P8 &= ~(1<<7); else P8 |= 1<<7;" compiled to WORD
   instructions (AND P8,#0FF7Fh / OR P8,#0080h - confirmed in your H86 at
   0x2644/0x264A). Those read the whole of Port 8, modify it and write it
   back. The CAPCOM drives P8.3 (boost solenoid, CC19 compare mode 3) at the
   same time. If one of these straddled a compare edge it wrote back P8.3's
   old level, and nothing corrected it until the next PWM period - 29.5ms of
   solenoid on, i.e. one loud clack, at random, engine running or not.
   The chip's read-modify-write protection (manual 4.3 / table 2-1) only
   covers bit instructions. Declaring the outputs as sbits makes Keil emit
   BSET/BCLR, which are protected; writing only on change means the port
   isn't touched every pass at all. The fan (P7, next to the injector
   compare pins) gets the same treatment. */
sbit PUMP_RELAY = P8^7;          /* low = pump on  */
sbit FAN_RELAY  = P7^4;          /* low = fan on   */
static unsigned char pumpPinState = 0xFF;   /* 0xFF = not yet written */
static unsigned char fanPinState  = 0xFF;
int IACidlecontrol=50;
unsigned int lastIdleRPM=0;   /* v0.9.4: previous second's rpm, to tell a decaying blip from a high idle */
/* v0.9.5: steps still owed to the valve; + opens, - closes. Everything that
   wants air asks in steps, and the stepper works the backlog off at a rate the
   motor can keep up with. StepperPosition is only an estimate for the log and
   for knowing when an end stop has been reached. */
int IACpending=0;
int iacBase=0;                /* table + start-up bump, as last applied */
unsigned char iacBaseInit=0;  /* 0 until the base has been laid down after a home */
unsigned char iacBlipArmed=0; /* throttle has been open, so air is owed on the way back */
volatile unsigned char iacStepTicks=0;
unsigned char ToolFreezeIAC=0;         /* v0.9.6: see main.h */
unsigned char ToolSparkOn=0;
unsigned char ToolAltInject=0;         /* v0.9.7: dead-time test, see main.h */
unsigned int IACstepUs=IAC_STEP_US;    /* v0.9.9: from EEPROM 0x0F */
unsigned char IACfanSteps=0;           /* v1.0.0: from EEPROM 0x07 */
static unsigned char fanKicked=0;      /* the fan's air is in IACpending */
static volatile unsigned char fanLead=0;   /* 10ms ticks before the relay may close */
int ToolIACmove=0;                     /* v0.9.9: IAC speed test, see main.h */
unsigned char ToolNoSP=0;              /* v1.6.0: small-pulse correction held off for a test */
/* v1.6.0: the small-pulse adjustment for a commanded pulse, in timer ticks */
static int smallPulseTicks(unsigned long pw){
	unsigned char i, t;
	int bp[8], c[8], a;
	if (!EXT_OK() || ExtSettings[EXT_SP_MODE] != 1 || (ToolNoSP && ToolLease)) return 0;
	for (i = 0; i < 8; i++){ bp[i] = ExtSettings[EXT_SP_BP + i]; c[i] = (signed char)ExtSettings[EXT_SP_CORR + i]; }
	for (i = 1; i < 8; i++) if (bp[i] <= bp[i - 1]) return 0;
	t = (pw / 125UL > 255UL) ? 255 : (unsigned char)(pw / 125UL);          /* ticks -> 0.1 ms */
	if (t <= bp[0]) a = c[0];
	else if (t >= bp[7]) a = c[7];
	else { for (i = 0; i < 7; i++) if (t <= bp[i + 1]) break;
	       a = c[i] + (int)(((long)(c[i + 1] - c[i]) * (long)(t - bp[i])) / (long)(bp[i + 1] - bp[i])); }
	return a * 5;                                                            /* 4 us = 5 ticks */
}
volatile unsigned char DelayTestState=0, DelayTestBase=0, DelayTestFuelStep=0;   /* v1.2.0 */
volatile unsigned int  DelayTestTicks=0;
unsigned int dtSum=0;                  /* v1.2.0: baseline accumulator */
/* v1.3.0: accel enrichment table and event recorder */
unsigned char aeEvt[AE_EVT_N][AE_EVT_SIZE];
unsigned char aeEvtCount=0, aeEvtLost=0;
static unsigned char aeOn=0, aeRate, aeTravel, aeKpa, aeReq, aeLean, aeRich, aeTLean, aeTRich, aeTStop, aeQuiet, aeFlags, aeT;
static signed char aeClt;
static unsigned int aeRpm, aePeak;
static const unsigned char aeBpDef[8] = { 1, 2, 3, 5, 8, 12, 18, 26 };
static const unsigned int aeRpmAx[4] = { 1000, 2000, 4000, 6000 };
static const signed char aeCltAx[4] = { -10, 20, 50, 80 };
/* piecewise-linear lookup; x beyond the ends holds the end value */
static unsigned int aeLookup(int x, const int *ax, const unsigned char *val, unsigned char n){
	unsigned char i;
	if (x <= ax[0]) return val[0];
	for (i = 0; i < n - 1; i++) if (x <= ax[i + 1])
		return (unsigned int)(val[i] + (int)((long)((int)val[i + 1] - (int)val[i]) * (x - ax[i]) / (ax[i + 1] - ax[i])));
	return val[n - 1];
}
static unsigned char aeTableOK(void){
	unsigned char i;
	if (!EXT_OK() || ExtSettings[EXT_AE_MODE] != 1) return 0;
	for (i = 1; i < 8; i++) if (ExtSettings[EXT_AE_BP + i] <= ExtSettings[EXT_AE_BP + i - 1]) return 0;   /* axis must rise */
	return ExtSettings[EXT_AE_BP] >= 1;
}
unsigned int ToolIACperiodUs=IAC_STEP_US;
unsigned int  ToolSpark=0;             /* half degrees, same units as ReferenceTiming */
volatile unsigned int ToolLease=0;
unsigned char IdleSparkAdjust=0;
extern volatile unsigned char *TargetIdleRPM;   /* PATCH: matches memloc.c now */
unsigned int TargetIdle=1000;
 unsigned char EEPROMflags=0;
 extern unsigned int FuelingInjectorPW;
 
extern unsigned int KPA_Dwell_Adjust();
 
void SysTick(void) interrupt T6_Interrupt { //10ms (100hz)  timer

	
	//P8 ^= 1<<7;//K15 relay
	//P7 ^= 1<<4;//Starter Relay Control (polaris)
	
	/* PATCH: coil stuck-on watchdog - backstop for a stall or missed compare
	   mid-dwell. Only ever acts if a coil has been charging for >30ms. */
	if (iacStepTicks < 250) iacStepTicks++;    /* v0.9.5: paces the stepper */
	if (fanLead) fanLead--;                    /* v1.0.0: fan waits for its air */
	/* v1.2.0: wideband delay test. Average the wideband for 200 ms, add 10% fuel,
	   and count 10 ms ticks until the AFR has moved 4.5% (at least 0.3 AFR).
	   The step comes off as soon as it's seen, or after 3 s. */
	if (DelayTestState == 1 || DelayTestState == 2){
		if (EngineStalled || Wideband < WB_VALID_MIN || Wideband > WB_VALID_MAX){ DelayTestFuelStep = 0; DelayTestState = 4; }
		else if (DelayTestState == 1){
			dtSum += Wideband;
			if (++DelayTestTicks >= DT_BASELINE_TICKS){
				DelayTestBase = (unsigned char)(dtSum / DT_BASELINE_TICKS);
				DelayTestTicks = 0; DelayTestFuelStep = 1; DelayTestState = 2;
			}
		}
		else {
			unsigned char thr = (unsigned char)(((unsigned int)DelayTestBase * 45u) / 1000u);
			if (thr < 3) thr = 3;
			DelayTestTicks++;
			if (Wideband + thr <= DelayTestBase){ DelayTestFuelStep = 0; DelayTestState = 3; }   /* richer by the threshold */
			else if (DelayTestTicks >= DT_TIMEOUT_TICKS){ DelayTestFuelStep = 0; DelayTestState = 4; }
		}
	}
	if (ToolLease) ToolLease--;                /* v0.9.6: the tool must keep refreshing */
	else { ToolFreezeIAC = 0; ToolSparkOn = 0; ToolAltInject = 0; ToolIACmove = 0; ToolNoSP = 0; }
	if (Coil1State==1) { if (++coil1Ticks > COIL_ON_TIMEOUT) { P2 |= 0x01; Coil1State=2; coil1Ticks=0; } } else coil1Ticks=0;
	if (Coil2State==1) { if (++coil2Ticks > COIL_ON_TIMEOUT) { P2 |= 0x02; Coil2State=2; coil2Ticks=0; } } else coil2Ticks=0;

	if (RunTimer<10000) RunTimer++;
	
	DeltaTPS=(TPS - OldTPS)<<3;//* 8
	
	OldTPS=TPS;

	/* v0.9.1: learner hold-off on REAL throttle movement only (open or close) */
	if (DeltaTPS > STFC_TIPIN_DTPS || DeltaTPS < -STFC_TIPIN_DTPS) stftTipHold = STFC_TIPIN_HOLD;
	else if (stftTipHold) stftTipHold--;

	/* PATCH: accel enrichment now lives on the 10ms tick.
	   - (DeltaTPS+50)*VE was 16 bit and wrapped on your fastest snaps at
	     high VE (2 samples in your logs: 1.1ms asked, 0.0ms delivered).
	   - the decay was one count per main loop pass, so it ran at a different
	     speed whenever logging or anything else changed the loop time.
	   Same formula, same trigger, same decay rate you've been tuning against. */
	if (aeTableOK()){
		/* v1.3.0: the table. Extra fuel is a share of the current fuel pulse,
		   looked up by how fast the throttle is opening, scaled for rpm and
		   coolant; it holds its peak while the throttle keeps opening, then
		   fades with time constant tau. */
		unsigned char c = (DeltaTPS > 0) ? (unsigned char)(DeltaTPS >> 3) : 0;   /* TPS counts per 10 ms */
		int bp[8], rx[4], cx[4]; unsigned char i;
		for (i = 0; i < 8; i++) bp[i] = ExtSettings[EXT_AE_BP + i];
		for (i = 0; i < 4; i++){ rx[i] = (int)aeRpmAx[i]; cx[i] = aeCltAx[i]; }
		if (c >= bp[0]){
			unsigned long pct = aeLookup(c, bp, (const unsigned char *)&ExtSettings[EXT_AE_PCT], 8);
			unsigned long ae;
			pct = pct * aeLookup((int)RPM, rx, (const unsigned char *)&ExtSettings[EXT_AE_RPM], 4) / 100UL;
			pct = pct * aeLookup((int)CLT, cx, (const unsigned char *)&ExtSettings[EXT_AE_CLT], 4) / 100UL;
			ae = (unsigned long)FuelingInjectorPW * pct / 100UL;
			if (ae > ACCEL_ENRICH_MAX) ae = ACCEL_ENRICH_MAX;
			if (ae > AccelEnrich) AccelEnrich = (unsigned int)ae;
		} else {
			unsigned int tau = ExtSettings[EXT_AE_TAU], d;
			if (tau < 2 || tau > 200) tau = AE_TAU_DEF;
			d = AccelEnrich / tau; if (d == 0 && AccelEnrich) d = 1;
			AccelEnrich = (AccelEnrich > d) ? AccelEnrich - d : 0;
		}
	}
	else if (DeltaTPS>0){
		unsigned long ae = ((unsigned long)(DeltaTPS+50) * (unsigned long)VE) / 50UL;
		if (ae > ACCEL_ENRICH_MAX) ae = ACCEL_ENRICH_MAX;
		AccelEnrich = (unsigned int)ae;
	} else {
		if (AccelEnrich > ACCEL_DECAY_PER_10MS) AccelEnrich -= ACCEL_DECAY_PER_10MS;
		else AccelEnrich = 0;
	}

	/* v1.3.0: accel event recorder. Each throttle stab gets a record: how fast
	   and far the throttle moved, where the engine was, the enrichment given,
	   and how far and when the mixture went lean or rich of target over the
	   next second. The tuner reads them (CMD 0x24) and tunes the table. */
	{
		unsigned char c = (DeltaTPS > 0) ? (unsigned char)(DeltaTPS >> 3) : 0;
		unsigned char wbOk = (Wideband >= WB_VALID_MIN && Wideband <= WB_VALID_MAX);
		if (!aeOn){
			if (c >= AE_EVT_MIN && !EngineStalled && wbOk && !CrankFuelFlag && !FuelCut && SyncState == 1){
				aeOn = 1; aeT = 0; aeRate = c; aeTravel = c; aeRpm = RPM; aeKpa = (KPA > 255) ? 255 : (unsigned char)KPA;
				aeClt = CLT; aeReq = reqAFR; aePeak = AccelEnrich; aeLean = 0; aeRich = 0; aeTLean = 0; aeTRich = 0;
				aeTStop = 0; aeQuiet = 0; aeFlags = 0;
			}
		} else {
			int e = (int)Wideband - (int)reqAFR;          /* + = lean, 0.1 AFR */
			aeT++;
			if (c > 0){
				if (aeQuiet >= AE_EVT_QUIET && c >= AE_EVT_MIN) aeFlags |= 1;   /* a second stab: close this one */
				if (c > aeRate) aeRate = c;
				aeTravel = (aeTravel + c > 255) ? 255 : (unsigned char)(aeTravel + c);
				aeQuiet = 0;
			} else {
				if (aeQuiet < 255) aeQuiet++;
				if (aeQuiet == 1 && aeTStop == 0) aeTStop = aeT;
			}
			if (AccelEnrich > aePeak) aePeak = AccelEnrich;
			if (!wbOk || EngineStalled || FuelCut) aeFlags |= 2;               /* not a clean reading */
			else {
				if (e > 0 && e > aeLean){ aeLean = (e > 255) ? 255 : (unsigned char)e; aeTLean = aeT; }
				if (e < 0 && -e > aeRich){ aeRich = (-e > 255) ? 255 : (unsigned char)(-e); aeTRich = aeT; }
			}
			if (aeT >= AE_EVT_WINDOW || (aeFlags & 1)){
				unsigned char *r, k;
				if (aeEvtCount >= AE_EVT_N){                                      /* full: drop the oldest */
					for (k = 1; k < AE_EVT_N; k++){ unsigned char j; for (j = 0; j < AE_EVT_SIZE; j++) aeEvt[k - 1][j] = aeEvt[k][j]; }
					aeEvtCount = AE_EVT_N - 1; if (aeEvtLost < 255) aeEvtLost++;
				}
				r = aeEvt[aeEvtCount++];
				r[0] = aeRate; r[1] = aeTravel; r[2] = (unsigned char)(aeRpm >> 8); r[3] = (unsigned char)aeRpm;
				r[4] = aeKpa; r[5] = (unsigned char)aeClt; r[6] = aeReq; r[7] = (unsigned char)(aePeak >> 8); r[8] = (unsigned char)aePeak;
				r[9] = aeLean; r[10] = aeRich; r[11] = aeTLean; r[12] = aeTRich; r[13] = aeTStop ? aeTStop : aeT; r[14] = aeFlags;
				r[15] = ExtSettings[EXT_AE_MODE] == 1 && aeTableOK() ? 1 : 0; r[16] = 0;
				aeOn = 0;
			}
		}
	}

	/* PATCH: start-up air bump decays on time, not per loop pass (it used to
	   be gone in ~45ms, before the IAC target was even recalculated) */
	if (CrankFuelFlag==0 && StartUpIACincrease>0){
		if (++startupDecayTicks >= STARTUP_IAC_DECAY_TICKS){ startupDecayTicks=0; StartUpIACincrease--; }
	}

	/* PATCH: IAC target recalculated every 100ms instead of once a second, so
	   the start-up bump and temperature changes track smoothly. Clamped to the
	   valve's travel. The closed loop trim itself still steps once a second. */
	if (++iacTicks >= 10){
		int base;
		iacTicks = 0;
		/* v0.9.5: the IAC vs temp table and the start-up bump are only a
		   STARTING point now, laid down once after homing. After that the
		   valve is nudged: as the engine warms, or as the bump decays, only
		   the CHANGE is asked for, and the idle loop is free to put the
		   valve wherever it needs to be without a table value dragging it
		   back. The old code recomputed an absolute target every 100ms, so
		   the closed loop could only ever trim 50 steps either side of the
		   table - and bottomed out at 0 while the idle was still high. */
		base = (int)interpolate_IACvsTemp() + (int)StartUpIACincrease;
		if (!IAChome){
			if (!iacBaseInit){ iacBaseInit = 1; iacBase = base; IACpending += base; }
			else if (base != iacBase){ IACpending += base - iacBase; iacBase = base; }
		}
		/* anti-stall: air goes back in as the throttle closes, then the idle
		   loop takes over and finds its own level */
		if (TPS > IAC_BLIP_TPS) iacBlipArmed = 1;
		else if (iacBlipArmed){ iacBlipArmed = 0; IACpending += IAC_BLIP_OPEN_STEPS; }

		if (IACpending >  (int)IAChomeCountShadow) IACpending =  (int)IAChomeCountShadow;
		if (IACpending < -(int)IAChomeCountShadow) IACpending = -(int)IAChomeCountShadow;
		RequestedSteps = StepperPosition + IACpending + ToolIACmove;   /* for the log only */

		/* PATCH v0.7: idle closed-loop fuel trim, every 100ms.
		   Integrates the wideband error against your AFR tables' target
		   (reqAFR, including warm-up enrichment) into a single trim that is
		   applied only at idle. Deliberately slow - 2.5%/s for a 1.0 AFR error
		   - because at idle the injector-to-wideband delay is around half a
		   second, and a fast loop would hunt.
		   - learns only after 30s running, 2s steady at idle, wideband valid
		   - held (not applied) off idle; re-applied when idle returns
		   - discarded above 20% TPS, on a stall, or when the flag is off */
		{
			/* v0.9.4: VE Table Learn takes idle as well, so the idle trim stands
			   down completely while it is on - otherwise both loops chase the
			   same AFR error and the VE cells learn whatever the trim left over. */
			unsigned char enabled = ((EEPROMflags & FLAG_IDLE_CL) && !(EEPROMflags & FLAG_VE_LEARN) && !(ToolAltInject && ToolLease) && !(DelayTestState == 1 || DelayTestState == 2)) ? 1 : 0;
			unsigned char wbValid = (Wideband >= WB_VALID_MIN && Wideband <= WB_VALID_MAX) ? 1 : 0;
			unsigned char inRegion, learning = 0;

			inRegion = enabled && !EngineStalled && SyncState==1 && CrankFuelFlag==0 &&
			           TPS <= IDLECL_TPS_MAX && RPM >= IDLECL_RPM_MIN && RPM < IDLECL_RPM_MAX;

			if (!enabled || EngineStalled || TPS > IDLECL_RESET_TPS){ IdleFuelTrim = 0; idleSettle = 0; }

			if (inRegion){
				if (idleSettle < IDLECL_SETTLE_STEPS) idleSettle++;
				learning = (idleSettle >= IDLECL_SETTLE_STEPS) && (RunTimer >= IDLECL_WARMUP_TICKS) && wbValid;
				if (learning){
					int e = (int)Wideband - (int)reqAFR;          /* + = lean, needs fuel */
					if (e > IDLECL_DEADBAND || e < -IDLECL_DEADBAND){
						if (e >  IDLECL_ERR_CLAMP) e =  IDLECL_ERR_CLAMP;
						if (e < -IDLECL_ERR_CLAMP) e = -IDLECL_ERR_CLAMP;
						IdleFuelTrim += (e * 5) / 2;                 /* 0.025% per 0.1 AFR per 100ms */
						if (IdleFuelTrim > IDLECL_TRIM_MAX) IdleFuelTrim = IDLECL_TRIM_MAX;
						if (IdleFuelTrim < IDLECL_TRIM_MIN) IdleFuelTrim = IDLECL_TRIM_MIN;
					}
				}
			} else idleSettle = 0;

			IdleCLActive = inRegion;
			IdleCLStatus = (unsigned char)( enabled | (inRegion<<1) | (learning<<2) | (wbValid<<3) |
			                                (CaptureMode<<4) | ((SyncState & 0x03)<<5) );
		}
		updateSTFC();   /* PATCH v0.9: off-idle STFT table, same 100ms tick */
	}
	
	systick--;
	if (systick==0){ //1 sec interrupt
		systick=100;
		
		TargetIdle=TargetIdleRPM[0]*10;

			if (TPSlearnTimer>0){
				TPSlearnTimer--;
				
				if (TPSlearnTimer==1){ //end of 5 sec, lets save it to eeprom
					/* PATCH: the EEPROM write used to run right here, inside the
					   10ms interrupt. It blocks for milliseconds, and it drives the
					   EEPROM chip select on the SPI bus the IAC stepper shares - if
					   it lands mid stepper byte, both chips are selected at once.
					   The main loop now does the write. */
					TPSsavePending=1;
				}
				
			}
			else
			{
				//FanState=0;
			}
			
			/* PATCH: closed loop idle. The reset test was (RPM+500) > TargetIdle,
			   i.e. "rpm within 500 BELOW target or anywhere above", so the trim only
			   ever ran when rpm had dropped 500+ below target - and in that branch
			   the decrement could never be true. The trim could only open the valve,
			   and only as an anti-stall. Now: reset above 5% throttle, when stopped,
			   or while rpm is still falling from well above target; otherwise trim
			   both ways, one step per second, outside a +/-50 rpm deadband. */
			/* v0.9.4: the reset used to fire on rpm being above target+500 at all,
			   so an idle that sat high - too much air in the table, a leak, a
			   stale home count - parked the trim at 50 every second and the valve
			   never came down off the table value. Only a rpm that is still
			   FALLING is a blip decaying; a steady high idle is what the trim is
			   for. Steps are also proportional now: a 500 rpm error took the best
			   part of a minute at one step a second. */
			{
				int idleErr = (int)RPM - (int)TargetIdle;      /* + = too fast */
				int falling = (lastIdleRPM > 0) && (((int)lastIdleRPM - (int)RPM) > IDLE_FALLING_RPM);
				int steps;

				if (ToolFreezeIAC && ToolLease){
					/* v0.9.6: air held still for an idle spark sweep */
				}
				else if ((TPS > IAC_BLIP_TPS) || (RPM == 0)){
					/* off idle, or stopped: the blip handler puts the air back */
				}
				else if ((idleErr > IDLE_RESET_ABOVE_RPM) && falling){
					/* still coming down from a blip: let it land before trimming */
				}
				/* v0.9.2: TPS 1% and up (3+ counts) - don't close the valve any
				   further. Before, anything up to 12 counts (4.7%) counted as idle,
				   so a light throttle holding rpm above target walked the valve shut
				   one step a second, down to IDLE_TRIM_MIN.
				   v0.9.4: that hold is one-way. Opening still works, so a TPS that
				   reads high at closed throttle can't leave the engine to stall -
				   it just won't pull a high idle down until the TPS is re-learned. */
				else if (idleErr > IDLE_DEADBAND_RPM && TPS <= IAC_TUNE_TPS_MAX){
					steps = 1 + (idleErr - IDLE_DEADBAND_RPM) / IDLE_STEP_SPLIT;
					if (steps > IDLE_STEP_MAX) steps = IDLE_STEP_MAX;
					IACpending -= steps;                        /* too fast: close */
				}
				else if (-idleErr > IDLE_DEADBAND_RPM){
					steps = 1 + (-idleErr - IDLE_DEADBAND_RPM) / IDLE_STEP_SPLIT;
					if (steps > IDLE_STEP_MAX) steps = IDLE_STEP_MAX;
					IACpending += steps;                        /* too slow: open */
				}
				lastIdleRPM = RPM;
			}
			
		if (PrimeTimer>0){
			FuelPumpState=1;
			PrimeTimer--;
		}
		else
		{
			if (EngineStalled==1)	{
				FuelPumpState=0;
				RunTimer=0;
			}
	}
}
	
	
	
	
}


void main (void)  {               /* execution starts here               */
	
	
	P3  |= 0x8400;        /* SET PORT 3.10 OUTPUT LATCH (TXD)              */
  DP3 |= 0x8400;        /* SET PORT 3.10 DIRECTION CONTROL (TXD OUTPUT)  */
  DP3 &= 0xF7FF;        /* RESET PORT 3.11 DIRECTION CONTROL (RXD INPUT) */
	ODP2 |= 0x0020;
	P2  |= 0x202F;        /* SET PORT 3.10 OUTPUT LATCH (TXD)              */
  DP2 |= 0x202F;        /* SET PORT 3.10 DIRECTION CONTROL (TXD OUTPUT)  */
	DP7  |= 0x00FF;        /* SET PORT 3.10 OUTPUT LATCH (TXD)              */
	P7|=0xFF;
	DP8|=0xFE;
	P8|=0x4F;


	
	ssc_init(); //spi port init
	
	//release system reset
	__asm{
		EINIT 
	}



	
	copyFlash2RAM();
	serialInit();
  timer_init();
	init_adc();
  // Enable global interrupts
  IEN = 1;

	
	readEEPROMsettings();
	BaseFuel=(BaseFuelmS[0]<<8)|(BaseFuelmS[1]);
  DP2 |= 0x202F;        /* SET PORT 3.10 DIRECTION CONTROL (TXD OUTPUT)  */
	
	calculateTemps(); //read the temps and use this data for crank pulsewidths
	RequestedSteps=StartUpIACincrease+interpolate_IACvsTemp();
	
		while(1){
			
			if (TachoTest==1){
				TachoTestCount--;
				if (TachoTestCount==0)TachoTest=0;
					if((TachoTestCount&0x03)==0x00)		P2  ^= 1 << 13 ; //generate tacho signal 
			}
			

			TempShortToothInterval=ShortToothInterval; //prevent race conditions for RPM when shorttoothinterval is updated mid calculation
			
			if (TempShortToothInterval==0) RPM=0;   /* PATCH: divide by zero before the first tooth */
			else RPM = (unsigned int)((unsigned long)(20000000 * 60) / (((unsigned long)TempShortToothInterval * (16)) * ToothCount)); 
			if (RPM > rpmScale[15])RPM=rpmScale[15];
			/* PATCH: calculateSparkTiming() moved below TotalTiming. It now runs
			   every pass (it only ran while T0==1, one tooth wide, so updates were
			   skipped whenever the loop was slow) and writes shadows that the tooth
			   ISR latches at the gap. */
		if (EngineStalled==1){
			RPM=0;
			LossOfSyncCount=0;
		}
		
		
		//SubLoopCount is used for fucntions not needed to be called every loop, like IAC control
		SubLoopCnt++;
		if (SubLoopCnt==8)SubLoopCnt=0;
		if (SubLoopCnt==0){
		
		//Boost Control
		BoostDuty=interpolateBoostDuty();

			
		dwellUs=interpolate_dwell(); //Calculate Coil Dwell angle based off battery voltage
		dwellUs+=KPA_Dwell_Adjust();
			InjectorDeadTime=interpolate_IDT(); //Calculate injector dead time based off battery voltage
		IATretardValue=interpolate_IATRetard();
		calculateTemps(); //Calc IAT and CLT temps
		
			
	
			
		}

		/* v0.9.8: the IAC stepper runs every main-loop pass, paced in microseconds
		   off T7, so it can go as fast as the valve will follow - see IAC_STEP_US.
		   Full current while moving; holding current only once it has been still
		   for IAC_SETTLE_US. (The v0.9.5 drift blamed on step rate was really the
		   phase bug fixed in IAC.C.) */
		{
			static unsigned int iacLastT7 = 0, iacMovedT7 = 0;
			static unsigned char iacSettling = 0;
			unsigned int nowT7 = T7;
			unsigned char testing = (ToolIACmove != 0 && ToolLease && !IAChome);
			unsigned int period = IAC_US_TO_T7(testing ? ToolIACperiodUs : IACstepUs);
			unsigned char stepped = 0;
			if ((unsigned int)(nowT7 - iacLastT7) >= period){
				if (IAChome==1){
					IAC_Move(0,1); stepped = 1;
					IAChomeCount--;
					if (IAChomeCount==0){
						IAChome=0;
						StepperPosition=0;
						IAChomeCount=IAChomeCountShadow; //number of steps to fully close the IAC valve
						iacBaseInit=0;          /* lay the starting air back down from the table */
						IACpending=0;
					}
				}
				else if (testing){                                   /* v0.9.9: IAC speed test move */
					if (ToolIACmove > 0){ if (StepperPosition < (int)IAChomeCountShadow){ IAC_Move(1,1); StepperPosition++; stepped = 1; } ToolIACmove--; }
					else                { if (StepperPosition > 0){ IAC_Move(0,1); StepperPosition--; stepped = 1; } ToolIACmove++; }
				}
				else if (ToolFreezeIAC && ToolLease){ /* v0.9.6: held for the sweep - see below */ }
				else if (IACpending > 0){
					if (StepperPosition < (int)IAChomeCountShadow){ IAC_Move(1,1); StepperPosition++; IACpending--; stepped = 1; }
					else IACpending = 0;        /* wide open: stop counting steps it cannot take */
				}
				else if (IACpending < 0){
					if (StepperPosition > 0){ IAC_Move(0,1); StepperPosition--; IACpending++; stepped = 1; }
					else IACpending = 0;        /* shut: nothing left to close */
				}
				if (stepped){ iacLastT7 = nowT7; iacMovedT7 = nowT7; iacSettling = 1; }
			}
			/* drop to holding current once it has stopped and settled */
			if (!stepped && iacSettling && (unsigned int)(nowT7 - iacMovedT7) >= IAC_US_TO_T7(IAC_SETTLE_US)){
				iacSettling = 0;
				IAC_Move(2,0);
			}
			if (ToolFreezeIAC && ToolLease && !iacSettling) IAC_Move(2,0);   /* v0.9.6: hold (no-op once holding) */
		}
		
		//Check and process K-line packets
		if (validPacketReceived==1){
			processPacket();
		}
		//If TunerPro has requested a monitor frame, send it out one byte per main loop
		if (SendMonitor==1) sendMonitorPacket();
		if (SendADC==1) sendADCPacket();
		
		calculateTPS(); //Calculate TPS 

		calculateWideband();
	 calculateVbatt();
		calculateMAP(MAPSensorType); 
				
		/* PATCH: hysteresis - selection used to flip every pass while hovering at 100 kPa.
		   Both tables meet at 100 kPa (NA axis top / boost axis bottom). */
		if (BoostTable==0){ if (KPA > BOOST_TABLE_ON_KPA)  BoostTable=1; }
		else              { if (KPA < BOOST_TABLE_OFF_KPA) BoostTable=0; }
		
		if ((TPS > 12)|| RPM < 500){ //only enable idle spark control if less than 5% TPS, else 0 advance
			IdleSparkAdjust=0;
		}
		else
		{
			if (RPM>TargetIdle){ 
				if (IdleSparkAdjust>0) IdleSparkAdjust--;
				}
			if (RPM<TargetIdle) {
				if (IdleSparkAdjust<10) IdleSparkAdjust++;
			}
		}		
		
		/* v0.9.6: idle MBT sweep. Honoured only at idle throttle and low rpm,
		   so it can never apply under load even if the tool misbehaves. */
		if (ToolSparkOn && ToolLease && TPS <= IAC_TUNE_TPS_MAX && RPM < TOOL_SPARK_MAX_RPM) RequestedTiming=ToolSpark;
		else if (EEPROMflags&ForceRefTiming)RequestedTiming=ReferenceTiming; //If Timing lock is requested, use the value defined in ReferenceTiming
		else{
			int t;
			if (BoostTable==0){
				t=(int)IdleSparkAdjust+(int)interpolateTable(ignitionMap,RPM,KPA,BoostTable) - (int)IATretardValue; //else calculate the requested timing using lookups
			}
			else {
				t=(int)interpolateTable(ignitionMapBoost,RPM,KPA,BoostTable) - (int)IATretardValue;//Use boost tables if > 1 bar
			}
			/* PATCH: this was unsigned. Retard larger than the table value wrapped
			   to ~65000, which turned every spark angle into garbage. */
			if (t < 0) t = 0;
			RequestedTiming=(unsigned int)t;
		}		
		
		TotalTiming=RequestedTiming + TDCoffset ; //add in the trigger wheel's missing tooth offset angle
		calculateSparkTiming();   /* PATCH: see note at the RPM calculation */

		if (BoostTable==0){
			VE=(unsigned char)interpolateTable(VEMap,RPM,KPA,BoostTable); //Calculate VE using lookups
			reqAFR=clampAFR((int)interpolateTable(AFRMap,RPM,KPA,BoostTable) - (int)interpolate_AFR()); //PATCH: signed + clamped
		}
		else {
			VE=(unsigned char)interpolateTable(VEMapBoost,RPM,KPA,BoostTable);
			reqAFR=clampAFR((int)interpolateTable(AFRMapBoost,RPM,KPA,BoostTable) - (int)interpolate_AFR()); //PATCH: signed + clamped
		}
		/* PATCH v0.9.1: the STFT table is looked up here but applied to the fuel
		   pulse below, not to VE. VE is 8 bit and clips at 255: in your boost VE
		   table 121 of 256 cells couldn't take the full +15%, the richest only
		   +8%, so a lean high-load cell could never be corrected.
		   XDF encoding: displayed% = 50 - (100/256)*raw, raw 128 = 0%.
		   Multiplier (384 - raw)/256. Clamped to the learn range so a stray
		   value written from TunerPro can never exceed +/-15%. */
		{
			unsigned char st = interpolateTable(
				BoostTable ? (unsigned char *)STFC_Boost : (unsigned char *)STFC,
				RPM, KPA, BoostTable);
			if (st < STFC_RAW_MIN) st = STFC_RAW_MIN;
			if (st > STFC_RAW_MAX) st = STFC_RAW_MAX;
			/* v0.9.2: VE Table Learn ticked = STFT tables are not applied, so
			   the VE table learns the whole correction and is right on its
			   own. Logged STFT Table % reads 0 in this mode. */
			if (EEPROMflags & FLAG_VE_LEARN) st = STFC_RAW_ZERO;
			stftMult = (unsigned int)(384u - st);               /* 256 = no trim */
			STFTapplied = (signed char)(((int)STFC_RAW_ZERO - (int)st) * 250 / 128);  /* 1 raw = 0.390625% -> 0.2% units */
		}
		AlphaN=(unsigned char)interpolateTable(AlphaNMAP,RPM,TPS,BoostTable);

					if (EEPROMflags&UseAlphaN){
						VE=AlphaN;
						KPA=100;
					}

		/* PATCH: accel enrichment calculation and decay moved to SysTick */
		
		if (CycleCounter<CrankEnrichDecayCount){
			FuelingInjectorPW=calculateCrankPw();
			totalInjectorPW=FuelingInjectorPW + InjectorDeadTime;
			CrankFuelFlag=1;
			LossOfSyncCount=0; //don't check for loss of sync until engine is running
			StartUpIACincrease=30; //add more Air for starting
		}
		else {
			FuelingInjectorPW=calculateFuel();
			/* v0.9.1: STFT table trim, on the fuel mass (not dead time) */
			FuelingInjectorPW = (unsigned int)(((unsigned long)FuelingInjectorPW * (unsigned long)stftMult) / 256UL);
			if (IdleCLActive)   /* PATCH v0.7: idle closed-loop trim, applied to the fuel only (not dead time) */
				FuelingInjectorPW = (unsigned int)(((unsigned long)FuelingInjectorPW * (unsigned long)(10000 + IdleFuelTrim)) / 10000UL);
			{	/* PATCH: summed in 32 bits so fuel + dead time + accel can't wrap */
				unsigned long pw = (unsigned long)FuelingInjectorPW + InjectorDeadTime + AccelEnrich;
				/* v0.9.7: dead-time test. Firing every other revolution with the fuel
				   part doubled delivers the same fuel - IF the dead time is right,
				   because the injector now opens once per cycle instead of twice.
				   Any AFR shift between the two modes is the dead-time error. */
				if (ToolAltInject && ToolLease) pw += FuelingInjectorPW;
				if (DelayTestFuelStep) pw += (unsigned long)FuelingInjectorPW * (DT_STEP_PCT - 100u) / 100u;   /* v1.2.0 */
				{	/* v1.6.0: small-pulse correction, looked up by the pulse as commanded */
					int sp = smallPulseTicks(pw);
					if (sp < 0 && (unsigned long)(-sp) >= pw) pw = 0; else pw = (unsigned long)((long)pw + sp);
				}
				if (pw > MAX_INJ_PW_TOTAL) pw = MAX_INJ_PW_TOTAL;
				totalInjectorPW = (unsigned int)pw;
			}
				CrankFuelFlag=0;
			/* PATCH: start-up air decay moved to SysTick (time based) */
		}
	
		
		/* PATCH: flood clear was only evaluated while stalled, so a value set
		   during cranking stayed latched into running. Same condition, just
		   no longer latched (RPM is 0 while stalled). */
		if (TPS>230 && RPM<400){FloodClear=1;}else{FloodClear=0;}

		/* PATCH v0.7: tooth capture mode follows the TunerPro flag, but is only
		   ever switched while the engine is stopped */
		if (EngineStalled==1){
			unsigned char want = (EEPROMflags & FLAG_HW_CAPTURE) ? 1 : 0;
			if (want != CaptureMode) selectToothCaptureMode(want);
		}

		if (EngineStalled==1 )
			{
			
			CycleCounter=0;
			//Set up the IAC position
			
			//Disable Spark and Fuel outputs
			SparkCut=1;
			FuelCut=1;
		}
		else
		{
			SparkCut=0;
			FuelCut=0;
			FuelPumpState=1;
		}
		/* v0.9.5: this test used to live inside the "engine running" branch, so
		   with the key on and the engine stopped - a hot soak, exactly when the
		   fan is wanted - FanState could never be set. It now follows coolant
		   temperature whenever the ECU is powered, held off while cranking so the
		   starter has the battery to itself. FanState doubles as the TPS-learn
		   confirmation blip, hence the TPSlearnTimer tests. */
		if (CLT>=FanCutIn[0] && CrankFuelFlag==0 && TPSlearnTimer==0) FanState=1;
		if ((CLT<FanCutOut[0])&&TPSlearnTimer==0) FanState=0;
		
		if (RPM > RevLimitValue)SparkCut=1; 
		if (SyncState != 1) SparkCut=1;   /* PATCH: sync validation - spark only, fuel continues */
		
		if (FloodClear==1)FuelCut=1;
		
		
		if (KPA > BoostSafetyKPA[0]) SparkCut=1; //if we overboost, we cut spark to prevent damage
		
		/* PATCH: spark cut (rev limit, overboost) is honoured inside the CC6/CC8
		   interrupts, so a coil that is already charging fires at its scheduled
		   angle instead of being released by tri-stating DP2 at whatever moment
		   the loop reaches this line. Tri-state is kept for the stalled case,
		   after the coils are off. Still spark cut only - fuel is untouched. */
		if (EngineStalled==1){ sparkAllOff(); DP2 &=~0x03; } //set DP2.0 and DP2.1 to input
		else DP2 |=0x03; //set DP2.0 and DP2.1 to output
		
		if (FuelCut==1){
			DP7 &=~0x60;  //7.5,7.6
			//DP8 &=~0x80; //8.7
		}
		else{
			DP7 |=0x60; //
			//DP8 |=0x80; //
		}

		if ((EngineStalled==1)&&(EngineStalledShw==0)){ //engine has just stalled, this will only be executed once every stall
			IAChome=1; //send the IAC motor back to its home position
			PrimeTimer=FuelPumpPrimeTime;
		}
		
		
			/* PATCH: deferred work moved out of the 10ms interrupt */
			if (TPSsavePending){
				TPSsavePending=0;
				EEPROMbuffer[0x00]=(unsigned char)(TPSmin>>8);
				EEPROMbuffer[0x01]=(unsigned char)(TPSmin&0xFF);
				EEPROMbuffer[0x02]=(unsigned char)(TPSmax>>8);
				EEPROMbuffer[0x03]=(unsigned char)(TPSmax&0xFF);
				eeprom_write(0x0B,4);
				FanState=1;
			}

			if (FuelPumpState != pumpPinState){ pumpPinState = FuelPumpState; PUMP_RELAY = (FuelPumpState==1) ? 0 : 1; }
			/* v1.0.0: the fan's electrical load drags the idle down the moment the
			   relay closes, and the idle loop only catches it afterwards. So the
			   air goes in first: IACfanSteps are added as the fan is asked for,
			   the relay waits FAN_LEAD_TICKS for the valve to open, and the air
			   comes out again when the fan goes off. A stall drops the kick (the
			   valve re-homes); if the fan is still on once it restarts, it goes
			   back in. The TPS-learn blip gets no air. */
			if (EngineStalled) fanKicked = 0;
			else if (FanState==1 && !fanKicked && IACfanSteps && TPSlearnTimer==0){
				IACpending += IACfanSteps; fanKicked = 1;
				if (fanPinState != 1) fanLead = FAN_LEAD_TICKS;
			}
			if (FanState!=1 && fanKicked){ IACpending -= IACfanSteps; fanKicked = 0; }
			if (FanState != fanPinState && (FanState!=1 || fanLead==0)){ fanPinState = FanState; FAN_RELAY = (FanState==1) ? 0 : 1; }
		
		flags=((unsigned char)(EngineStalled<<7))|((unsigned char)(FuelCut<<6)) | ((unsigned char)(FloodClear<<5))|((unsigned char)(FanState<<4))| ((unsigned char)(FuelPumpState<<3))|((unsigned char)(CrankFuelFlag<<2))| ((unsigned char)(BoostTable<<1))|((unsigned char)(SparkCut<<0)); //set flags registers
		EngineStalledShw=EngineStalled;
	}
}                       

