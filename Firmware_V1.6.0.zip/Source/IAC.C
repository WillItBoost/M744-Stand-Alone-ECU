#include "reg167.h" 
unsigned char IACphase=0;
unsigned char IACactive=1;
#define IACcurrent 0x00 //v0.9.8: full current while moving. 0x82 = 550mA, 0x00 = 900mA, 0x24 = 60mA
#define IAChold    0x24 //64mA once the valve has stopped
#define PhaseA 0x00 //bit 0 and 3
#define PhaseB 0x01 //bit 0 and 3
#define PhaseC 0x08 //bit 0 and 3
#define PhaseD 0x09 //bit 0 and 3

void IAC_chipselect_low(void)
{
	__asm{
		bclr P8.2
	}
}

void IAC_chipselect_high(void)
{
   	__asm{
		bset P8.2
	}
}


extern unsigned char ssc_xfer(unsigned char data);

/* PATCH: shares the SSC with the EEPROM. The old busy-waits could hang the
   main loop forever if an interrupt delayed the poll past one byte time. */
void sendSPI(char dbyte){
	ssc_xfer((unsigned char)dbyte);
}


/* v0.9.8: the phase index used to be sent FIRST and advanced AFTER. That is
   one phase out of step with the valve:
   - on every change of direction the first "step" went the old way while
     being counted the new way - two steps of error per reversal, and the
     idle loop reverses constantly;
   - every hold energised the NEXT phase (at holding current), nudging the
     rotor on in the last direction each time the valve stopped.
   Now the index moves first and the phase sent is the one the rotor is being
   pulled to; a hold re-sends the phase it is actually sitting on. The phase
   ORDER (A B D C = 00 01 11 10, a proper full-step sequence) is unchanged. */
static const unsigned char IACphaseBits[4] = { PhaseA, PhaseB, PhaseD, PhaseC };

void IAC_Move(char Direction,char Active){
	unsigned char StepperCurrent;

	if (Direction==2){                          /* hold where it is */
		if (IACactive==0) return;               /* already holding */
		IACactive=0;
		StepperCurrent=IAChold;
	}
	else {
		if (Direction==0) IACphase = (unsigned char)((IACphase + 1) & 3);   /* close */
		else              IACphase = (unsigned char)((IACphase + 3) & 3);   /* open  */
		IACactive=1;
		StepperCurrent = Active ? IACcurrent : IAChold;
	}

	IAC_chipselect_low();
	sendSPI(StepperCurrent | IACphaseBits[IACphase]);
	IAC_chipselect_high();
}


void IAC_Close(){

}