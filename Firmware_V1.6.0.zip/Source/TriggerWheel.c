#include "reg167.h"    
#include "main.h"
static unsigned char inj1Rev=0, inj2Rev=0;   /* v0.9.7: revolution parity per bank */

#define CC4_Interrupt 0x14 //CC4 interrupt
#define CC15_Interrupt 0x1F //CC15 interrupt
#define T0_Interrupt 0x20 //T0 interrupt
#define T1_Interrupt 0x21 //T1 interrupt

unsigned int DetectedTeeth=0;
/* PATCH: sync validation.
   0 = waiting for the first gap after key-on or a stall. That gap is accepted
       immediately, so starting is exactly as fast as before.
   1 = synced. Every gap must count exactly ToothCount teeth.
   2 = a gap counted wrong while running (false gap, missed or extra tooth).
       Spark is cut - fuel continues - until a gap counts correctly again,
       normally one or two revolutions. Your logs show LossOfSyncCount = 0
       throughout, so this should never engage on a healthy sensor. */
unsigned char SyncState=0;

/* PATCH v0.7: hardware tooth capture.
   CaptureMode 0 = original: read T1 in the ISR and reset it (the interval
                   includes however late this interrupt ran).
   CaptureMode 1 = CC15 latches T1 in hardware at the tooth edge (ACC15 = 1),
                   T1 free-runs, interval = difference of two captures. No
                   interrupt latency in the measurement, and the spark ISRs
                   can measure and remove their own latency (ignition.c).
   Selected from TunerPro, only ever switched while the engine is stopped. */
unsigned char CaptureMode=0;
static unsigned int  lastCapture=0;
static unsigned char validIntervals=0;     /* real intervals seen since the last stall */
static volatile unsigned int toothSeq=0;   /* bumped every tooth, watched by the T1 ISR */
static unsigned int  t1SeqSeen=0;
static unsigned char t1Quiet=0;

void selectToothCaptureMode(unsigned char want){
	CC15IE=0;
	CCM3 = (CCM3 & 0x0FFF) | (want ? 0x9000 : 0x1000);   /* ACC15 | capture rising edge */
	CaptureMode = want;
	validIntervals = 0;                                   /* first intervals are not trusted */
	CC15IE=1;
}
unsigned char TDCflag=0;

unsigned int LastToothInterval=0x7FFF;

unsigned int ShortToothInterval=0;
extern unsigned int RPM;
extern char LossOfSyncCount;
extern volatile char *InjectionOffset1;
extern volatile char *InjectionOffset2;
extern unsigned char TPS,OldTPS;
void TriggerCountMatch(void) interrupt CC4_Interrupt {

	//T0=0;
	
//	Injector1_fire(5000);
//	Injector2_fire(5000);
//	Injector3_fire(5000);
//	Injector4_fire(5000);
}

extern void calculateSparkTiming();
extern void calculateRPM();
extern unsigned char EngineStalled;


void Timer1Overflow(void) interrupt T1_Interrupt{
	/* PATCH v0.7: in capture mode T1 is never reset, so it overflows every
	   52ms whether or not the engine is turning. Only a stall if a whole T1
	   period passes with no tooth (52-104ms after the last one). */
	if (CaptureMode){
		if (toothSeq != t1SeqSeen){ t1SeqSeen = toothSeq; t1Quiet = 0; return; }
		if (++t1Quiet < CAPTURE_STALL_OVF) return;
		t1Quiet = 0;
	}
	validIntervals=0;
	EngineStalled=1;
	RPM=0;
	SyncState=0;   /* PATCH: next gap is accepted straight away */
	/* PATCH: a stall mid-dwell used to leave a coil charging, and a stall
	   mid-injection left an injector open, until something else noticed. */
	sparkAllOff();
	injectorsAllOff();
}
void Timer0Overflow(void) interrupt T0_Interrupt{
	
}

void ToothIntervalInterrupt(void) interrupt CC15_Interrupt using INTREG1{ //called every tooth
	unsigned int T1dbl;
	unsigned char trusted;
	if (CaptureMode){
		unsigned int cap = CC15;          /* T1 latched by hardware at the edge */
		T1dbl = cap - lastCapture;        /* unsigned: correct across a T1 wrap */
		lastCapture = cap;
	} else {
		T1dbl=T1;
		T1=0; //reset tooth timer
	}
	toothSeq++;

	/* PATCH v0.7: after a stall the first interval is garbage (T1 has been
	   running or wrapping since the last tooth), and a garbage interval can
	   look like a gap. The old code would then have accepted a false first
	   gap and fired the first revolution at the wrong angle. Only trust a gap
	   once two real intervals have been measured. Costs 20 degrees of crank. */
	trusted = (validIntervals >= TEETH_BEFORE_GAP);
	if (validIntervals < 255) validIntervals++;
	
	/* PATCH: integer compare. "* 1.5" was a software floating point multiply
	   in the most frequent interrupt in the system. Same 1.5x threshold. */
	if (trusted && ((unsigned long)T1dbl * 2UL) > ((unsigned long)LastToothInterval * 3UL)){ //Missing tooth detected, or engine stall
		DetectedTeeth=T0; //take note of how many teeth before the missing tooth was detected as a valid sync detection
		/* PATCH: load the whole spark schedule for the coming revolution in
		   one go. Done BEFORE T0 is rewritten so that a compare scheduled on
		   tooth 1 is armed when the write below triggers it. */
		latchSparkSchedule();
		T0=1; //Reset toof count
		
		//calculateSparkTiming();

		
		if (DetectedTeeth!=(ToothCount))LossOfSyncCount++; //or loss of sync - will this cause backfiring upon start? lets see!
		/* PATCH: sync validation (see SyncState above) */
		if (SyncState==0)                       SyncState=1;
		else if (DetectedTeeth==(ToothCount))   SyncState=1;
		else                                  { SyncState=2; sparkAllOff(); }
		EngineStalled=0; //here we could use this to enable the spark and fuel, and also set a sync valid signal, and loss of sync valid could be used to kill spark. This would allow faster starting
//			Injector1_fire(totalInjectorPW);
//			Injector2_fire(totalInjectorPW);

		
		
	}
	else
	{
		ShortToothInterval=T1dbl; //use this for RPM calculation
	}
	LastToothInterval=T1dbl;
	
	
	//calculateRPM();
	
	
    //    RPM = (unsigned int)((unsigned long)(20000000 * 60) / (((unsigned long)ShortToothInterval * (16)) * ToothCount));   

	
	//calculateSparkTiming();

	/* v0.9.7: in the dead-time test each bank fires on alternate revolutions */
	if (T0==InjectionOffset1[0]){ inj1Rev ^= 1; if (!(ToolAltInject && ToolLease) || inj1Rev) Injector1_fire(totalInjectorPW); }
	if (T0==InjectionOffset2[0]){ inj2Rev ^= 1; if (!(ToolAltInject && ToolLease) || inj2Rev) Injector2_fire(totalInjectorPW); }

	//	OldTPS=TPS;

}
