#include <reg167.h>     

#define TIMER2_INTERRUPT 0x22 // Timer 2 interrupt number

#define NMI_Interrupt 0x02
#define StackOverflow_Interrupt 0x04
#define StackUnderflow_Interrupt 0x06
#define HardwareTrap_Intrrupt 0x0A

#define Intrrupt_0x10 0x10 //
#define Intrrupt_0x11 0x11 //
#define Intrrupt_0x12 0x12 //
#define Intrrupt_0x13 0x13 //
#define Intrrupt_0x14 0x14 //
#define Intrrupt_0x15 0x15 //
#define Intrrupt_0x16 0x16 //
#define Intrrupt_0x17 0x17 //
#define Intrrupt_0x18 0x18 //
#define Intrrupt_0x19 0x19 //
#define Intrrupt_0x20 0x20 //
#define Intrrupt_0x21 0x21 //
#define Intrrupt_0x22 0x22 //
#define Intrrupt_0x23 0x23 //
#define Intrrupt_0x24 0x24 //
#define Intrrupt_0x25 0x25 //
#define Intrrupt_0x26 0x26 //
#define Intrrupt_0x27 0x27 //
#define Intrrupt_0x28 0x28 //
#define Intrrupt_0x29 0x29 //
#define Intrrupt_0x30 0x30 //
#define Intrrupt_0x31 0x31 //
#define Intrrupt_0x32 0x32 //
#define Intrrupt_0x34 0x34 //
#define Intrrupt_0x35 0x35 //
#define Intrrupt_0x36 0x36 //
#define Intrrupt_0x37 0x37 //
#define Intrrupt_0x38 0x38 //
#define Intrrupt_0x39 0x39 //
#define Intrrupt_0x40 0x40 //
#define Intrrupt_0x41 0x41 //
#define Intrrupt_0x42 0x42 //
#define Intrrupt_0x43 0x43 //the last of the traps


//Port3.5 output high will disable the security module (disable output drivers) but not issue a system reset. This is used for runtime flash updating.

unsigned int ResponseBuffer[3]={7222,8528,0};
unsigned int WDTResponse=0;
char WDTmodeListen=0; //
char WDTinitialdelay=1;
char WDTdelayperiod=0;
char placeInSequence=0;
unsigned int WDT_RX_PW=0;
char ResponseCounter=0; //every 16th reply we need to send an invalid response


void I10(void) interrupt Intrrupt_0x10{
}
void I11(void) interrupt Intrrupt_0x11{
}
void I12(void) interrupt Intrrupt_0x12{
}
void I13(void) interrupt Intrrupt_0x13{
}

void I25(void) interrupt Intrrupt_0x25{
}
void I27(void) interrupt Intrrupt_0x27{
}
void I29(void) interrupt Intrrupt_0x29{
}

void I30(void) interrupt Intrrupt_0x30{
}
void I31(void) interrupt Intrrupt_0x31{
}
void I32(void) interrupt Intrrupt_0x32{
}

void I34(void) interrupt Intrrupt_0x34{
}
void I35(void) interrupt Intrrupt_0x35{
}
void I36(void) interrupt Intrrupt_0x36{
}
void I37(void) interrupt Intrrupt_0x37{
}
void I38(void) interrupt Intrrupt_0x38{
}
void I39(void) interrupt Intrrupt_0x39{
}



void I43(void) interrupt Intrrupt_0x43 {
}

/* PATCH: every trap handler used to loop forever with the coils and
   injectors left exactly as they were. Mid-dwell that cooks a coil;
   mid-injection it holds an injector open. Safe state first. */
static void failSafe(void){
	T4R=0; T3R=0;
	P2 |= 0x03;  DP2 &= ~0x03;          /* coils off             */
	CCM7 &= 0xF00F;                     /* disarm injector ends  */
	P7 |= 0x0060; DP7 &= ~0x0060;       /* injectors off         */
	P8 |= (1<<7);                       /* fuel pump relay off   */
	CC19 = 60927;                       /* boost solenoid off (original polarity) */
}

void NMI2(void) interrupt NMI_Interrupt {
	failSafe();
	while(1){
		S0TIC&=0x7F;
	S0RIC&=0x7F;
	S0TBUF='1';
	while ((!S0RIR)); //we test for the byte received flag instead of byte written
	S0TIC&=0x7F;
	S0RIC&=0x7F;
	}	
}

void StackOverflow(void) interrupt StackOverflow_Interrupt {
	failSafe();
	while(1){
		S0TIC&=0x7F;
	S0RIC&=0x7F;
	S0TBUF='2';
	while ((!S0RIR)); //we test for the byte received flag instead of byte written
	S0TIC&=0x7F;
	S0RIC&=0x7F;
	}}	

void StackUnderflow(void) interrupt StackUnderflow_Interrupt {
	failSafe();
		while(1){
		S0TIC&=0x7F;
	S0RIC&=0x7F;
	S0TBUF='3';
	while ((!S0RIR)); //we test for the byte received flag instead of byte written
	S0TIC&=0x7F;
	S0RIC&=0x7F;
}}
void HardwareTrap(void) interrupt HardwareTrap_Intrrupt {
	failSafe();
		while(1){
		S0TIC&=0x7F;
	S0RIC&=0x7F;
	S0TBUF='4';
	while ((!S0RIR)); //we test for the byte received flag instead of byte written
	S0TIC&=0x7F;
	S0RIC&=0x7F;
}}


void timer2_isr(void) interrupt TIMER2_INTERRUPT {
    // Timer 2 interrupt service routine
    // Clear interrupt request
    T2IC = (T2IC & 0xFFF0) | 0x0004;
	if (WDTinitialdelay==1){
			WDTinitialdelay=0;
			T2 =ResponseBuffer[0] ; //the initial query pulse width, the wdt will reply with its own pulsewidth
			//set WDT line low
			P2 &= ~0x0020; //this should be low for the above query time
			return;
		}
	if (WDTdelayperiod==1){//we're just delaying getting ready for our next pulse
		WDTdelayperiod=0; //clear the flag, that time has elapsed!
		//set the port to an output
			DP2 |= 0x0020; //set port 2.5 to as output
		//set port low
			P2 &= ~0x0020;
		//set up T2 with the response duration
			T2 =ResponseBuffer[0] ; //
			CC5IC &= ~0x80;
			WDTmodeListen=0; //
			return;
	}
		if (WDTmodeListen==0){ //we've just elapsed our send pulse width timer, raise the line and setup for a listen
			//set WDT line high
			P2 |= 0x0020;
			T2R = 0;// Stop timer 2, we'll start it on the falling edge of p2.5 now that we're listening
			WDTmodeListen=1;
			DP2 &= ~0x0020; //set port 2.5 to as input
			CC5IC &= ~0x80;
	    CC5IE = 1;   // enable Enable CC5 interrupt
			return;
		}
}

void CC5_ISR(void) interrupt 21
{

	
	if (WDTmodeListen==0) return;
	
	if (WDTmodeListen==1){ //we're expecting a pulse from the WDT, lets check if it's begun (falling edge)
		if ((P2&0x0020)==0){//pin is low
			//zero and start timer T2
			T2=0xFFFF;
			T2R = 1; 
		}
		else if ((P2&0x0020)==0x0020){//pin is high
			//stop the timer
			T2R = 0; 
			WDT_RX_PW=0xFFFF - T2; //get the pulse width of the WDT's response
			T2=30000-WDT_RX_PW;	//we need to start a delay timer for 20ms - rx pulse width
			T2R = 1; //start the timer
			WDTdelayperiod=1;//we're just delaying, make it known.
			//calculate the appropreate response to the WDT's query
			if ((WDT_RX_PW > 6000) && (WDT_RX_PW < 6650)) WDTResponse=12237-100;// 4.22638 >> 8.15802 == 6339 >> 12237
			else if ((WDT_RX_PW > 6650) && (WDT_RX_PW < 7000)) WDTResponse=7642-100;// 4.48566 >> 5.0945 == 6728 >> 7642
			else if ((WDT_RX_PW > 7000) && (WDT_RX_PW < 7300)) WDTResponse=9983-100;// 4.74308 >> 6.65572 == 7115 >> 9983
			else if ((WDT_RX_PW > 7300) && (WDT_RX_PW < 7700)) WDTResponse=8077-100;// 5.01306 >> 5.38508 == 7519 >> 8077
			else if ((WDT_RX_PW > 7700) && (WDT_RX_PW < 8200)) WDTResponse=13497-100;// 5.29926 >> 8.99806 == 7949 >> 13497
			else if ((WDT_RX_PW > 8200) && (WDT_RX_PW < 8600)) WDTResponse=12851-100;// 5.5979 >> 8.56748 == 8397 >> 12851
			else if ((WDT_RX_PW > 8600) && (WDT_RX_PW < 9100)) WDTResponse=14158-100;// 5.902 >> 9.4388 == 8853 >> 14158
			else if ((WDT_RX_PW > 9100) && (WDT_RX_PW < 9500)) WDTResponse=10509-100;// 6.2243 >> 7.0065 == 9336 >> 10509
			else if ((WDT_RX_PW > 9700) && (WDT_RX_PW < 10000)) WDTResponse=7222-100;// 6.56086 >> 4.81456 == 9841 >> 7222
			else if ((WDT_RX_PW > 10000) && (WDT_RX_PW < 10700)) WDTResponse=6440-100;// 6.9078 >> 4.29354 == 10361 >> 6440
			else if ((WDT_RX_PW > 10700) && (WDT_RX_PW < 11000)) WDTResponse=9474-100;// 7.26654 >> 6.31584 == 10900 >> 9474
			else if ((WDT_RX_PW > 11200) && (WDT_RX_PW < 11800)) WDTResponse=11066-100;// 7.6425 >> 7.37702 == 11464 >> 11066
			else if ((WDT_RX_PW > 11800) && (WDT_RX_PW < 12200)) WDTResponse=8527-100;// 8.03452 >> 5.68488 == 12052 >> 8527
			else if ((WDT_RX_PW > 12500) && (WDT_RX_PW < 13000)) WDTResponse=11636-100; //8.44534mS > 7.7576 == 12668 > 11636
			else if ((WDT_RX_PW > 13000) && (WDT_RX_PW < 13600)) WDTResponse=8993-100;// 8.86936 >> 5.99528 == 13304 > 8993
			else if ((WDT_RX_PW > 13800) && (WDT_RX_PW < 14100)) WDTResponse=6831-100;// 9.30801 >> 4.55406  == 13962 >> 6831
			else WDTResponse=7642;
			ResponseCounter++;
			if (ResponseCounter==16){ //we need to send a bad response every 16th to keep it happy
				ResponseCounter=0;
				WDTResponse=10813;
			}

			ResponseBuffer[2]=WDTResponse;
			ResponseBuffer[0]=ResponseBuffer[1];
			ResponseBuffer[1]=ResponseBuffer[2];
		}
	}

		
}