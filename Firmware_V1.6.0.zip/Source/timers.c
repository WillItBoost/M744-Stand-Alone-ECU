#include "reg167.h"

/*==========================================================================
  PATCH: interrupt priorities.
  C167CR User Manual 5-8: "All interrupt request sources that are enabled
  and programmed to the same priority level must always be programmed to
  different group priorities. Otherwise an incorrect interrupt vector will
  be generated."
  The original had four collisions:
      ILVL 1  GLVL 1   T6, T1 and CC19        (the boost dropouts)
      ILVL 9  GLVL 1   CC6, CC7, CC8, CC9     (all four spark compares)
      ILVL 6  GLVL 2   CC29, CC30             (both injector ends)
      ILVL 13 GLVL 0   T3, T4                 (both fine angle timers)
  Every enabled source now has a unique pair. Relative order is unchanged.

    source   ILVL GLVL        source   ILVL GLVL
    T4        13   1          ADC        8   0
    T3        13   0          CC30       6   2
    CC15      11   3          CC29       6   1
    CC6        9   3          S0 RX      5   1   (Serial.c, now constant)
    CC7        9   2          T1         2   1
    CC8        9   1          T6         1   1
    CC9        9   0          CC19       1   0
==========================================================================*/
#define IC(ilvl,glvl)  (0x40 | ((ilvl)<<2) | (glvl))

void timer_init(void) {
    // Configure Timer 2
    //T2CON = 0x0000;    // Stop Timer 2 and clear configuration
    //T2IC = 0x0000;     // Clear Timer 2 interrupt request
    //T2IE = 0x0002;     // Enable Timer 2 interrupt
    //T2 =16472 ; //the initial high pulse width
    //T2CON |= 0x00C1;   // Set Timer 2 to reload mode
    //T2R = 0;           // Stop timer 2
		//T2IC = (T2IC & 0xFFF0) | 0x0019;
		CCM1 &= 0xFF0F;
		CCM1 |= 0x0030;
	    // Configure CAPCOM1 Channel 5 (CC5) - used for security module communication
    //CC5IC = 0x15;    // Set interrupt priority to the highest level
    //CC5IE = 0;       // disable Enable CC5 interrupt
		//set up T7 as a free running timer, /16 prescale, 21.84mS maximum PW. Used for Injection timing
    T7IC = 0x0000;     // Clear Timer 2 interrupt request
    T7 =0 ; //the initial high pulse width
    T78CON |= 0x0041;   // PATCH: bit 7 is reserved in T78CON (manual 15-5); was 0x00C1
    T7R = 1;           // Start timer 2
		CC30IC=IC(6,2); //CC30 is used for injector1   PATCH: was 0x1A, same pair as CC29
		CC29IC=IC(6,1);//CC29 is used for injector2
//		CC28IC=0x1A;//CC28 is used for injector3
//		CC28IE=1;
//		CC23IC=0x1A;//CC23 is used for injector4
//		CC23IE=1;

		CC0IC=0x00;   // PATCH: empty handlers, were enabled at ILVL 10 for no reason
		CC1IC=0x00;


//Setup T0 to count pulses, we'll use this to detect the 60th tooth as TDC
    T0IC = 0x0000;     // Clear Timer 0 interrupt request
    T0 =0 ; //the initial high pulse width
		T01CON=0x0049; //Counter, pos edge at T0, Running.
    T0R = 1;           // Start timer 0
		
//We'll use CC4 to test for the 60th edge and trigger an interrupt
    CC4IC = 0x00;    // PATCH: empty handler, and 0x26 (ILVL 9 GLVL 2) would now collide with CC7
		CC4=ActualTeeth ; //trigger at << tooth count
		CCM1 &= 0xFFF0;
		CCM1 |= 0x0004;


//Setup T1 as a /8 counter. We'll use this to measure tooth to tooth pulse widths
    T1IC = 0x0000;     // Clear Timer 0 interrupt request
    T1 =0 ; //the initial high pulse width
		T01CON=0x4149; //Counter, pos edge at T0, Running. 4149=/16, 4049=/8
		//Start the engine on /16 for a lower RPM tooth detection, once idling we'll increase to /8
		T1IC = IC(2,1);    // PATCH: stall detect, was ILVL 1 GLVL 1 colliding with T6 and CC19

//CC15 is also the trigger wheel input, we'll set up an interrupt on this edge to check for RPM and missing teeth

#define CC16GLVL 3
#define CC16ILVL 11
#define CC16IEbit 1
		CC15IC=(CC16IEbit << 6) | (CC16ILVL << 2) | (CC16GLVL & 0x03) | ((CC16GLVL & 0x04)<<6); //0x24;//interrupt priority 
		CC15IE=1;
		CCM3 &= 0x0FFF;
		CCM3 |= 0x1000;
		
		
//T4 - used for angular triggering of spark 1
    T4IC = 0x0000;     // Clear Timer 4 interrupt request
    T4 = 0 ; //the initial high pulse width
    T4CON |= 0x0081;   // Set Timer 4 to reload mode, stopped //80=/8, 81=/16
		T4IC = IC(13,1);   // PATCH: was ILVL 13 GLVL 0, same pair as T3

//CC6 (Dwell start) will be used for the course timing interrupt (6deg per tooth etc)
    CC6IC = IC(9,3); // PATCH: CC6..CC9 all shared ILVL 9 GLVL 1
		CC6=30 ; //trigger at << tooth count - we'll use 30 for now
		CCM1 &= 0xF0FF;
		CCM1 |= 0x0400;
//CC7 (Dwell end [spark fire]) will be used for the course timing interrupt (6deg per tooth etc)
    CC7IC = IC(9,2);
		CC7=30 ; //trigger at << tooth count - we'll use 30 for now
		CCM1 &= 0x0FFF;
		CCM1 |= 0x4000;


//Spark channel 2
		
//T3 - used for angular triggering of spark 2
    T3IC = 0x0000;     // Clear Timer 4 interrupt request
    T3 = 0 ; //the initial high pulse width
    T3CON |= 0x0081;   // Set Timer 4 to reload mode, stopped
		T3IC = IC(13,0);

//CC8 (Dwell start) will be used for the course timing interrupt (6deg per tooth etc)
    CC8IC = IC(9,1);
		CC8=30 ; //trigger at << tooth count - we'll use 30 for now
		CCM2 &= 0xFFF0;
		CCM2 |= 0x0004;
//CC9 (Dwell end [spark fire]) will be used for the course timing interrupt (6deg per tooth etc)
    CC9IC = IC(9,0);
		CC9=30 ; //trigger at << tooth count - we'll use 30 for now
		CCM2 &= 0xFF0F;
		CCM2 |= 0x0040;


//T6 is used for the 100hz loop
#define T6GLVL 1
#define T6ILVL 1
#define T6IEbit 1
//Timer 6 will be the main loop timer (10mS / 100hz)
    T6IC = 0x0000;     // Clear Timer 4 interrupt request
    T6IE = 0x0002;     // Enable Timer 4 interrupt
    T6 = 0 ; //the initial high pulse width
		CAPREL = 0x186;//0x9898;
		T6CON |= 0x80C7;   // Set Timer 4 to reload mode, running
		T6IC =  (T6IEbit << 6) | (T6ILVL << 2) | (T6GLVL & 0x03) | ((T6GLVL & 0x04)<<6); //


//we'll use 10 and 11 for injector firing.

//PWM Timer for boost control etc
T8REL=60926; //Change this to adjust PWM Freq
T78CON |= 0x4400; //128 prescale, running
CCM4 |= 0xF000; //Mode 1 PWM, Timer8 used for CC19
CC19 = 60927 + (0*18);//set default pwm to 0%

#define cc19GLVL 0   // PATCH: was 1, colliding with T6 (and T1) - the boost dropouts
#define cc19ILVL 1
#define cc19IEbit 1
CC19IC = (cc19IEbit <<6) | (cc19ILVL <<2) | (cc19GLVL & 0x03) | ((cc19GLVL & 0x04)<<6);

}

#define CC19_Interrupt 0x33
extern unsigned char BoostDuty;
extern unsigned char *MinTPS4Boost;
extern unsigned char TPS;
//update the boost duty only after last trigger
void CC19InterruptPWM(void) interrupt CC19_Interrupt
{
			if (MinTPS4Boost[0] < TPS)			CC19 = 60927u + (unsigned int)BoostDuty*18u;// v0.9.1: 'u' keeps it 16 bit (was promoted to long -> C192). Same value.
			else 	CC19 = 60927u; //0 percent duty
}