/*==========================================================================
  temp_tables.h
  Move your two 1024 entry lookup tables into temp_tables.c unchanged,
  but declare them as:

      const signed char IAT_table[1024] = { ... };
      const signed char CLT_table[1024] = { ... };

  They were "static char ...[1024]" with no const, which put 2kB of
  constant data in RAM.  Add  #include "temp_tables.h"  at the top of
  temp_tables.c so the declarations are checked.

  While you are there, count the initialisers.  A short list is accepted
  silently by the compiler and zero fills the rest, which would read 0 C
  at the cold end of the scale.
==========================================================================*/
#ifndef __TEMP_TABLES_H__
#define __TEMP_TABLES_H__
extern const signed char IAT_table[1024];
extern const signed char CLT_table[1024];
#endif