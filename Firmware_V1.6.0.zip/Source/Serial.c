#include "reg167.h"
#include "main.h"
/*
Serial packet format:
Header Length Payload Checksum

Header=0xAA
Lenght=length of payload, not including checksum or header
Checksum = byte val of lenght plus byte val of every payload byte. Does not include the header byte.

e.g. 0xAA 0x01 0x55 0x56


*/

#define S0RX_Interrupt 0x2B
#define HEADER_BYTE 0xAA
#define MAX_DATA_LENGTH 32
#define OK 0
#define ERROR 1

unsigned char rxBuffer[MAX_DATA_LENGTH];
unsigned char rxBufferIndex = 0;
unsigned char receiving = 0; // Use 0 (false) and 1 (true) instead of bool
unsigned char validPacketReceived=0;
extern volatile unsigned char EEPROMbuffer[32];
extern void copy_FH_to_memory();
extern void jump_to_FH();
extern volatile unsigned char EEPROMbuffer[];	
extern char TPSLearnFlag;

extern unsigned int RPM;
extern unsigned int KPA;
extern unsigned int RequestedTiming;
extern unsigned int adc_raw[NUM_ADC_CHANNELS];
extern unsigned int totalInjectorPW;
extern unsigned char Wideband;
extern unsigned char VE;
extern unsigned char reqAFR;
extern unsigned char AFR;
extern unsigned char TPS;
extern char IAT;
extern unsigned char CLT;
unsigned int shaddowRPM; //to keep both upper and lower bytes the same during serial tx
unsigned char SerialSendPos=0;
unsigned char AdcSendPos=0;   /* PATCH: monitor and ADC frames shared one counter */
unsigned char SendMonitor=0;
unsigned char SendADC=0;
unsigned int RevLimitValue;//=RevLimit[0]<<8)|(RevLimit[1]);
extern unsigned int TPSmax;
extern unsigned int TPSmin;
extern unsigned char BoostDuty;
extern unsigned char MAPSensorType;
extern unsigned int voltage;
extern unsigned char flags;
extern unsigned char EngineStalled;
extern unsigned int TDCoffset; 
extern unsigned int BaseFuel;
extern unsigned int InjFlow;
extern unsigned int dwellTable[];
extern unsigned int IDTTable[];
extern unsigned int dwellUs;
extern unsigned int InjectorDeadTime;
extern int StepperPosition;
extern int RequestedSteps;
extern volatile unsigned int KPAtableNA[16];
extern volatile unsigned int KPAtableBoost[16];
extern volatile unsigned int rpmScale[16];

extern unsigned char	CrankEnrichDecayCount;
extern unsigned char	FanCutInTemp;
extern unsigned char	FanCutOutTemp;
extern unsigned char TPSlearnTimer;
extern int DeltaTPS;
extern char LossOfSyncCount;
 unsigned int ReferenceTiming;
 
extern unsigned char VElearn;
unsigned char Flags1=0;
extern unsigned char EEPROMflags;
extern unsigned char IAChomeCount;
extern unsigned char IAChomeCountShadow;
extern unsigned int FuelingInjectorPW;
void refreshEEPROMparamaters(){
	
			eeprom_read(0,16); //read 32 bytes from address 0x0000.	
			TDCoffset=(EEPROMbuffer[0]<<8) + EEPROMbuffer[1]; //load the TDC offset from the eeprom, address 0:1, 16bit value.
			ReferenceTiming=EEPROMbuffer[3]; //12deg + 10deg offset = 22deg
			MAPSensorType=EEPROMbuffer[4]; //map sensor table to use
			/* PATCH: don't reload TPS min/max while a learn is running. This is
			   called straight after the learn resets them, so it used to undo
			   the reset - a re-learn could only ever widen the range. */
			if (TPSlearnTimer==0){
				TPSmin=(EEPROMbuffer[0x0B]<<8) + EEPROMbuffer[0x0C];
				TPSmax=(EEPROMbuffer[0x0D]<<8) + EEPROMbuffer[0x0E];
			}
			if (MAPSensorType==0 || MAPSensorType>6) MAPSensorType=1;   /* PATCH: same check as boot */
			
		EEPROMflags=EEPROMbuffer[2];
	IAChomeCount=EEPROMbuffer[5]; //number of steps to fully close the IAC valve
	IAChomeCountShadow=IAChomeCount;


}


void serialSend(unsigned char b){
	unsigned int t = SERIAL_TIMEOUT;   /* PATCH: a shorted/open K-line hung here forever */

	S0TIC&=0x7F;
	S0RIC&=0x7F;
	S0TBUF=b;
	while ((!S0RIR) && --t); //we test for the byte received flag instead of byte written
	S0TIC&=0x7F;
	S0RIC&=0x7F; //clear the rx byte so we don't act on our last sent byte (half-duplex)

	

}
char serialWait4Byte(){
	while (!S0RIR);
	S0RIC&=0x7F;
	return S0RBUF;
}

void resetBuffer(void) {
    rxBufferIndex = 0;
    receiving = 0;
}

void sendSimpleResponse(unsigned char payload){
	S0RIC = 0x00; //disable serial interrupts to prevent it talking to itself
	serialSend(0x55); //response header
	serialSend(0x01);//length of data
	serialSend(payload);//the data
	serialSend(payload+0x01);//checksum
	S0RIC = 0x55;	
}

void sendStringResponse(unsigned char *string){
	unsigned char chrcount=0;
	unsigned char string2[32];
	unsigned char checksum=0;
	unsigned char i;
	S0RIC = 0x00;
	while (*string!=0x00 && chrcount<31){   /* PATCH: bounded to string2[] */
		string2[chrcount]=*string;
		string++;
		chrcount++;
	}
	checksum=chrcount;   /* PATCH: every other reply includes the length byte in its checksum; this one didn't */
	serialSend(0x55); //response header
	serialSend(chrcount); //length
	for (i=0;i<chrcount;i++){
		serialSend(string2[i]);
		checksum+=string2[i];
	}
	serialSend(checksum);	
	S0RIC = 0x55;
}

void sendEEPacket(unsigned char lenght){
	unsigned char checksum=lenght;
	unsigned char i;
	S0RIC = 0x00;
	serialSend(0x55); //response header
	serialSend(lenght); //length
	for (i=0;i<lenght;i++){
		serialSend(EEPROMbuffer[i]);
		checksum+=EEPROMbuffer[i];
	}
	serialSend(checksum);	
	S0RIC = 0x55;
}

void sendRAMPacket(unsigned int address, unsigned char lenght){
	unsigned char checksum=lenght;
	unsigned char i;
	volatile unsigned char *RAM = (unsigned char *)StartOfMapArea_RAM;
	if (address >= 0x2000) return;                                   /* PATCH: bounds */
	if ((unsigned long)address + lenght > 0x2000UL) lenght = (unsigned char)(0x2000U - address);
	S0RIC = 0x00;
	serialSend(0x55); //response header
	serialSend(lenght); //length
	for (i=0;i<lenght;i++){
		serialSend(RAM[address+i]);
		checksum+=RAM[address+i];
	}
	serialSend(checksum);	
	S0RIC = 0x55;
}

void sendEEPROMpacket(unsigned int address, unsigned char lenght){
	unsigned char checksum=lenght;
	unsigned char i;
	address-=0x2000;
	S0RIC = 0x00;
	serialSend(0x55); //response header
	serialSend(lenght); //length
	eeprom_read(address,lenght);
	for (i=0;i<lenght;i++){
		serialSend(EEPROMbuffer[i]);      /* PATCH: was [address+i] - wrong bytes for any */
		checksum+=EEPROMbuffer[i];        /* address other than 0x2000, and out of bounds */
	}
	serialSend(checksum);	
	S0RIC = 0x55;
}




void sendMonitorPacket(){
	S0RIC = 0x00; //don't process you're own trasnmissions due to half-duplex

	/*
		16bit RPM Value
		16bit Requested Timing
		16bit Injector PW
		16bit MAP kPa
		8bit VE
		8bit Req AFR
		8bit AFR
		8bit TPS
		8bit IAT
		8bit CLT
		8bit vBatt		
		*/
		if (SerialSendPos==0){
			shaddowRPM=RPM;
			serialSend(shaddowRPM>>8);		//send upper byte of RPM
		}
		else if (SerialSendPos==1) serialSend(shaddowRPM&0xFF);//send lower byte of RPM
		else if (SerialSendPos==2) serialSend(RequestedTiming>>8);		//send upper byte of RequestedTiming
		else if (SerialSendPos==3) serialSend(RequestedTiming&0xFF);//send lower byte of RequestedTiming
		else if (SerialSendPos==4) serialSend(FuelingInjectorPW>>8);		//send upper byte of totalInjectorPW
		else if (SerialSendPos==5) serialSend(FuelingInjectorPW&0xFF);//send lower byte of totalInjectorPW
		else if (SerialSendPos==6) serialSend(KPA>>8); //16bit scaled MAP in kPa
		else if (SerialSendPos==7) serialSend(KPA&0xFF); //16bit scaled MAP in kPa
		else if (SerialSendPos==8) serialSend(VE); //Calculated VE value
		else if (SerialSendPos==9) serialSend(reqAFR); //Requested AFR
		else if (SerialSendPos==10) serialSend(Wideband); /* v0.9.3: was the AFR variable, which
		                                                     nothing has written since the wideband
		                                                     code went in - it sent a constant 14.7.
		                                                     Byte 25 is unchanged, so the ADX needs
		                                                     no edit and both AFR rows now read alike. */
		else if (SerialSendPos==11) serialSend(TPS); //scaled TPS
		else if (SerialSendPos==12) serialSend(IAT); //scaled IAT
		else if (SerialSendPos==13) serialSend(CLT); //scaled CLT
		else if (SerialSendPos==14) serialSend(voltage>>3); //vBatt scaled to 8bit
		else if (SerialSendPos==15) serialSend(InjectorDeadTime>>8);		//send upper byte of totalInjectorPW
		else if (SerialSendPos==16) serialSend(InjectorDeadTime&0xFF);//send lower byte of totalInjectorPW
		else if (SerialSendPos==17) serialSend(dwellUs>>8);		//send upper byte of dwellUs
		else if (SerialSendPos==18) serialSend(dwellUs&0xFF);//send lower byte of dwellUs
		else if (SerialSendPos==19) serialSend((RequestedSteps));//send lower byte of dwellUs
		else if (SerialSendPos==20) serialSend(flags);//send lower byte of dwellUs
		else if (SerialSendPos==21) serialSend(LossOfSyncCount);//send lower byte of dwellUs
		else if (SerialSendPos==22) serialSend(DeltaTPS>>8);//send upper byte of deltatps
		else if (SerialSendPos==23) serialSend(DeltaTPS);//send upper byte of deltatps
		else if (SerialSendPos==24) serialSend(BoostDuty); //Flag Variable
	
		else if (SerialSendPos==25) serialSend(Wideband); //Flag Variable
		/* PATCH v0.7: three new bytes - needs the v0.7 ADX (packet 29 bytes) */
		else if (SerialSendPos==26) {                           /* idle fuel trim, 0.2% per count, signed */
			int t = IdleFuelTrim / 20;
			serialSend((unsigned char)(signed char)t);
		}
		else if (SerialSendPos==27) serialSend(IdleCLStatus);  /* bit0 enabled 1 applying 2 learning 3 WB valid 4 capture 5-6 sync */
		else if (SerialSendPos==28) {
			serialSend(SparkLatencyMax);                        /* worst spark ISR latency since last frame, 0.8us per count */
			SparkLatencyMax=0;
		}
		else if (SerialSendPos==29) {                           /* v0.9.1: STFT table trim, 0.2% per count, signed */
			serialSend((unsigned char)STFTapplied);
			SerialSendPos=0;
			SendMonitor=0;
			S0RIC = 0x55;
			return;
		}
		SerialSendPos++;

		
	S0RIC = 0x55;	
}



void sendADCPacket(){
	S0RIC = 0x00; //don't process you're own trasnmissions due to half-duplex
 
	/*
		16bit RPM Value
		16bit Requested Timing
		16bit Injector PW
		16bit MAP kPa
		8bit VE
		8bit Req AFR
		8bit AFR
		8bit TPS
		8bit IAT
		8bit CLT
		8bit vBatt		
		*/
		if (AdcSendPos==0){
			shaddowRPM=RPM;
			serialSend(adc_raw[0]>>8);		//send upper byte of RPM
		}
		else if (AdcSendPos==1) serialSend(adc_raw[0]);//
		else if (AdcSendPos==2) serialSend(adc_raw[1]>>8);//
		else if (AdcSendPos==3) serialSend(adc_raw[1]);//
		else if (AdcSendPos==4) serialSend(adc_raw[2]>>8);//
		else if (AdcSendPos==5) serialSend(adc_raw[2]);//
		else if (AdcSendPos==6) serialSend(adc_raw[3]>>8);//
		else if (AdcSendPos==7) serialSend(adc_raw[3]);//
		else if (AdcSendPos==8) serialSend(adc_raw[4]>>8);//
		else if (AdcSendPos==9) serialSend(adc_raw[4]);//
		else if (AdcSendPos==10) serialSend(adc_raw[5]>>8);//
		else if (AdcSendPos==11) serialSend(adc_raw[5]);//
		else if (AdcSendPos==12) serialSend(adc_raw[6]>>8);//
		else if (AdcSendPos==13) serialSend(adc_raw[6]);//
		else if (AdcSendPos==14) serialSend(adc_raw[7]>>8);//
		else if (AdcSendPos==15) serialSend(adc_raw[7]);//
		else if (AdcSendPos==16) serialSend(adc_raw[8]>>8);//
		else if (AdcSendPos==17) serialSend(adc_raw[8]);//
		else if (AdcSendPos==18) serialSend(adc_raw[9]>>8);//
		else if (AdcSendPos==19) serialSend(adc_raw[9]);//
		else if (AdcSendPos==20) serialSend(adc_raw[10]>>8);//
		else if (AdcSendPos==21) serialSend(adc_raw[10]);//
		else if (AdcSendPos==22) serialSend(adc_raw[11]>>8);//
		else if (AdcSendPos==23) serialSend(adc_raw[11]);//
		else if (AdcSendPos==24) serialSend(adc_raw[12]>>8);//
		else if (AdcSendPos==25) serialSend(adc_raw[12]);//
		else if (AdcSendPos==26) serialSend(adc_raw[13]>>8);//
		else if (AdcSendPos==27) serialSend(adc_raw[13]);//
		else if (AdcSendPos==28) serialSend(adc_raw[14]>>8);//
		else if (AdcSendPos==29) serialSend(adc_raw[14]);//
		else if (AdcSendPos==30) serialSend(adc_raw[15]>>8);//
 
		else if (AdcSendPos==31) {
			serialSend(adc_raw[15]); //Flag Variable
			AdcSendPos=0;
			SendADC=0;
			S0RIC = 0x55;
			return;
		}
		AdcSendPos++;
 
 
	S0RIC = 0x55;
 
 
 
}
 
 

 

extern void InjectorTest(unsigned int count, unsigned int duration);   /* PATCH: defined void (L20 warning) */

void processPacket() {
	unsigned char i;
	unsigned int duration;
	unsigned int count;
    // This is the main serial handler function. If this function is called we have received a checksum verified packet.
    // ...

	if (EngineStalled==1){ //only process these when the engine is off!
		if (rxBuffer[2]==0x08){ //CMD 0x08 - Hardware Test Mode
			if (rxBuffer[3]==0x00){ //CMD 0x08 00 - Hardware Test Injectors
				count=(rxBuffer[4]<<8)|rxBuffer[5];
				duration=(rxBuffer[6]<<8)|rxBuffer[7];
				InjectorTest(count,duration);
			}
			sendSimpleResponse(OK);
		}
	}
	
	if (rxBuffer[2]==0x00){ //CMD 0x00 - Get FW version
		sendStringResponse("BV7.4.4 v1.6.0 STFT\0");   /* v1.6.0 - still exactly 19 characters */   /* PATCH: must stay 19 characters - your TunerPro plugin checks the length */   /* PATCH: bumped so you can tell the patched build apart */
	}


	if (rxBuffer[2]==0x01){ //CMD 0x01 - Enter flash update mode
			/* PATCH: refused unless the engine is stopped. Entering the flash
			   handler kills every interrupt, so a running engine would be left
			   with whatever the coils and injectors were doing. */
			if (EngineStalled==1 && RPM==0){
				sendSimpleResponse(OK);
				copy_FH_to_memory();
				jump_to_FH();
			} else sendSimpleResponse(ERROR);
		}
		 if (rxBuffer[2]==0x02){ //CMD 0x02 - Read EERPOM aaaa ll l<=32
			eeprom_read(((rxBuffer[3]<<8)|(rxBuffer[4])),32);
			sendEEPacket(rxBuffer[5] > 32 ? 32 : rxBuffer[5]);//send x bytes from the eeprom buffer   PATCH: capped
		}
	
	//}

	

	else if (rxBuffer[2]==0x03){ //CMD 0x03 - Write EERPOM aaaa ll dddddd......
		/* PATCH: the length was trusted - a valid-checksum frame could write
		   past EEPROMbuffer or read past rxBuffer */
		if (rxBuffer[5] > 25 || rxBuffer[1] < (unsigned char)(rxBuffer[5]+4)) { sendSimpleResponse(ERROR); }
		else {
			for (i=0;i<rxBuffer[5];i++)	EEPROMbuffer[i]=rxBuffer[i+6];
			eeprom_write((rxBuffer[3]<<8)|(rxBuffer[4]),rxBuffer[5]);
			sendSimpleResponse(OK);
		}
	}
	else if (rxBuffer[2]==0x04){ //CMD 0x04 - Read RAM MAP Data aaaa ll l<=32
		unsigned int address=(rxBuffer[3]<<8)|(rxBuffer[4]);
		if (address<0x2000){
			sendRAMPacket((rxBuffer[3]<<8)|(rxBuffer[4]),rxBuffer[5]);//send x bytes from the external SRAM
		}
		else
		{
				sendEEPROMpacket((rxBuffer[3]<<8)|(rxBuffer[4]),rxBuffer[5]);
					
				
			//read from eeprom instead
		}
	}
	else if (rxBuffer[2]==0x05){ //CMD 0x05 - Write RAM MAP Data aaaa ll dddddd......
		volatile unsigned char *RAM = (unsigned char *)StartOfMapArea_RAM;
		unsigned int address=(rxBuffer[3]<<8)|(rxBuffer[4]);
		
		/* PATCH: bounds */
		if (rxBuffer[5] > 25 || rxBuffer[1] < (unsigned char)(rxBuffer[5]+4)) { sendSimpleResponse(ERROR); goto cmd05_done; }
		if (address<0x2000){
			if ((unsigned long)address + rxBuffer[5] > 0x2000UL) { sendSimpleResponse(ERROR); goto cmd05_done; }
			for (i=0;i<rxBuffer[5];i++){
				RAM[address+i]=rxBuffer[i+6];
			}
		}
		else
		{
			for (i=0;i<rxBuffer[5];i++){
				EEPROMbuffer[i]=rxBuffer[i+6];
			}
			//if (EngineStalled==1){ //only process these when the engine is off!
				if ((address==0x200A)&&(EEPROMbuffer[0x00]&0x01)==0x01){//TPS learn requested
					TPSmax=0;
					TPSmin=0xFFFF;
					TPSlearnTimer=5;
					TPSLearnFlag=1;
					EEPROMbuffer[0x00]&=0xFE;//cler the bit   PATCH: was [0x0A], not the byte being written
				}
				eeprom_write(address - 0x2000,rxBuffer[5]);
				//write to eeprom instead
				refreshEEPROMparamaters();
			//}
			}
		
		if ((address>0xEFF)&&(address<0x1000)){
			RevLimitValue=(RAM[0xFF0]<<8)|(RAM[0xFF1]);
			for (i=0;i<8;i++){
				dwellTable[i]=((RAM[0xF60+(i*2)]<<8)|RAM[0xF61+(i*2)]);
			}
			for (i=0;i<8;i++){
				IDTTable[i]=((RAM[0xF70+(i*2)]<<8)|RAM[0xF71+(i*2)]);
			}
			
				for (i=0;i<16;i++){
				KPAtableNA[i]=((RAM[0xF20+(i*2)]<<8)|RAM[0xF21+(i*2)]);
			}
				for (i=0;i<16;i++){
				KPAtableBoost[i]=((RAM[0xF40+(i*2)]<<8)|RAM[0xF41+(i*2)]);
			}
				for (i=0;i<16;i++){
				rpmScale[i]=((RAM[0xF00+(i*2)]<<8)|RAM[0xF01+(i*2)]);
			}
				
			BaseFuel=(RAM[0xFF2]<<8)|(RAM[0xFF3]);
			CrankEnrichDecayCount=(RAM[0xFF4]);
			FanCutInTemp=(RAM[0xFF5]);
			FanCutOutTemp=(RAM[0xFF6]);
		}		
		sendSimpleResponse(OK);
cmd05_done: ;
	}		
	
	
	if (rxBuffer[2]==0x06){ //CMD 0x06 Get ADC values
		sendRAMPacket(0,16);//send x bytes from the external SRAM
	}
	
	/* v0.9.6: CMD 0x20 ff ss - tool control for the idle MBT sweep.
	   ff bit0 = hold the IAC still, bit1 = run spark at ss half-degrees,
	   bit2 = dead-time test (fire every other revolution, fuel doubled).
	   Every one of these renews a 5 s lease; ff = 0 lets go at once. */
	if (rxBuffer[2]==0x20){
		unsigned char f = rxBuffer[3];
		unsigned int  s = rxBuffer[4];
		if (s > TOOL_SPARK_MAX_HALFDEG) s = TOOL_SPARK_MAX_HALFDEG;
		ToolFreezeIAC = (f & 0x01) ? 1 : 0;
		ToolSparkOn   = (f & 0x02) ? 1 : 0;
		ToolSpark     = s;
		ToolAltInject = (f & 0x04) ? 1 : 0;
		ToolNoSP      = (f & 0x10) ? 1 : 0;   /* v1.6.0: small-pulse correction off for the test */
		ToolLease     = f ? TOOL_LEASE_TICKS : 0;
		sendSimpleResponse(OK);
	}
	/* v0.9.9: CMD 0x21 nn pphh ppll - IAC speed test. Move nn steps (signed,
	   + opens) with pppp microseconds between them. Only while a CMD 0x20
	   lease with the IAC held (bit0) is running, so the idle loop is out of
	   the way; replies ERROR otherwise. */
	if (rxBuffer[2]==0x21){
		unsigned int us = ((unsigned int)rxBuffer[4] << 8) | rxBuffer[5];
		if (ToolLease && ToolFreezeIAC){
			if (us < IAC_STEP_MIN_US) us = IAC_STEP_MIN_US;
			if (us > IAC_STEP_MAX_US) us = IAC_STEP_MAX_US;
			ToolIACperiodUs = us;
			ToolIACmove += (signed char)rxBuffer[3];
			sendSimpleResponse(OK);
		}
		else sendSimpleResponse(ERROR);
	}
	/* v1.2.0: CMD 0x23 xx - wideband delay test.
	   01 start (engine running, wideband valid), 00 abort, 02 read back:
	   state, ticks (16 bit, 10 ms each), baseline and current wideband. */
	if (rxBuffer[2]==0x23){
		unsigned char op = rxBuffer[3];
		if (op == 1){
			if (EngineStalled || Wideband < WB_VALID_MIN || Wideband > WB_VALID_MAX || DelayTestState == 1 || DelayTestState == 2) sendSimpleResponse(ERROR);
			else { DelayTestTicks = 0; dtSum = 0; DelayTestFuelStep = 0; DelayTestState = 1; sendSimpleResponse(OK); }
		}
		else if (op == 0){ DelayTestFuelStep = 0; DelayTestState = 0; sendSimpleResponse(OK); }
		else if (op == 2){
			unsigned char st = DelayTestState, th = (unsigned char)(DelayTestTicks >> 8), tl = (unsigned char)DelayTestTicks, b = DelayTestBase, w = Wideband;
			S0RIC = 0x00;
			serialSend(0x55); serialSend(5); serialSend(st); serialSend(th); serialSend(tl); serialSend(b); serialSend(w);
			serialSend((unsigned char)(5 + st + th + tl + b + w));
			S0RIC = 0x55;
		}
		else sendSimpleResponse(ERROR);
	}
	/* v1.3.0: CMD 0x24 xx - accel event log. 01 clears; 02 replies
	   count, lost, then count records of 17 bytes (oldest first) and clears. */
	if (rxBuffer[2]==0x24){
		unsigned char op = rxBuffer[3], i, j, n, cs, b;
		if (op == 1){ aeEvtCount = 0; aeEvtLost = 0; sendSimpleResponse(OK); }
		else if (op == 2){
			n = aeEvtCount;
			S0RIC = 0x00;
			serialSend(0x55); serialSend((unsigned char)(2 + n * AE_EVT_SIZE)); cs = (unsigned char)(2 + n * AE_EVT_SIZE);
			serialSend(n); cs += n; serialSend(aeEvtLost); cs += aeEvtLost;
			for (i = 0; i < n; i++) for (j = 0; j < AE_EVT_SIZE; j++){ b = aeEvt[i][j]; serialSend(b); cs += b; }
			serialSend(cs);
			S0RIC = 0x55;
			aeEvtCount = 0; aeEvtLost = 0;
		}
		else sendSimpleResponse(ERROR);
	}
	if (rxBuffer[2]==0x10){ //CMD 0x10 Send Monitor Frame
		//sendMonitorPacket();
		SendMonitor=1;
	}
	if (rxBuffer[2]==0x11){ //CMD 0x11 Send ADC Frame
		//sendMonitorPacket();
		SendADC=1;
	}
	


	//set it up ready for the next packet
	validPacketReceived=0;
//	resetBuffer();
	  rxBufferIndex = 0; //reset buffer code
    receiving = 0;
}

void parseAndRespond(unsigned char* buffer, unsigned char length) {
    // Check the header byte
	unsigned char checksum = buffer[1]; // Include the length byte in the checksum calculation
	unsigned char i;
  unsigned char payloadLength = buffer[1];
  unsigned char expectedLength = payloadLength + 3; // Payload length + header + length byte + checksum
  if (buffer[0] != HEADER_BYTE) {
        // Invalid header byte, discard the frame
      return;
  }
    // Calculate the checksum
	for (i = 2; i < expectedLength - 1; i++) {
			checksum += buffer[i];
	}
    // Validate the checksum
    if (buffer[length - 1] != checksum) {
        // Invalid checksum, discard the frame
        return;
    }
    // Valid frame received, prepare the response
    validPacketReceived=1; //Flag used to tell the main code loop to action the packet. We don't want to delay an interrupt any longer than necessary
}





void processReceivedByte(unsigned char byte) {
    if (validPacketReceived) return;   /* PATCH: don't overwrite a frame main hasn't processed */
    if (!receiving) {
        // Check for the header byte
        if (byte == HEADER_BYTE) {
            receiving = 1;
            rxBuffer[0] = byte;
            rxBufferIndex = 1;
        }
    } else {
        /* PATCH: MAX_DATA_LENGTH was never enforced. One corrupt length byte let
           rxBufferIndex climb to 258 and write past the 32 byte buffer. */
        if (rxBufferIndex == 1 && byte > (MAX_DATA_LENGTH - 3)) { rxBufferIndex = 0; receiving = 0; return; }
        if (rxBufferIndex >= MAX_DATA_LENGTH) { rxBufferIndex = 0; receiving = 0; return; }
        // Store the received byte
        rxBuffer[rxBufferIndex] = byte;
        rxBufferIndex++;

        // Check if we've received the expected payload length
        if (rxBufferIndex >= 3) {
            unsigned char expectedLength = rxBuffer[1] + 3; // Payload length + header + length byte + checksum
            if (rxBufferIndex == expectedLength) {
                // Process the received frame
                parseAndRespond(rxBuffer, rxBufferIndex);
                //resetBuffer();
            } else if (rxBufferIndex > expectedLength) {
                // Discard the received frame and reset the buffer
                //resetBuffer();
							  rxBufferIndex = 0; //reset buffer code
								receiving = 0;
            }
        }
    }
}


void serialInit(){
	S0BG  = 0x1F;         /* SET BAUDRATE TO 19200 BAUD                    0x26 for 24mhz mcu */
  S0CON = 0x8011;       /* SET SERIAL MODE                               */
	S0RIC = 0x55;
	//resetBuffer();
	rxBufferIndex = 0;
  receiving = 0;
}



void ByteReceived(void) interrupt S0RX_Interrupt {
	processReceivedByte(S0RBUF);
}





