#include "reg167.h" 
volatile unsigned int adc_raw[NUM_ADC_CHANNELS];


/*
	adc channel 0 = MAP / MAF (0-5v) 														-(Grey C1)
	adc channel 1 = Throttle Blade Position 1 (0-5v) 
	adc channel 2 = Rollover Switch (0-5v) 12v pullup 					-(Brown E3)
	adc channel 3 = Throttle Blade Position 2 (0-5v) 12v pullup -(Brown M3)
	adc channel 4 = 
	adc channel 5 = Battery Voltage [0...17V], 1Inc = 0.067V    -Not a single input
	adc channel 6 = Upstream O2 sensor (0-5v)										-(Grey A3)
	adc channel 7 = Downstream O2 sensor (0-5v)									-(Black E3)
	adc channel 8 = Pedal input 1 (0-5v) (TPS)									-(Black B4)
	adc channel 9 = Pedal input 2(0-5v)													-Not Externally Connected
	adc channel 10 = Coolant Temp (Resistive)										-(Black E4)
	adc channel 11 = IAT																				-(Black A2)
	adc channel 12 = 				 																		-Not Externally Connected
	adc channel 13 =  																					-Not Externally Connected
	adc channel 14 = 																					  -Not Externally Connected
	adc channel 15 = 																						-Not Externally Connected
 
*/
 

// Integer array to store ADC results

void init_adc(void) {
    // Configure ADC
    ADCON = 0xF03F;       // ADC control register
    ADCIC |= 0x60;      // Enable ADC interrupt
    ADCON |= 0x0080;    // Start ADC conversion
}

// ADC interrupt service routine
void adc_isr(void) interrupt 0x28 {
    // Clear ADC interrupt request flag
    /* PATCH: ADDAT was read twice. An interrupt landing between the two reads
       could pair one channel's number with another channel's result. */
    unsigned int d = ADDAT;
    ADCIR = 0x00;
    adc_raw[(d >> 12) & 0x0F] = d & 0x3FF;
}


