#include <reg167.h> 
#include "main.h"
/*
Injector 1 = P7.6 (active low)
Injector 2 = P7.5 (active low)
Injector 3 = P7.4 (active low)
Injector 4 = P8.7 (active low)
*/

#define CC30_INTERRUPT 0x45 // 
#define CC29_INTERRUPT 0x44 //
#define CC28_INTERRUPT 0x3C // 
#define CC23_INTERRUPT 0x37 // 

unsigned int totalInjectorPW=3000; //3000 = 2mS
unsigned int FuelingInjectorPW=3000; //3000 = 2mS
extern unsigned char CycleCounter;


void Injector1_isr(void) interrupt CC30_INTERRUPT { //triggered at the end of the injection pulse 
	//disable CC30
		CCM7 &= 0xF0FF;
		P7 |= 0x0040; //set injector output high (Off) - it should already be, but just to be sure to be sure
}
void Injector1_fire(unsigned int pulsewidth){
		if (pulsewidth < MIN_INJ_PW) return;   /* PATCH: too short to deliver fuel, and can miss its compare */
		P7 &=~0x0040; //set injector output low (ON)
		CC30=T7 + pulsewidth;
		CCM7 |= 0x0500;
	  if (CycleCounter<255)CycleCounter++;
}

void Injector2_isr(void) interrupt CC29_INTERRUPT { //triggered at the end of the injection pulse 
	//disable CC29
		CCM7 &= 0xFF0F;
		P7 |= 0x0020; //set injector output high (Off) - it should already be, but just to be sure to be sure
}
void Injector2_fire(unsigned int pulsewidth){
		if (pulsewidth < MIN_INJ_PW) return;   /* PATCH: too short to deliver fuel, and can miss its compare */
		P7 &=~0x0020; //set injector output low (ON)
		CC29=T7 + pulsewidth;
		CCM7 |= 0x0050;
	  if (CycleCounter<255)CycleCounter++;
}


void InjectorTest(unsigned int count, unsigned int duration){
	unsigned int delay;
	while (count>0){
		Injector1_fire(duration); //fire batch1
		Injector2_fire(duration); //fire batch2
		while ((P7 & 0x0060) != 0x60); //wait for the firing to comlete
		for (delay=0;delay<5000;delay++){
			__asm{
				NOP
			}
		}
		count--;
	}
}

//void Injector3_isr(void) interrupt CC28_INTERRUPT { //triggered at the end of the injection pulse 
	//disable CC28
//		CCM7 &= 0xFFF0;
//		P7 |= 0x0010; //set injector output high (Off) - it should already be, but just to be sure to be sure
//}
//void Injector3_fire(unsigned int pulsewidth){
//		P7 &=~0x0010; //set injector output low (ON)
//		CC28=T7 + pulsewidth;
//		CCM7 |= 0x0005;
//}

//void Injector4_isr(void) interrupt CC23_INTERRUPT { //triggered at the end of the injection pulse 
	//disable CC23
//		CCM5 &= 0x0FFF;
//		P8 |= 0x0080; //set injector output high (Off) - it should already be, but just to be sure to be sure
//}
//void Injector4_fire(unsigned int pulsewidth){
//		P8 &=~0x0080; //set injector output low (ON)
//		CC23=T7 + pulsewidth;
//		CCM5 |= 0x5000;
//}

/* PATCH: unconditional safe state, used on stall, trap and flash entry.
   Disarms both compare channels so a pending end-of-pulse cannot fire
   into nothing, then drives both injectors off. */
void injectorsAllOff(void){
		CCM7 &= 0xF00F;   /* disarm CC29 and CC30 */
		P7 |= 0x0060;     /* both injectors off   */
}
