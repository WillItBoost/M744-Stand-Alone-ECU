#include "reg167.h" 
#include "main.h"
/*
Ignition driver 1 = P2.0
Ignition driver 2 = P2.1

*/
#define T3_Interrupt 0x23 // interrupt
#define T4_Interrupt 0x24 // interrupt
#define CC0_INTERRUPT 0x10 // 
#define CC1_INTERRUPT 0x11 //
#define CC6_Interrupt 0x16 //CC6 interrupt
#define CC7_Interrupt 0x17 //CC7 interrupt
#define CC8_Interrupt 0x18 //CC8 interrupt
#define CC9_Interrupt 0x19 //CC9 interrupt

//#define ToothCount 36
//#define MissingTeeth 1
//#define ActualTeeth 35
//#define DegreesPerTooth 10
//#define DegreePrecision 20

extern unsigned int RPM;
extern unsigned int ShortToothInterval;
unsigned int SubDegreesOn=0;
unsigned int SubDegreesOff=0;
unsigned int TeethDegreesOn=0;
unsigned int TeethDegreesOff=0;
unsigned int dwellUs = 3000; // 4mS dwell input 
unsigned int TDCoffset;//=20*2; //The missing tooth is 20deg ATDC, this way ignition timing never falls in the gap
/* PATCH: 0 = dwell start pending, 1 = charging, 2 = idle/off */
unsigned char Coil1State=2;
unsigned char Coil2State=2;

unsigned int InjectorDeadTime=0;
unsigned int AccelEnrich=0;
unsigned int RequestedTiming;//=(10 *2); //each bit = 0.5deg timing, so 81=40.5deg BTDC
unsigned int TotalTiming; //including the TDCoffset
extern unsigned char EngineStalled;
extern unsigned char SparkCut;
/*==========================================================================
  PATCH: spark scheduler

  Tooth numbering in THIS build: the gap ISR writes T0 = 1 at the first tooth
  after the gap, so angular tooth k (0 = first tooth after gap) is T0 = k+1,
  and real teeth are T0 = 1..35. That is what CourseTooth+1 already produced;
  it is unchanged here, so TDCoffset keeps its meaning.

  What was wrong:
   - Coil 2 was derived by adding 18 teeth and wrapping at 36. Whenever the
     dwell-start tooth index was 17, CC8 came out as 0, which T0 never reaches:
     coil 2 got no dwell start and fired with almost no dwell. With a 20 deg
     offset that happens e.g. at 4000us/6000rpm/16.5-26 deg and
     3500us/7000rpm/13.5-23 deg - boosted, high rpm, two cylinders.
   - DwellTiming = 720 - (TotalTiming + dwell) underflowed as an unsigned int
     and a single "-= 720" could not recover it (coil 1 dead at long dwell).
   - (interval / 20) was truncated before multiplying.
   - Dwell start and spark on the same tooth let the second ISR reload the
     fine timer before the first had fired (cranking).
   - CC6..CC9 were written piecemeal while the ISRs could read them, and only
     recalculated while T0 == 1, so updates were skipped when the loop was slow.
==========================================================================*/
unsigned int  SubDegreesOn2=1, SubDegreesOff2=1;
static unsigned int sCC6=35, sCC7=35, sCC8=17, sCC9=17;
static unsigned int sOn1=1, sOff1=1, sOn2=1, sOff2=1;

/* angle: 0.5 deg units from the first tooth after the gap.
   Produces the T0 compare value (1..ActualTeeth) and the fine timer count.
   An angle inside the gap is scheduled from the last real tooth plus the
   extra tooth periods, so no compare value is ever unreachable. */
static void angleToSchedule(unsigned int angle, unsigned int interval,
                            unsigned int *ccOut, unsigned int *fineOut)
{
	unsigned int  idx, rem, extra;
	unsigned long fine;

	while (angle >= HALFDEG_PER_REV) angle -= HALFDEG_PER_REV;
	idx = angle / TICKS_PER_TOOTH;
	rem = angle % TICKS_PER_TOOTH;
	if (idx <= (unsigned int)(ActualTeeth - 1)) extra = 0;
	else { extra = idx - (unsigned int)(ActualTeeth - 1); idx = (unsigned int)(ActualTeeth - 1); }

	*ccOut = idx + 1;
	fine  = ((unsigned long)rem * (unsigned long)interval) / (unsigned long)TICKS_PER_TOOTH;
	fine += (unsigned long)extra * (unsigned long)interval;
	if (fine == 0) fine = 1;
	if (fine > 0xFFF0UL) fine = 0xFFF0UL;
	*fineOut = (unsigned int)fine;
}

/* dwell start and spark on the same tooth: move the dwell start to the
   previous tooth and add that tooth's period, so the angle is unchanged */
static void separateSameTooth(unsigned int *ccOn, unsigned int *fineOn,
                              unsigned int ccOff, unsigned int interval)
{
	unsigned long f;
	if (*ccOn != ccOff) return;
	f = (unsigned long)*fineOn;
	if (*ccOn > 1) { (*ccOn)--; f += interval; }
	else           { *ccOn = (unsigned int)ActualTeeth; f += (unsigned long)(1 + MissingTeeth) * interval; }
	if (f > 0xFFF0UL) f = 0xFFF0UL;
	*fineOn = (unsigned int)f;
}

void calculateSparkTiming(void){
	unsigned int  interval = ShortToothInterval;
	unsigned long dwellHD;
	unsigned int  sparkAngle, dwellAngle, tt;
	unsigned int  c6,c7,c8,c9,on1,off1,on2,off2;
	unsigned int  dw = dwellUs;

	if (interval == 0) return;

	/* PATCH: absolute dwell ceiling, so no table mistake can charge a coil
	   for tens of milliseconds */
	if (dw > MAX_DWELL_US) dw = MAX_DWELL_US;

	/* dwell in 0.5 deg units straight from the tooth period, so it is not
	   limited by the RPM clamp at rpmScale[15]:
	      dwell counts = dwellUs * 1.25,  counts per 0.5 deg = interval / 20 */
	dwellHD = ((unsigned long)dw * FINE_TIMER_KHZ / 1000UL) * (unsigned long)TICKS_PER_TOOTH
	          / (unsigned long)interval;
	if (dwellHD < 1) dwellHD = 1;
	if (dwellHD > (unsigned long)MAX_DWELL_HD) dwellHD = MAX_DWELL_HD;

	tt = TotalTiming;
	while (tt >= HALFDEG_PER_REV) tt -= HALFDEG_PER_REV;
	sparkAngle = HALFDEG_PER_REV - tt;
	dwellAngle = (sparkAngle + HALFDEG_PER_REV - (unsigned int)dwellHD) % HALFDEG_PER_REV;

	angleToSchedule(dwellAngle, interval, &c6, &on1);
	angleToSchedule(sparkAngle, interval, &c7, &off1);
	angleToSchedule(dwellAngle + (HALFDEG_PER_REV/2), interval, &c8, &on2);   /* coil 2: own schedule */
	angleToSchedule(sparkAngle + (HALFDEG_PER_REV/2), interval, &c9, &off2);
	separateSameTooth(&c6, &on1, c7, interval);
	separateSameTooth(&c8, &on2, c9, interval);

	/* shadows only - the tooth ISR latches them at the gap */
	sCC6=c6; sOn1=on1; sCC7=c7; sOff1=off1;
	sCC8=c8; sOn2=on2; sCC9=c9; sOff2=off2;

	TeethDegreesOn = c6;   /* kept for anything that logs them */
	TeethDegreesOff = c7;
}

/* called ONLY from the tooth ISR at the gap, before T0 is rewritten */
void latchSparkSchedule(void){
	CC6=sCC6; SubDegreesOn=sOn1;
	CC7=sCC7; SubDegreesOff=sOff1;
	CC8=sCC8; SubDegreesOn2=sOn2;
	CC9=sCC9; SubDegreesOff2=sOff2;
}

/* PATCH v0.7: spark ISR latency correction (capture mode only).
   The fine timer used to start whenever this interrupt got to run, so every
   spark was late by the interrupt latency. In capture mode CC15 already holds
   the exact T1 time of the tooth edge (hardware latched it), and T1, T3 and T4
   all tick at fCPU/16 - so T1 - CC15 is exactly how late we are, and it comes
   straight off the fine delay. Works for tooth 1 too: that compare fires when
   the gap ISR rewrites T0, and CC15 still holds the gap tooth's edge. */
unsigned char SparkLatencyMax=0;
static unsigned int latencyCorrected(unsigned int fine){
	unsigned int lat = T1 - CC15;
	if (lat > SparkLatencyMax) SparkLatencyMax = (lat > 255) ? 255 : (unsigned char)lat;
	if (lat >= fine) return 1;        /* already late: fire at once */
	return fine - lat;
}

void sparkAllOff(void){
	T4R=0; T3R=0;
	P2 |= 0x03;
	Coil1State=2;
	Coil2State=2;
}


//P2.0 Spark1
//P2.1 Spark2

/* Spark cut is honoured here: no NEW dwell is started, an in-flight cycle
   still fires at its scheduled angle. The old approach tri-stated DP2 from
   the main loop, which released a charging coil at whatever angle the loop
   happened to be at. Tacho keeps running during a cut, as before. */
void Spark1OnCourseDegCompare(void) interrupt CC6_Interrupt {
	P2  |= 1 << 13 ; //generate tacho signal (ON)
	if (SparkCut || SyncState != 1) { Coil1State=2; P2 |= 0x01; return; }
	P2 |= 0x01; //make sure the coil is OFF at this stage
	Coil1State=0;
	T4 = CaptureMode ? latencyCorrected(SubDegreesOn) : SubDegreesOn;
	T4R=1; //start the timer
}
void Spark1OffCourseDegCompare(void) interrupt CC7_Interrupt {
	P2  &=~(1<<13) ; //generate tacho signal (OFF)
	if (Coil1State==2) { P2 |= 0x01; return; }      /* no dwell this cycle */
	if (Coil1State==0) { T4R=0; P2 &= ~0x01; }      /* dwell start still pending: start it now */
	Coil1State=1;
	T4 = CaptureMode ? latencyCorrected(SubDegreesOff) : SubDegreesOff;
	T4R=1; //start the timer
}
void Spark1SubDegreeTimer(void) interrupt T4_Interrupt {
	T4R=0; //stop T4 timer
	if (Coil1State==0)      { P2 &= ~0x01; Coil1State=1; }   /* dwell on */
	else if (Coil1State==1) { P2 |=  0x01; Coil1State=2; }   /* spark    */
	else                      P2 |=  0x01;
}

void Spark2OnCourseDegCompare(void) interrupt CC8_Interrupt {
	P2  |= 1 << 13 ; //generate tacho signal (ON)
	if (SparkCut || SyncState != 1) { Coil2State=2; P2 |= 0x02; return; }
	P2 |= 0x02;
	Coil2State=0;
	T3 = CaptureMode ? latencyCorrected(SubDegreesOn2) : SubDegreesOn2;
	T3R=1; //start the timer
}
void Spark2OffCourseDegCompare(void) interrupt CC9_Interrupt {
	P2  &=~(1<<13) ; //generate tacho signal (OFF)
	if (Coil2State==2) { P2 |= 0x02; return; }
	if (Coil2State==0) { T3R=0; P2 &= ~0x02; }
	Coil2State=1;
	T3 = CaptureMode ? latencyCorrected(SubDegreesOff2) : SubDegreesOff2;
	T3R=1; //start the timer
}
void Spark2SubDegreeTimer(void) interrupt T3_Interrupt {
	T3R=0; //stop T3 timer
	if (Coil2State==0)      { P2 &= ~0x02; Coil2State=1; }
	else if (Coil2State==1) { P2 |=  0x02; Coil2State=2; }
	else                      P2 |=  0x02;
}
