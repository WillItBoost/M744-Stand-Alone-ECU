/*==========================================================================
  config.h  -  BV7.4.4  build / calibration configuration
  --------------------------------------------------------------------------
  This file now owns every tunable build constant.  reg167.h must no longer
  define ToothCount / MissingTeeth / BenchTest etc.  See CHANGELOG step 1.
==========================================================================*/
#ifndef __CONFIG_H__
#define __CONFIG_H__

/*---- BUILD SELECTION ---------------------------------------------------*/
/* BenchTest forces KPA=45, TPS=0, IAT=CLT=27 and cripples the tooth ISR.
   IT WAS LEFT DEFINED IN reg167.h.  Leave it commented out for engine use. */
/* #define BenchTest */

/*---- TRIGGER WHEEL -----------------------------------------------------*/
#define ToothCount        36
#define MissingTeeth      1
#define ActualTeeth       (ToothCount - MissingTeeth)
#define DegreesPerTooth   (360 / ToothCount)
#define DegreePrecision   2                  /* 0.5 deg granularity        */

/* Derived angular units (all angles below are in 0.5 crank-degree units) */
#define TICKS_PER_TOOTH   (DegreesPerTooth * DegreePrecision)   /* 12 or 20 */
#define HALFDEG_PER_REV   (360 * DegreePrecision)               /* 720      */

#define TIMER_FREQ        20000000
#define NUM_ADC_CHANNELS  16

/*---- SPARK SAFETY ------------------------------------------------------*/
/* Minimum dwell window, in teeth.  Guarantees the dwell-start and
   spark compares never land on the same tooth (which used to kill the
   spark entirely at cranking speeds).  1 tooth = 5ms @200rpm on a 60T. */
#define MIN_DWELL_TEETH   1
#define MAX_DWELL_HD      (180 * DegreePrecision)  /* cap dwell at 180 deg */
#define MAX_ADVANCE_HD    (60  * DegreePrecision)  /* 60 deg BTDC ceiling  */
#define COIL_ON_TIMEOUT   3      /* 10ms ticks a coil may stay charging    */

/*---- FUEL SAFETY -------------------------------------------------------*/
#define MIN_INJ_PW        60     /* T7 counts; below this a compare can be
                                    missed and the injector sticks open    */
#define MAX_INJ_PW        30000  /* ~24ms @ 1.25MHz                        */
#define MIN_AFRx10        80
#define MAX_AFRx10        250
#define FUEL_TEMP_REF_C   20     /* IAT at which BaseFuel is correct       */

/*---- LIMITS ------------------------------------------------------------*/
/* rpm below the limit before spark returns. 0 = original behaviour: spark
   returns as soon as rpm drops below the limit, so the limiter bounces.
   Raising this gives a cleaner limiter but a LONGER CONTINUOUS spark cut,
   and fuel keeps flowing during it - that is raw fuel into a hot turbo.
   Left at 0 deliberately. Change it only if you want that trade. */
#define REVLIMIT_HYST     0
#define OVERBOOST_KPA     250    /* fuel+spark cut above this              */
#define BOOST_TABLE_ON    102    /* kPa: switch to boost tables            */
#define BOOST_TABLE_OFF   98     /* kPa: switch back to NA tables          */

/*---- IDLE / IAC --------------------------------------------------------*/
#define IAC_MIN_STEPS     0
#define IAC_MAX_STEPS     200
#define IAC_TRIM_MIN      20
#define IAC_TRIM_MAX      90
#define IAC_TRIM_CENTRE   50
#define IDLE_TRIM_BAND    100    /* rpm either side of target = deadband   */
#define IDLE_AUTH_TPS     12     /* TPS counts below which idle ctrl runs  */
#define IDLE_SPARK_MAX    20     /* 0.5deg units = 10 deg                  */
#define IDLE_SPARK_MINRPM 500    /* no idle spark trim below this          */

/*---- BOOST PWM ---------------------------------------------------------*/
/* T8 reload value.  Period = 65536 - T8REL_VAL counts of fCPU/128.
   20MHz/128 = 156250Hz, 4610 counts => 33.9Hz.                            */
#define T8REL_VAL         60926
#define BOOST_PWM_SPAN    4590   /* 255 * 18                               */
/* Boost solenoid driver polarity.
   1 = MCU pin duty is inverted relative to the solenoid (low-side driver).
       CC19 = 60926 + 1 + duty*18, which is byte-for-byte the original
       firmware's formula. This is the DEFAULT: your calibration was tuned
       against it on a running engine, and every other output on this board
       is active low.
   0 = MCU pin duty matches the solenoid directly.
   Only change this if a scope on P8.3 AND the solenoid says otherwise. */
#define BOOST_PWM_INVERT  1

/*---- SERIAL ------------------------------------------------------------*/
#define MAX_DATA_LENGTH   32
#define MAX_PAYLOAD       (MAX_DATA_LENGTH - 3)
#define SERIAL_TIMEOUT    20000  /* poll iterations before giving up       */
#define SSC_TIMEOUT       20000
#define RX_IDLE_TICKS     10     /* 10ms ticks before a part frame resets  */

#endif