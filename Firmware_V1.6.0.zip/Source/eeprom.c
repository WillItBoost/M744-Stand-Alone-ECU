#include <reg167.h> 
#include "main.h"
#define EEPROM_READ_INSTRUCTION 0x03
#define EEPROM_WriteEnable_INSTRUCTION 0x06
#define EEPROM_WriteDisable_INSTRUCTION 0x04
#define EEPROM_Write_INSTRUCTION 0x02
#define EEPROM_RSR_INSTRUCTION 0x05

volatile unsigned char EEPROMbuffer[32];

extern char WDTmodeListen; 
extern unsigned int TDCoffset; 
extern volatile unsigned char EEPROMbuffer[32];
extern unsigned int ReferenceTiming;
extern unsigned int RequestedTiming;
extern unsigned char validPacketReceived; //when =1, process the packet
extern char SendMonitor;
extern unsigned int RPM;
extern unsigned int KPA;
extern unsigned char VE;
extern unsigned int TotalTiming;
extern unsigned char flags;
extern unsigned char SparkCut;
extern unsigned char FuelCut;
extern unsigned int RevLimitValue;
extern unsigned int totalInjectorPW;
extern unsigned int dwellUs;
extern unsigned int InjectorDeadTime;
extern unsigned int BaseFuel;
extern unsigned char MAPSensorType;
extern unsigned char IAChomeCount;
extern unsigned char IAChomeCountShadow;
extern volatile unsigned char *RevLimit;
extern volatile unsigned char *BaseFuelmS;
extern unsigned char	CrankEnrichDecayCount;
extern unsigned char	FanCutInTemp;
extern unsigned char	FanCutOutTemp;
extern volatile unsigned char *CrankEnrichDecay;
extern volatile unsigned char *FanCutIn;
extern volatile unsigned char *FanCutOut;
extern unsigned int TPSmax;
extern unsigned int TPSmin;
extern unsigned char EEPROMflags;
/* PATCH: one SSC byte with a timeout. The old routines waited for BSY to go
   HIGH after loading SSCTB; if an interrupt delayed the poll past one byte
   time, BSY had already gone low and the loop never exited - a hard hang of
   the main loop with spark and fuel still running from stale data. */
unsigned char ssc_xfer(unsigned char data)
{
    unsigned int t = SSC_TIMEOUT;
    SSCRIC &= 0x7F;
    SSCTB = data;
    while (!SSCRIR && --t) ;
    SSCRIC &= 0x7F;
    return (unsigned char)SSCRB;
}

void ssc_write_byte(unsigned char data)
{
    ssc_xfer(data);
}

unsigned char ssc_read_byte(void)
{
    return ssc_xfer(0xFF);
}

void ssc_chipselect_low(void)
{
	__asm{
		bclr P4.7
	}
}

void ssc_chipselect_high(void)
{
   	__asm{
		bset P4.7
	}
}


void ssc_init(void)
{
    // Configure P4.7 as GPIO output for chip select
    DP4 |= (1 << 7);
    P4 |= (1 << 7);  // Set chip select high (inactive)

    // Configure SSC pins
    DP3 |= (1 << 9);   // P3.9 as SSC TX output (EEPROM Din)
    DP3 &= ~(1 << 8);  // P3.8 as SSC RX input (EEPROM Dout)
    DP3 |= (1 << 13);  // P3.13 as SSC CLK output (EEPROM CLK)

    // Configure SSC
     // Configure SSC
    SSCCON = 0x0000;       // Reset SSC control register
    SSCCON |= (1 << 14);   // Set master mode
    SSCCON |= (1 << 4);   // Set msb
    SSCCON |= (1 << 6);   // PH
    //SSCCON |= (1 << 5);   // PHase
    SSCCON |= 0x07;    // Set data width to 8 bits 7+1
    SSCBR = 0x0080;        // Set baudrate reload value for desired SPI clock frequency
    SSCCON |= (1 << 15);   // Enable SSC
	ssc_chipselect_high();


}

unsigned char eeprom_read_status_register(){
	unsigned char temp;
		//Enable writing
	ssc_chipselect_low();
	ssc_write_byte(EEPROM_RSR_INSTRUCTION);  
	temp=ssc_read_byte();
  ssc_chipselect_high();
	return temp;

}

void eeprom_read(unsigned int address, unsigned char length)
{
    unsigned int i;
    if (length > 32) length = 32;       /* PATCH: EEPROMbuffer is 32 bytes */
    ssc_chipselect_low();
    // Send read instruction
		ssc_write_byte(EEPROM_READ_INSTRUCTION);   

  	// Send address (16-bit)
    ssc_write_byte((address >> 8) & 0xFF);
    ssc_write_byte(address & 0xFF);

    // Read data from EEPROM
    for (i = 0; i < length; i++)
    {
			EEPROMbuffer[i]=(ssc_read_byte());
			//serialSend(ssc_read_byte());
    }
    ssc_chipselect_high();
}

void eeprom_write(unsigned int address, unsigned char length)
{
	unsigned char i;
	unsigned int guard;
	if (length > 32) length = 32;       /* PATCH: EEPROMbuffer is 32 bytes */
	//Enable writing
	ssc_chipselect_low();
	ssc_write_byte(EEPROM_WriteEnable_INSTRUCTION);   
  ssc_chipselect_high();


	ssc_chipselect_low();
	ssc_write_byte(EEPROM_Write_INSTRUCTION);   
	// Send address (16-bit)
  ssc_write_byte((address >> 8) & 0xFF);
  ssc_write_byte(address & 0xFF);

  for (i = 0; i < length; i++)
  {
		ssc_write_byte(EEPROMbuffer[i]);
  }
    ssc_chipselect_high();

	/* PATCH: no timeout before - a missing EEPROM reads 0xFF and hung here */
	guard = 10000;
	while ((eeprom_read_status_register() & 0x01) != 0 && --guard);
	
	//Disable writing
	ssc_chipselect_low();
	ssc_write_byte(EEPROM_WriteDisable_INSTRUCTION);   
  ssc_chipselect_high();
}


void readEEPROMsettings(){
	
	eeprom_read(0,16); //read 32 bytes from address 0x0000.	
	TDCoffset=(EEPROMbuffer[0]<<8) + EEPROMbuffer[1]; //load the TDC offset from the eeprom, address 0:1, 16bit value.
	EEPROMflags=EEPROMbuffer[2];
	ReferenceTiming=EEPROMbuffer[3] ; //12deg + 10deg offset = 22deg
	MAPSensorType=EEPROMbuffer[4]; //map sensor table to use
	IAChomeCount=EEPROMbuffer[5]; //number of steps to fully close the IAC valve
	IAChomeCountShadow=IAChomeCount;
	/* v1.0.0: IAC fan kick, steps; a blank 0xFF (or anything silly) means none */
	IACfanSteps = (EEPROMbuffer[0x07] <= IAC_FAN_KICK_MAX) ? EEPROMbuffer[0x07] : 0;
	/* v0.9.9: IAC step time, 0.1 ms units; unset or silly = the default */
	if (EEPROMbuffer[0x0F] >= IAC_STEP_MIN_US/100 && EEPROMbuffer[0x0F] <= IAC_STEP_MAX_US/100) IACstepUs = (unsigned int)EEPROMbuffer[0x0F] * 100u;
	else IACstepUs = IAC_STEP_US;
	TPSmin=(EEPROMbuffer[0x0B]<<8) + EEPROMbuffer[0x0C];
	TPSmax=(EEPROMbuffer[0x0D]<<8) + EEPROMbuffer[0x0E];
	
	if (MAPSensorType==0)MAPSensorType=1;
	else if (MAPSensorType>6)MAPSensorType=1;
	RevLimitValue=(RevLimit[0]<<8)|(RevLimit[1]);
	BaseFuel=(BaseFuelmS[0]<<8)|(BaseFuelmS[1]);
	
	CrankEnrichDecayCount=CrankEnrichDecay[0];
	FanCutInTemp=FanCutIn[0];
	FanCutOutTemp=FanCutOut[0];
	
}
