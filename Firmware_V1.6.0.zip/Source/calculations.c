#include "reg167.h"   

#include "main.h"
#define TIMER_FREQ 20000000
#define PRESCALER 16  // Change this to 16 if using a /16 prescaler


extern volatile unsigned int adc_raw[NUM_ADC_CHANNELS];
extern unsigned int ShortToothInterval;
extern const unsigned int dwellTable[];
extern const unsigned int IDTTable[];
extern volatile unsigned char *TempVsCrankPWMap;
extern volatile unsigned char *TempVsAFRMap;
extern volatile unsigned char *IATretardMap;
extern volatile unsigned char *TempVsIACMap;
extern volatile unsigned char *BoostVsRPM;
unsigned int voltage;
const unsigned int voltages[] = {4*36, 6*36, 8*36, 10*36, 12*36, 14*36, 16*36, 18*36};
extern int DeltaTPS;
extern unsigned char EEPROMflags;
extern unsigned char EngineStalled;
extern unsigned char SyncState;
extern unsigned char CrankFuelFlag;
extern unsigned char FloodClear;
extern unsigned long RunTimer;
extern unsigned int AccelEnrich;
extern volatile unsigned char *STFC;
extern volatile unsigned char *STFC_Boost;
extern unsigned char SparkCut;
/* v0.9.1: fractional remainder per cell, in 1/16 raw counts. Without it,
   (step*weight)/16 truncated to zero for any error under ~1.2 AFR in the
   middle of a cell, so small errors were never learned. */
static signed char stftRemNA[256];
static signed char stftRemBoost[256];
/* v0.9.2: VE learn reuses the same two remainder arrays (the two learners
   never run at the same time). In VE mode the unit is 1/128 of a VE count.
   They are cleared whenever the mode changes so one learner never inherits
   the other's half-counts. */
extern volatile unsigned char *VEMap;
extern volatile unsigned char *VEMapBoost;
unsigned char veLearnMode=0;
static unsigned char bigRun = 0;       /* v1.5.0: big errors of one sign in a row */
static signed char   bigSign = 0;
unsigned int TPSmin;
unsigned int TPSmax;
extern unsigned char TPSlearnTimer;
unsigned int BaseFuel=0;
unsigned int InjFlow=0;

unsigned char Wideband=147;
unsigned int RPM=0;
unsigned int KPA=100;
unsigned char VE=75;
unsigned char AlphaN=75;
unsigned char reqAFR=147;
unsigned char AFR=147;   /* legacy, never updated; the live value is Wideband */
unsigned char TPS=0;
char IAT=27;
char CLT=89;
unsigned char flags=0x00;
unsigned char SparkCut=1;   /* PATCH: cut until the main loop has run once */
unsigned char FuelCut=1;
unsigned char MAPSensorType=1;
unsigned char BoostTable=0; //1= use the boost tables


#define TEMP_POINTS 19
#define ADC_RESOLUTION 1024  // 10-bit ADC

// Wideband lookup table: ADC values and corresponding AFR * 10
const unsigned int WidebandADCTable[] = {
    0,   102, 205, 307, 410, 512, 614, 717, 819, 921, 1023
};

const unsigned int WidebandAFRTable[] = {
    74,  89,  104, 119, 134, 149, 164, 179, 194, 209, 224  // AFR * 10 (7.35 to 22.39)
};

const unsigned char WidebandTableSize = sizeof(WidebandAFRTable) / sizeof(WidebandAFRTable[0]);


// MAP sensor lookup table (kPa values) 1Bar
const unsigned int MAPkPaTable[] = {
    20, 25, 30, 35, 40, 45, 50, 55, 60, 65,
    70, 75, 80, 85, 90, 95, 100, 105, 110, 115
};

const unsigned int MAPkPaTable1_15Bar[] = {//calculated with : KPA =(24.70588235 * (ADC/1024*5) ) + 0.117647059
		0,7,13,20,26,33,39,46,52,59,65,72,78,85,91,98,104,110,117,124
};

const unsigned int MAPkPaTable2Bar[] = {  //2bar lookup
    20, 30, 40, 50, 60, 70, 80, 90, 100, 110,
    120, 130, 140, 150, 160, 170, 180, 190, 200, 210
};
const unsigned int MAPkPaTable2_5Bar[] = {//calculated with : KPA =(54.11764706 * (ADC/1024*5) ) - 1.647058824
		0,13,27,41,55,69,84,98,112,127,141,155,169,183,198,212,226,240,254,269
};

const unsigned int MAPkPaTable2_7Bar[] = {//calculated with : KPA = (32.85714286 * (ADC/1024*5) ) - 0.607142857
		0,5,22,38,54,71,87,104,120,137,153,169,186,202,219,235,252,268,284,301
};

const unsigned int MAPkPaTable3Bar[] = { //calculated with : KPA = (65.88235294 * (ADC/1024*5) )- 6.352941176
		0,11,28,46,63,80,98,115,132,150,167,184,201,219,236,254,271,288,305,323
};



// ADC values corresponding to the kPa values (10-bit ADC)
const unsigned int MAPadcTable[] = {
    0, 54, 108, 162, 215, 269, 323, 377, 431, 485,
    538, 592, 646, 700, 754, 808, 862, 915, 969, 1023
};

// Define the table size
#define TABLE_SIZE 16
// Declare the table in RAM

/* PATCH: IAT density correction.
   The original added 27315 (273.15 x 100) to the temperature in WHOLE
   degrees - 30C became 27345 instead of 30315 - so the factor moved by
   under 0.5% across the whole range. Effectively switched off.
   Now referenced to FUEL_TEMP_REF_C (30C, where your logs show you tuned):
   factor = T_ref / T_air in kelvin, exactly 1.000 at 30C. Hotter air gets
   less fuel, colder air more, holding AFR where the tables put it. */
unsigned int temp_corrected(unsigned int base_pulse_width, signed int air_temp_celsius) {
    signed long   kelvin_x100;
    unsigned long correction_factor, adjusted_pulse_width;
    if (air_temp_celsius < -40) air_temp_celsius = -40;
    if (air_temp_celsius > 125) air_temp_celsius = 125;
    kelvin_x100 = 27315L + (signed long)air_temp_celsius * 100L;
    correction_factor = (unsigned long)(((27315L + (long)FUEL_TEMP_REF_C * 100L) * 10000L) / kelvin_x100);
    adjusted_pulse_width = (unsigned long)base_pulse_width * correction_factor / 10000UL;
    if (adjusted_pulse_width > 0xFFFFUL) adjusted_pulse_width = 0xFFFFUL;
    return (unsigned int)adjusted_pulse_width;
}


unsigned char interpolate_AFR(){
    unsigned int index;
    unsigned int fraction;
    unsigned char val1, val2;
    unsigned int result;

    // Ensure CLT is within the valid range (-20 to 127)
    if (CLT < -20) CLT = -20;
    if (CLT > 127) CLT = 127;  // Max value for signed char
    
    // Calculate the index and fraction for interpolation
    index = (unsigned int)((CLT + 20) / 10);
    fraction = (unsigned int)((CLT + 20) % 10);
    
    // Perform linear interpolation
    if (index < 15) {
        val1 = TempVsAFRMap[index];
        val2 = TempVsAFRMap[index + 1];
        if (val1 < val2) {
            result = (unsigned int)val1 + (((unsigned int)val2 - (unsigned int)val1) * fraction) / 10;
        } else {
            result = (unsigned int)val1 - (((unsigned int)val1 - (unsigned int)val2) * fraction) / 10;
        }
        return (unsigned char)result;
    } else {
        // If we're at the last index, return the last value
        return TempVsAFRMap[15];
    }
}

	
	
unsigned char interpolate_IATRetard(){
    unsigned int index;
    unsigned int fraction;
    unsigned char val1, val2;
    unsigned int result;

    // Ensure IAT is within the valid range (-20 to 127)
    if (IAT < -20) IAT = -20;
    if (IAT > 127) IAT = 127;  // Max value for signed char
    
    // Calculate the index and fraction for interpolation
    index = (unsigned int)((IAT + 20) / 10);
    fraction = (unsigned int)((IAT + 20) % 10);
    
    // Perform linear interpolation
    if (index < 15) {
        val1 = IATretardMap[index];
        val2 = IATretardMap[index + 1];
        if (val1 < val2) {
            result = (unsigned int)val1 + (((unsigned int)val2 - (unsigned int)val1) * fraction) / 10;
        } else {
            result = (unsigned int)val1 - (((unsigned int)val1 - (unsigned int)val2) * fraction) / 10;
        }
        return (unsigned char)result;
    } else {
        // If we're at the last index, return the last value
        return IATretardMap[15];
    }
}

unsigned char interpolate_IACvsTemp(){
    unsigned int index;
    unsigned int fraction;
    unsigned char val1;
    unsigned char val2;
    unsigned int result;

    // Ensure CLT is within the valid range (-20 to 127)
    if (CLT < -20) CLT = -20;
    if (CLT > 127) CLT = 127;  // Max value for signed char
    
    // Calculate the index and fraction for interpolation
    index = (unsigned int)((CLT + 20) / 10);
    fraction = (unsigned int)((CLT + 20) % 10);
    
    // Perform linear interpolation
    if (index < 15) {
        val1 = TempVsIACMap[index];
        val2 = TempVsIACMap[index + 1];
        
        // Interpolation for descending values
        if (val1 > val2) {
            result = (unsigned int)val1 - (((unsigned int)val1 - (unsigned int)val2) * fraction) / 10;
        } else {
            // In case there are any ascending sections
            result = (unsigned int)val1 + (((unsigned int)val2 - (unsigned int)val1) * fraction) / 10;
        }
        
        return (unsigned char)result;
    } else {
        // If we're at the last index, return the last value
        return TempVsIACMap[15];
    }
}
	
unsigned int calculateCrankPw(){
    unsigned int index;
    unsigned int fraction;
    unsigned int val1, val2;
    
    // Ensure temp is within the valid range (-20 to 127)
    if (CLT < -20) CLT = -20;
    if (CLT > 126) CLT = 127;  // Max value for signed char
    
    // Calculate the index and fraction for interpolation
    index = (unsigned int)((CLT + 20) / 10);
    fraction = (unsigned int)((CLT + 20) % 10);
    
    // Perform linear interpolation
    if (index < 15) {
        // Combine two bytes to form a 16-bit value
        val1 = ((unsigned int)TempVsCrankPWMap[index * 2] << 8) | TempVsCrankPWMap[index * 2 + 1];
        val2 = ((unsigned int)TempVsCrankPWMap[(index + 1) * 2] << 8) | TempVsCrankPWMap[(index + 1) * 2 + 1];
        if (val1 < val2) {
            return val1 + ((val2 - val1) * fraction) / 10;
        } else {
            return val1 - ((val1 - val2) * fraction) / 10;
        }
    } else {
        // If we're at the last index, return the last value
        return ((unsigned int)TempVsCrankPWMap[30] << 8) | TempVsCrankPWMap[31];
    }
}
/* v1.4.0: charge temperature for the density correction. Without the blend
   turned on (extended settings marker + CT mode 1 + a rising airflow axis)
   this is IAT, exactly as before. */
signed int chargeTemp(void){
	unsigned char i, bp[6], bl[6];
	unsigned int flow;
	signed int t;
	if (!EXT_OK() || ExtSettings[EXT_CT_MODE] != 1) return IAT;
	for (i = 0; i < 6; i++){ bp[i] = ExtSettings[EXT_CT_BP + i]; bl[i] = ExtSettings[EXT_CT_BLEND + i]; if (bl[i] > 100) bl[i] = 100; }
	for (i = 1; i < 6; i++) if (bp[i] <= bp[i - 1]) return IAT;
	flow = (unsigned int)(((unsigned long)RPM * (unsigned long)KPA / 1000UL) / 4UL);
	if (flow <= bp[0]) t = bl[0];
	else if (flow >= bp[5]) t = bl[5];
	else { for (i = 0; i < 5; i++) if (flow <= bp[i + 1]) break;
	       t = bl[i] + (int)(((long)((int)bl[i + 1] - (int)bl[i]) * (long)(flow - bp[i])) / (long)(bp[i + 1] - bp[i])); }
	return (signed int)IAT + (int)(((long)((int)CLT - (int)IAT) * t) / 100L);
}
unsigned int calculateFuel(){
	unsigned long  totalFuel=(unsigned long)temp_corrected(BaseFuel,chargeTemp());
	totalFuel*= VE ;
	totalFuel*= KPA;
	totalFuel/= 100*256;
	totalFuel*= 147;
	totalFuel/= (reqAFR ) ;

	
	return (unsigned int)totalFuel;
}
unsigned int calculateFuelAlphaN(){
	unsigned long  totalFuel=(unsigned long)temp_corrected(BaseFuel,chargeTemp());
	totalFuel*= AlphaN ;
	totalFuel*= 100;
	totalFuel/= 100*256;
	totalFuel*= 147;
	totalFuel/= (reqAFR ) ;

	
	return (unsigned int)totalFuel;
}
extern volatile unsigned int *DwellKPAMap;
/* PATCH: byte order. The XDF stores this table big-endian (like every other
   16 bit table here), but it was read as a native C167 word, which is
   little-endian - so every value was byte-swapped. Your tune's 500/1000/1500us
   were read as 62465/59395/56325us, which pushed the dwell start off the end
   of the wheel above 125 kPa: both coils fired on a token dwell under boost.
   Now read big-endian, the same way dwellTable[] and IDTTable[] are. */
static unsigned int dwellKPAentry(unsigned char i){
	volatile unsigned char *p = (volatile unsigned char *)DwellKPAMap;
	return ((unsigned int)p[i*2] << 8) | p[i*2+1];
}
unsigned int KPA_Dwell_Adjust(){
	if (KPA < 100) return dwellKPAentry(0);
	if (KPA < 125) return dwellKPAentry(1);
	if (KPA < 150) return dwellKPAentry(2);
	if (KPA < 175) return dwellKPAentry(3);
	if (KPA < 200) return dwellKPAentry(4);
	if (KPA < 225) return dwellKPAentry(5);
	if (KPA < 250) return dwellKPAentry(6);
	return dwellKPAentry(7);
	
}

unsigned int interpolate_dwell() {
    unsigned char i;
    unsigned int lower_voltage, upper_voltage;
    unsigned int lower_duration, upper_duration;
    unsigned long duration;
    long voltage_diff, voltage_range, duration_diff;
    
// voltage = updateFilterVbat(adc_raw[5]);
        /* PATCH: no range check - outside 4..18V this interpolated between
       uninitialised locals. Happens for real in the first milliseconds after
       reset, before the ADC has produced a battery reading. */
    if (voltage <= voltages[0]) return dwellTable[0];
    if (voltage >= voltages[7]) return dwellTable[7];

    // Check if the input voltage matches a data point
    for (i = 0; i < 8; i++) {
        if (voltage == voltages[i]) {
            return dwellTable[i];
        }
    }

    // Find the nearest lower and upper voltage data points
    for (i = 0; i < 7; i++) {
        if ((voltages[i] <= voltage && voltage <= voltages[i + 1]) ||
            (voltages[i] >= voltage && voltage >= voltages[i + 1])) {
            lower_voltage = voltages[i];
            upper_voltage = voltages[i + 1];
            lower_duration = dwellTable[i];
            upper_duration = dwellTable[i + 1];
            break;
        }
    }

    // Perform linear interpolation
    voltage_diff = (long)(voltage - lower_voltage);
    voltage_range = (long)(upper_voltage - lower_voltage);
    
    if (voltage_range != 0) {
        duration_diff = (long)upper_duration - (long)lower_duration;
        duration = lower_duration + (duration_diff * voltage_diff) / voltage_range;
    } else {
        duration = lower_duration;
    }

    return (unsigned int)duration;
}

unsigned int interpolate_IDT() {
    unsigned char i;
    unsigned int lower_voltage, upper_voltage;
    unsigned int lower_duration, upper_duration;
    unsigned long duration;
    long voltage_diff, voltage_range, duration_diff;

		
	
        /* PATCH: no range check - outside 4..18V this interpolated between
       uninitialised locals. Happens for real in the first milliseconds after
       reset, before the ADC has produced a battery reading. */
    if (voltage <= voltages[0]) return IDTTable[0];
    if (voltage >= voltages[7]) return IDTTable[7];

    // Check if the input voltage matches a data point
    for (i = 0; i < 8; i++) {
        if (voltage == voltages[i]) {
            return IDTTable[i];
        }
    }

    // Find the nearest lower and upper voltage data points
    for (i = 0; i < 7; i++) {
        if ((voltages[i] <= voltage && voltage <= voltages[i + 1]) ||
            (voltages[i] >= voltage && voltage >= voltages[i + 1])) {
            lower_voltage = voltages[i];
            upper_voltage = voltages[i + 1];
            lower_duration = IDTTable[i];
            upper_duration = IDTTable[i + 1];
            break;
        }
    }

    // Perform linear interpolation
    voltage_diff = (long)(voltage - lower_voltage);
    voltage_range = (long)(upper_voltage - lower_voltage);
    
    if (voltage_range != 0) {
        duration_diff = (long)upper_duration - (long)lower_duration;
        duration = lower_duration + (duration_diff * voltage_diff) / voltage_range;
    } else {
        duration = lower_duration;
    }

    return (unsigned int)duration;
}

//Fueling



// Define the scaling for x-axis (KPA) and y-axis (RPM)
volatile unsigned int KPAtableNA[TABLE_SIZE] = {0, 10, 20, 30, 40, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100};
volatile unsigned int KPAtableBoost[TABLE_SIZE] = {100, 110, 120, 130, 140, 150, 155, 160, 165, 170, 175, 180, 185, 190, 195, 200};
volatile unsigned int rpmScale[TABLE_SIZE] = {0, 500, 1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 5500, 6000, 6500, 7000, 7500};
//volatile unsigned int *rpmScale = (unsigned char *)StartOfMapArea_RAM+0xF00; //first 512byte table is the VE map


unsigned int scale_uint16_by_percentage(unsigned int value, unsigned char percentage_reg) {
    // Scale the 16-bit value by the percentage using fixed-point arithmetic
    unsigned int scaled_value = (unsigned int)((unsigned long)value * percentage_reg >> 8);
    return scaled_value;
}

unsigned char interpolateTable(unsigned char *table, unsigned int rpm, unsigned int kpa,unsigned char boost) {
    unsigned char x1=0, x2=1, y1=0, y2=1;
    unsigned int value11, value12, value21, value22;
    unsigned long interpolatedValue;
    unsigned int *kpatable;
    long kpa_diff,kpa_range,rpm_diff,rpm_range;
    if (boost==0) kpatable=KPAtableNA; else kpatable=KPAtableBoost;

    /* PATCH: x2/y2 were left uninitialised when the input fell outside the
       axis, reading past the table. KPA above the top of the boost axis (200
       by default) does exactly that - including every overboost event. The
       inputs are clamped to the axis ends, which is what the table edge
       means anyway. In-range lookups are unchanged. */
    if (kpatable[0] <= kpatable[TABLE_SIZE-1]) {
        if (kpa < kpatable[0]) kpa = kpatable[0];
        if (kpa > kpatable[TABLE_SIZE-1]) kpa = kpatable[TABLE_SIZE-1];
    }
    if (rpmScale[0] <= rpmScale[TABLE_SIZE-1]) {
        if (rpm < rpmScale[0]) rpm = rpmScale[0];
        if (rpm > rpmScale[TABLE_SIZE-1]) rpm = rpmScale[TABLE_SIZE-1];
    }
    
    // Find the bounding indices for KPA
    for (x1 = 0; x1 < TABLE_SIZE - 1; x1++) {
        if ((kpa >= kpatable[x1] && kpa <= kpatable[x1 + 1]) ||
            (kpa <= kpatable[x1] && kpa >= kpatable[x1 + 1])) {
            x2 = x1 + 1;
            break;
        }
    }

    // Find the bounding indices for RPM
    for (y1 = 0; y1 < TABLE_SIZE - 1; y1++) {
        if ((rpm >= rpmScale[y1] && rpm <= rpmScale[y1 + 1]) ||
            (rpm <= rpmScale[y1] && rpm >= rpmScale[y1 + 1])) {
            y2 = y1 + 1;
            break;
        }
    }

    // Get the table values at the bounding indices
    value11 = table[y1 * TABLE_SIZE + x1];
    value12 = table[y1 * TABLE_SIZE + x2];
    value21 = table[y2 * TABLE_SIZE + x1];
    value22 = table[y2 * TABLE_SIZE + x2];

    // Perform bilinear interpolation
     kpa_diff = (long)kpa - kpatable[x1];
     kpa_range = (long)kpatable[x2] - kpatable[x1];
     rpm_diff = (long)rpm - rpmScale[y1];
     rpm_range = (long)rpmScale[y2] - rpmScale[y1];

    if (kpa_range != 0 && rpm_range != 0) {
        interpolatedValue = (unsigned long)value11 * (rpm_range - rpm_diff) * (kpa_range - kpa_diff);
        interpolatedValue += (unsigned long)value21 * rpm_diff * (kpa_range - kpa_diff);
        interpolatedValue += (unsigned long)value12 * (rpm_range - rpm_diff) * kpa_diff;
        interpolatedValue += (unsigned long)value22 * rpm_diff * kpa_diff;
        interpolatedValue /= rpm_range * kpa_range;
    } else {
        interpolatedValue = value11;
    }

    return (unsigned char)interpolatedValue;
}

/* PATCH v0.9: live short-term fuel trim.
   When Enable STFC is on, off idle, wideband valid, and the site is steady,
   walk the four surrounding cells of STFC / STFC_Boost toward the AFR target.
   Encoding matches the XDF: lower raw = more fuel, 128 = 0%.
   Idle is left to IdleFuelTrim so the two loops do not fight.

   v0.9.2: with VE Table Learn (FLAG_VE_LEARN) ticked, the SAME gates, settle,
   error, gain and bilinear spread write into VE / VE (Boost) instead. The
   step is scaled by each cell's own VE so the correction is the same
   percentage of fuel as the STFT learner (~4.9%/s per 1.0 AFR) - the loop
   gain, and so its stability with wideband delay, is unchanged. No +/-15%
   cap: a cell stops only at VE_LEARN_MIN or 255. */
void updateSTFC(void){
	unsigned int *kpatable;
	unsigned char x1=0, x2=1, y1=0, y2=1;
	unsigned int kpa, rpm;
	long kpa_diff, kpa_range, rpm_diff, rpm_range;
	int e;
	volatile unsigned char *map;
	static unsigned char settle=0;
	static unsigned int lastKpa=0, lastRpm=0;
	static unsigned char lastTps=0;
	unsigned char veMode;
	unsigned char atIdle;

	/* v0.9.2: VE learn wins over STFT learn. On any change of mode the
	   carried half-counts are dropped, so neither learner inherits the
	   other's (they are in different units). */
	veMode = (EEPROMflags & FLAG_VE_LEARN) ? 1 : 0;
	if (veMode != veLearnMode){
		unsigned int j;
		for (j = 0; j < 256; j++){ stftRemNA[j] = 0; stftRemBoost[j] = 0; }
		veLearnMode = veMode;
		settle = 0;
	}
	if (!veMode && (EEPROMflags & FLAG_STFT_LEARN) == 0){ settle = 0; return; }   /* v0.9.1: own checkbox */
	if (ToolAltInject && ToolLease){ settle = 0; return; }   /* v0.9.7: a dead-time test is running */
	if (DelayTestState == 1 || DelayTestState == 2){ settle = 0; return; }   /* v1.2.0: a delay test is stepping the fuel */
	/* v0.9.2: in Alpha-N the fuel comes from the Alpha-N table and KPA is
	   forced to 100, so the VE table isn't the one being tested - don't
	   write into it. */
	if (veMode && (EEPROMflags & FLAG_ALPHA_N)){ settle = 0; return; }
	if (EngineStalled || SyncState!=1 || CrankFuelFlag || FuelCut || FloodClear){ settle = 0; return; }
	/* v0.9.1: no learning during spark cut (rev limiter, overboost). Fuel keeps
	   flowing with no spark, the wideband reads that unburnt charge as lean, and
	   sitting on the limiter is a nice steady site - it would learn rich. */
	if (SparkCut){ settle = 0; return; }
	if (RunTimer < IDLECL_WARMUP_TICKS){ settle = 0; return; }
	if (Wideband < WB_VALID_MIN || Wideband > WB_VALID_MAX){ settle = 0; return; }
	/* v0.9.1: was "if (AccelEnrich) return" plus a +/-1 count DeltaTPS check.
	   TPS noise re-armed accel enrichment every ~50ms, so the learner never
	   got its 1s of calm. Now only a real throttle move (or accel enrichment
	   bigger than noise can produce) holds it off. */
	if (stftTipHold){ settle = 0; return; }
	if (AccelEnrich > STFC_AE_IGNORE){ settle = 0; return; }
	/* v0.9.4: VE learn covers idle too, so the idle cells get dialled in on the
	   dyno instead of being left to the idle fuel trim. STFT learning is still
	   off idle only - on the road IdleFuelTrim owns that region. While VE learn
	   is on, main.c neither learns nor applies IdleFuelTrim, so only one loop
	   is ever touching idle fuelling. */
	atIdle = (TPS < STFC_LEARN_TPS_MIN) ? 1 : 0;
	if (atIdle && !veMode){ settle = 0; return; }

	kpa = KPA;
	rpm = RPM;
	if (BoostTable==0) kpatable = KPAtableNA; else kpatable = KPAtableBoost;
	if (veMode) map = (BoostTable==0) ? VEMap : VEMapBoost;      /* v0.9.2 */
	else        map = (BoostTable==0) ? STFC : STFC_Boost;

	if (kpatable[0] <= kpatable[TABLE_SIZE-1]) {
		if (kpa < kpatable[0]) kpa = kpatable[0];
		if (kpa > kpatable[TABLE_SIZE-1]) kpa = kpatable[TABLE_SIZE-1];
	}
	if (rpmScale[0] <= rpmScale[TABLE_SIZE-1]) {
		if (rpm < rpmScale[0]) rpm = rpmScale[0];
		if (rpm > rpmScale[TABLE_SIZE-1]) rpm = rpmScale[TABLE_SIZE-1];
	}

	for (x1 = 0; x1 < TABLE_SIZE - 1; x1++) {
		if ((kpa >= kpatable[x1] && kpa <= kpatable[x1 + 1]) ||
		    (kpa <= kpatable[x1] && kpa >= kpatable[x1 + 1])) {
			x2 = x1 + 1;
			break;
		}
	}
	for (y1 = 0; y1 < TABLE_SIZE - 1; y1++) {
		if ((rpm >= rpmScale[y1] && rpm <= rpmScale[y1 + 1]) ||
		    (rpm <= rpmScale[y1] && rpm >= rpmScale[y1 + 1])) {
			y2 = y1 + 1;
			break;
		}
	}

	/* site must sit still for 1s so transients do not smear neighbouring cells */
	if (kpa + 4 < lastKpa || kpa > lastKpa + 4 || rpm + 150 < lastRpm || rpm > lastRpm + 150 ||
	    TPS + STFC_TPS_STEADY < lastTps || TPS > lastTps + STFC_TPS_STEADY){
		settle = 0;
		lastKpa = kpa;
		lastRpm = rpm;
		lastTps = TPS;
		return;
	}
	lastKpa = kpa;
	lastRpm = rpm;
	lastTps = TPS;
	if (settle < (atIdle ? STFC_IDLE_SETTLE_STEPS : STFC_SETTLE_STEPS)){ settle++; return; }

	e = (int)Wideband - (int)reqAFR;   /* + = lean, needs fuel, raw must fall */

	kpa_diff  = (long)kpa - kpatable[x1];
	kpa_range = (long)kpatable[x2] - kpatable[x1];
	rpm_diff  = (long)rpm - rpmScale[y1];
	rpm_range = (long)rpmScale[y2] - rpmScale[y1];
	if (kpa_range == 0) kpa_range = 1;
	if (rpm_range == 0) rpm_range = 1;

	{
		/* v0.9.1: normalised bilinear update with carried remainders.
		   Each cell i moves by  k * w_i / sum(w_j^2)  where k is the change we
		   want at the operating point. That makes the correction at the
		   operating point the same wherever you sit in the cell (the old
		   step*w/16 was ~7x weaker in the middle of a cell than on a
		   breakpoint), and the remainder carry means small errors add up
		   instead of truncating to nothing. */
		int W[4];
		unsigned char idx[4];
		long S, k16;
		unsigned char i;
		signed char *rem = (BoostTable==0) ? stftRemNA : stftRemBoost;
		unsigned char confScale[4];

		W[0] = (int)(((rpm_range - rpm_diff) * (kpa_range - kpa_diff) * 16L) / (rpm_range * kpa_range));
		W[1] = (int)(((rpm_range - rpm_diff) * kpa_diff * 16L) / (rpm_range * kpa_range));
		W[2] = (int)((rpm_diff * (kpa_range - kpa_diff) * 16L) / (rpm_range * kpa_range));
		W[3] = (int)((rpm_diff * kpa_diff * 16L) / (rpm_range * kpa_range));
		idx[0] = (unsigned char)(y1 * TABLE_SIZE + x1);  idx[1] = (unsigned char)(y1 * TABLE_SIZE + x2);
		idx[2] = (unsigned char)(y2 * TABLE_SIZE + x1);  idx[3] = (unsigned char)(y2 * TABLE_SIZE + x2);

		/* v1.5.0: learner confidence. A cell carrying real weight gains a point
		   each time it's found on target; a big error costs it a quarter. Steps
		   are scaled by K/(K+conf), so a settled cell stops chasing noise and a
		   new one still learns at full speed. */
		{
			volatile unsigned char *cf = (BoostTable != 0) ? LearnConfBoost : LearnConf;
			unsigned char useConf = (EXT_OK() && ExtSettings[EXT_CONF_MODE] == 1);
			if (e <= IDLECL_DEADBAND && e >= -IDLECL_DEADBAND){
				bigRun = 0;
				if (useConf) for (i = 0; i < 4; i++) if (W[i] >= CONF_MIN_W && cf[idx[i]] < 255) cf[idx[i]]++;
				return;
			}
			/* a real change persists; a glitch doesn't - confidence only drops after
			   CONF_BIG_RUN big errors of the same sign in a row */
			if (e > CONF_BIG_ERR || e < -CONF_BIG_ERR){
				signed char sg = (e > 0) ? 1 : -1;
				if (sg == bigSign && bigRun < 255) bigRun++; else { bigSign = sg; bigRun = 1; }
				if (useConf && bigRun >= CONF_BIG_RUN)
					for (i = 0; i < 4; i++) if (W[i] >= CONF_MIN_W) cf[idx[i]] = (unsigned char)(cf[idx[i]] - (cf[idx[i]] >> 2));
			}
			else bigRun = 0;
			for (i = 0; i < 4; i++) confScale[i] = useConf ? cf[idx[i]] : 0;
		}
		if (e >  IDLECL_ERR_CLAMP) e =  IDLECL_ERR_CLAMP;
		if (e < -IDLECL_ERR_CLAMP) e = -IDLECL_ERR_CLAMP;

		S = (long)W[0]*W[0] + (long)W[1]*W[1] + (long)W[2]*W[2] + (long)W[3]*W[3];
		if (S < 1) S = 1;
		k16 = (long)e * STFC_GAIN;            /* + = lean = needs fuel = raw must FALL */

		if (!veMode){
			for (i = 0; i < 4; i++){
				long d16;
				int  acc, whole, nv;
				if (W[i] == 0) continue;
				d16 = (k16 * (long)W[i] * 16L) / S;          /* this cell's share, 1/16 counts */
				d16 = (d16 * CONF_K) / (CONF_K + (long)confScale[i]);   /* v1.5.0 */
				acc = (int)rem[idx[i]] + (int)d16;
				whole = acc / 16;                             /* whole raw counts to apply */
				acc  -= whole * 16;                           /* keep the remainder, -15..+15 */
				nv = (int)map[idx[i]] - whole;
				if (nv < STFC_RAW_MIN){ nv = STFC_RAW_MIN; acc = 0; }
				if (nv > STFC_RAW_MAX){ nv = STFC_RAW_MAX; acc = 0; }
				map[idx[i]] = (unsigned char)nv;
				rem[idx[i]] = (signed char)acc;
			}
		}
		else {
			/* v0.9.2: VE learn. One STFT raw count is 1/256 of the fuel, so
			   the same fractional step in a VE cell is VE/256 counts. In
			   1/128 VE counts:  d128 = (k16*W*16/S) * (VE/256) * 128/16
			                          = k16 * W * VE / (2*S).
			   Sign is the other way round to the STFT table: lean (+e)
			   needs fuel, so VE must RISE. Worst case per 100ms at the
			   error clamp, on a breakpoint, VE 255: 478/128 = 3.7 counts. */
			for (i = 0; i < 4; i++){
				long d128;
				int  acc, whole, nv, cell;
				if (W[i] == 0) continue;
				cell = (int)map[idx[i]];
				if (cell < VE_LEARN_MIN) cell = VE_LEARN_MIN;   /* a 0 cell still gets a step */
				d128 = (k16 * (long)W[i] * (long)cell) / (2L * S);
				if (atIdle) d128 /= STFC_IDLE_SLOW;          /* v0.9.4: gentler at idle */
				d128 = (d128 * CONF_K) / (CONF_K + (long)confScale[i]);   /* v1.5.0 */
				acc = (int)rem[idx[i]] + (int)d128;
				whole = acc / 128;                            /* whole VE counts to apply */
				acc  -= whole * 128;                          /* remainder, -127..+127 */
				nv = (int)map[idx[i]] + whole;
				if (nv < VE_LEARN_MIN){ nv = VE_LEARN_MIN; acc = 0; }
				if (nv > 255)         { nv = 255;          acc = 0; }
				map[idx[i]] = (unsigned char)nv;
				rem[idx[i]] = (signed char)acc;
			}
		}
	}
}

void calculateRPM(){
	//use ShortToothInterval and T01CON bit 8 (prescaler divisor) to calculate RPM
    unsigned long rpm;
    unsigned long elapsed_time;
    unsigned long rotation_time;
    elapsed_time = (unsigned long)ShortToothInterval * (16); 
    // Calculate the time for a complete rotation
    rotation_time = elapsed_time * ToothCount;
    // Calculate RPM
//	if (rotation_time != 0) {
        rpm = (unsigned long)(TIMER_FREQ * 60) / rotation_time;   
//    }
    RPM= (unsigned int)rpm;
}

static char IAT_table[1024] = {
  127, 127, 127, 127, 127, 127, 127, 127, 127, 
  127, 127, 127, 127, 127, 127, 127, 127, 127, 
  127, 127, 127, 127, 127, 127, 127, 127, 127, 
  127, 127, 127, 127, 125, 124, 123, 121, 120, 
  119, 117, 116, 115, 114, 113, 112, 111, 110, 
  109, 108, 107, 106, 105, 104, 104, 103, 102, 
  101, 101, 100, 99, 98, 98, 97, 96, 96, 95, 
  94, 94, 93, 93, 92, 91, 91, 90, 90, 89, 89, 
  88, 88, 87, 87, 86, 86, 85, 85, 84, 84, 83, 
  83, 82, 82, 81, 81, 81, 80, 80, 79, 79, 78, 
  78, 78, 77, 77, 77, 76, 76, 75, 75, 75, 74, 
  74, 74, 73, 73, 73, 72, 72, 72, 71, 71, 71, 
  70, 70, 70, 69, 69, 69, 69, 68, 68, 68, 67, 
  67, 67, 67, 66, 66, 66, 65, 65, 65, 65, 64, 
  64, 64, 64, 63, 63, 63, 63, 62, 62, 62, 62, 
  61, 61, 61, 61, 60, 60, 60, 60, 59, 59, 59, 
  59, 59, 58, 58, 58, 58, 57, 57, 57, 57, 57, 
  56, 56, 56, 56, 56, 55, 55, 55, 55, 55, 54, 
  54, 54, 54, 54, 53, 53, 53, 53, 53, 52, 52, 
  52, 52, 52, 52, 51, 51, 51, 51, 51, 50, 50, 
  50, 50, 50, 50, 49, 49, 49, 49, 49, 49, 48, 
  48, 48, 48, 48, 47, 47, 47, 47, 47, 47, 47, 
  46, 46, 46, 46, 46, 46, 45, 45, 45, 45, 45, 
  45, 44, 44, 44, 44, 44, 44, 44, 43, 43, 43, 
  43, 43, 43, 43, 42, 42, 42, 42, 42, 42, 42, 
  41, 41, 41, 41, 41, 41, 41, 40, 40, 40, 40, 
  40, 40, 40, 39, 39, 39, 39, 39, 39, 39, 39, 
  38, 38, 38, 38, 38, 38, 38, 37, 37, 37, 37, 
  37, 37, 37, 37, 36, 36, 36, 36, 36, 36, 36, 
  36, 35, 35, 35, 35, 35, 35, 35, 35, 34, 34, 
  34, 34, 34, 34, 34, 34, 34, 33, 33, 33, 33, 
  33, 33, 33, 33, 32, 32, 32, 32, 32, 32, 32, 
  32, 32, 31, 31, 31, 31, 31, 31, 31, 31, 31, 
  30, 30, 30, 30, 30, 30, 30, 30, 30, 29, 29, 
  29, 29, 29, 29, 29, 29, 29, 28, 28, 28, 28, 
  28, 28, 28, 28, 28, 27, 27, 27, 27, 27, 27, 
  27, 27, 27, 27, 26, 26, 26, 26, 26, 26, 26, 
  26, 26, 25, 25, 25, 25, 25, 25, 25, 25, 25, 
  25, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 
  23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 22, 
  22, 22, 22, 22, 22, 22, 22, 22, 22, 21, 21, 
  21, 21, 21, 21, 21, 21, 21, 21, 21, 20, 20, 
  20, 20, 20, 20, 20, 20, 20, 20, 19, 19, 19, 
  19, 19, 19, 19, 19, 19, 19, 19, 18, 18, 18, 
  18, 18, 18, 18, 18, 18, 18, 18, 17, 17, 17, 
  17, 17, 17, 17, 17, 17, 17, 17, 16, 16, 16, 
  16, 16, 16, 16, 16, 16, 16, 16, 15, 15, 15, 
  15, 15, 15, 15, 15, 15, 15, 15, 14, 14, 14, 
  14, 14, 14, 14, 14, 14, 14, 14, 13, 13, 13, 
  13, 13, 13, 13, 13, 13, 13, 13, 12, 12, 12, 
  12, 12, 12, 12, 12, 12, 12, 12, 11, 11, 11, 
  11, 11, 11, 11, 11, 11, 11, 11, 10, 10, 10, 
  10, 10, 10, 10, 10, 10, 10, 10, 10, 9, 9, 
  9, 9, 9, 9, 9, 9, 9, 9, 9, 8, 8, 8, 8, 8, 
  8, 8, 8, 8, 8, 8, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
  6, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 4, 4, 
  4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 
  2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
  1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -2, -2, 
  -2, -2, -2, -2, -2, -2, -2, -2, -2, -3, -3, 
  -3, -3, -3, -3, -3, -3, -3, -3, -3, -4, -4, 
  -4, -4, -4, -4, -4, -4, -4, -4, -4, -5, -5, 
  -5, -5, -5, -5, -5, -5, -5, -5, -6, -6, -6, 
  -6, -6, -6, -6, -6, -6, -6, -7, -7, -7, -7, 
  -7, -7, -7, -7, -7, -7, -7, -8, -8, -8, -8, 
  -8, -8, -8, -8, -8, -8, -9, -9, -9, -9, -9, 
  -9, -9, -9, -9, -10, -10, -10, -10, -10, 
  -10, -10, -10, -10, -10, -11, -11, -11, -11, 
  -11, -11, -11, -11, -11, -12, -12, -12, -12, 
  -12, -12, -12, -12, -12, -12, -13, -13, -13, 
  -13, -13, -13, -13, -13, -13, -14, -14, -14, 
  -14, -14, -14, -14, -14, -14, -15, -15, -15, 
  -15, -15, -15, -15, -15, -16, -16, -16, -16, 
  -16, -16, -16, -16, -16, -17, -17, -17, -17, 
  -17, -17, -17, -17, -18, -18, -18, -18, -18, 
  -18, -18, -18, -19, -19, -19, -19, -19, -19, 
  -19, -19, -20, -20, -20, -20, -20, -20, -20, 
  -21, -21, -21, -21, -21, -21, -21, -22, -22, 
  -22, -22, -22, -22, -22, -23, -23, -23, -23, 
  -23, -23, -23, -24, -24, -24, -24, -24, -24, 
  -24, -25, -25, -25, -25, -25, -25, -26, -26, 
  -26, -26, -26, -26, -27, -27, -27, -27, -27, 
  -27, -28, -28, -28, -28, -28, -28, -29, -29, 
  -29, -29, -29, -30, -30, -30, -30, -30, -30, 
  -31, -31, -31, -31, -31, -32, -32, -32, -32, 
  -33, -33, -33, -33, -33, -34, -34, -34, -34, 
  -35, -35, -35, -35, -35, -36, -36, -36, -36, 
  -37, -37, -37, -37, -38, -38, -38, -39, -39, 
  -39, -39, -40, -40, -40, -41, -41, -41, -42, 
  -42, -42, -43, -43, -43, -44, -44, -44, -45, 
  -45, -46, -46, -46, -47, -47, -48, -48, -49, 
  -49, -50, -50, -51, -51, -52, -52, -53, -54, 
  -54, -55, -56, -57, -57, -58, -59, -60, -61, 
  -62, -63, -65, -66, -68, -70, -72, -74, -77, 
  -82, -87
};
 

static char CLT_table[1024] = {
  127, 127, 127, 127, 127, 127, 127, 127, 127, 
  127, 127, 127, 127, 127, 127, 127, 127, 127, 
  127, 127, 127, 127, 127, 127, 127, 125, 124, 
  122, 120, 119, 117, 116, 114, 113, 112, 111, 
  109, 108, 107, 106, 105, 104, 103, 102, 101, 
  100, 99, 98, 97, 97, 96, 95, 94, 93, 93, 
  92, 91, 91, 90, 89, 89, 88, 87, 87, 86, 86, 
  85, 84, 84, 83, 83, 82, 82, 81, 81, 80, 80, 
  79, 79, 78, 78, 77, 77, 76, 76, 75, 75, 75, 
  74, 74, 73, 73, 73, 72, 72, 71, 71, 71, 70, 
  70, 69, 69, 69, 68, 68, 68, 67, 67, 67, 66, 
  66, 66, 65, 65, 65, 64, 64, 64, 64, 63, 63, 
  63, 62, 62, 62, 61, 61, 61, 61, 60, 60, 60, 
  60, 59, 59, 59, 58, 58, 58, 58, 57, 57, 57, 
  57, 56, 56, 56, 56, 55, 55, 55, 55, 55, 54, 
  54, 54, 54, 53, 53, 53, 53, 52, 52, 52, 52, 
  52, 51, 51, 51, 51, 51, 50, 50, 50, 50, 50, 
  49, 49, 49, 49, 49, 48, 48, 48, 48, 48, 47, 
  47, 47, 47, 47, 47, 46, 46, 46, 46, 46, 45, 
  45, 45, 45, 45, 45, 44, 44, 44, 44, 44, 44, 
  43, 43, 43, 43, 43, 43, 42, 42, 42, 42, 42, 
  42, 41, 41, 41, 41, 41, 41, 40, 40, 40, 40, 
  40, 40, 40, 39, 39, 39, 39, 39, 39, 38, 38, 
  38, 38, 38, 38, 38, 37, 37, 37, 37, 37, 37, 
  37, 36, 36, 36, 36, 36, 36, 36, 35, 35, 35, 
  35, 35, 35, 35, 35, 34, 34, 34, 34, 34, 34, 
  34, 33, 33, 33, 33, 33, 33, 33, 33, 32, 32, 
  32, 32, 32, 32, 32, 32, 31, 31, 31, 31, 31, 
  31, 31, 31, 30, 30, 30, 30, 30, 30, 30, 30, 
  30, 29, 29, 29, 29, 29, 29, 29, 29, 28, 28, 
  28, 28, 28, 28, 28, 28, 28, 27, 27, 27, 27, 
  27, 27, 27, 27, 27, 26, 26, 26, 26, 26, 26, 
  26, 26, 26, 25, 25, 25, 25, 25, 25, 25, 25, 
  25, 24, 24, 24, 24, 24, 24, 24, 24, 24, 23, 
  23, 23, 23, 23, 23, 23, 23, 23, 23, 22, 22, 
  22, 22, 22, 22, 22, 22, 22, 22, 21, 21, 21, 
  21, 21, 21, 21, 21, 21, 21, 20, 20, 20, 20, 
  20, 20, 20, 20, 20, 20, 19, 19, 19, 19, 19, 
  19, 19, 19, 19, 19, 18, 18, 18, 18, 18, 18, 
  18, 18, 18, 18, 18, 17, 17, 17, 17, 17, 17, 
  17, 17, 17, 17, 16, 16, 16, 16, 16, 16, 16, 
  16, 16, 16, 16, 15, 15, 15, 15, 15, 15, 15, 
  15, 15, 15, 15, 14, 14, 14, 14, 14, 14, 14, 
  14, 14, 14, 14, 13, 13, 13, 13, 13, 13, 13, 
  13, 13, 13, 13, 12, 12, 12, 12, 12, 12, 12, 
  12, 12, 12, 12, 11, 11, 11, 11, 11, 11, 11, 
  11, 11, 11, 11, 10, 10, 10, 10, 10, 10, 10, 
  10, 10, 10, 10, 10, 9, 9, 9, 9, 9, 9, 9, 
  9, 9, 9, 9, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 
  8, 8, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 5, 5, 5, 
  5, 5, 5, 5, 5, 5, 5, 5, 5, 4, 4, 4, 4, 4, 
  4, 4, 4, 4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
  2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 
  -1, -1, -1, -1, -1, -1, -1, -1, -1, -2, -2, 
  -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -3, 
  -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, 
  -4, -4, -4, -4, -4, -4, -4, -4, -4, -4, -4, 
  -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, 
  -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6, 
  -6, -7, -7, -7, -7, -7, -7, -7, -7, -7, -7, 
  -7, -8, -8, -8, -8, -8, -8, -8, -8, -8, -8, 
  -8, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 
  -9, -10, -10, -10, -10, -10, -10, -10, -10, 
  -10, -10, -10, -11, -11, -11, -11, -11, -11, 
  -11, -11, -11, -11, -12, -12, -12, -12, -12, 
  -12, -12, -12, -12, -12, -13, -13, -13, -13, 
  -13, -13, -13, -13, -13, -13, -13, -14, -14, 
  -14, -14, -14, -14, -14, -14, -14, -14, -15, 
  -15, -15, -15, -15, -15, -15, -15, -15, -15, 
  -16, -16, -16, -16, -16, -16, -16, -16, -16, 
  -17, -17, -17, -17, -17, -17, -17, -17, -17, 
  -17, -18, -18, -18, -18, -18, -18, -18, -18, 
  -18, -19, -19, -19, -19, -19, -19, -19, -19, 
  -19, -20, -20, -20, -20, -20, -20, -20, -20, 
  -21, -21, -21, -21, -21, -21, -21, -21, -21, 
  -22, -22, -22, -22, -22, -22, -22, -22, -23, 
  -23, -23, -23, -23, -23, -23, -23, -24, -24, 
  -24, -24, -24, -24, -24, -24, -25, -25, -25, 
  -25, -25, -25, -25, -26, -26, -26, -26, -26, 
  -26, -26, -27, -27, -27, -27, -27, -27, -27, 
  -28, -28, -28, -28, -28, -28, -28, -29, -29, 
  -29, -29, -29, -29, -29, -30, -30, -30, -30, 
  -30, -30, -31, -31, -31, -31, -31, -31, -32, 
  -32, -32, -32, -32, -32, -33, -33, -33, -33, 
  -33, -34, -34, -34, -34, -34, -34, -35, -35, 
  -35, -35, -35, -36, -36, -36, -36, -36, -37, 
  -37, -37, -37, -38, -38, -38, -38, -38, -39, 
  -39, -39, -39, -40, -40, -40, -40, -41, -41, 
  -41, -41, -42, -42, -42, -43, -43, -43, -43, 
  -44, -44, -44, -45, -45, -45, -46, -46, -46, 
  -47, -47, -47, -48, -48, -48, -49, -49, -50, 
  -50, -50, -51, -51, -52, -52, -53, -53, -54, 
  -54, -55, -55, -56, -57, -57, -58, -59, -59, 
  -60, -61, -62, -63, -64, -65, -66, -67, -69, 
  -70, -72, -74, -77, -80, -84, -88
};
 

void calculateTemps(void) {
		int t;
	
	//ADC 468 = 18c
	//ADC 
		IAT=IAT_table[adc_raw[11] & 0x3FF];
		/* PATCH: +8 went straight into a signed char. The table saturates at
		   127, so 127+8 wrapped to -121: a hot or shorted coolant sensor read
		   as extremely cold - full enrichment, and the fan switched OFF. */
		t = (int)CLT_table[adc_raw[10] & 0x3FF] + 8; //add 8 because it was reading low for some reason...
		if (t > 127) t = 127;
		CLT = (char)t;
		
}
#define WINDOW_SIZE 16  // Power of 2 for efficient division
unsigned int buffer[WINDOW_SIZE];
unsigned int index = 0;
unsigned long sum = 0;  // 32-bit to prevent overflow

unsigned int updateFilter(unsigned int new_value) {
    sum -= buffer[index];
    buffer[index] = new_value;
    sum += new_value;
    index = (index + 1) & (WINDOW_SIZE - 1);  // Efficient modulo for power of 2
    return sum >> 4;  // Divide by 16
}	


unsigned int buffer2[WINDOW_SIZE];
unsigned int index2 = 0;
unsigned long sum2 = 0;  // 32-bit to prevent overflow

unsigned int updateFilterWideband(unsigned int new_value) {
    sum2 -= buffer2[index2];
    buffer2[index2] = new_value;
    sum2 += new_value;
    index2 = (index2 + 1) & (WINDOW_SIZE - 1);  // Efficient modulo for power of 2
    return sum2 >> 4;  // Divide by 16
}	

unsigned int bufferVbat[WINDOW_SIZE];
unsigned int indexVbat = 0;
unsigned long sumVbat = 0;  // 32-bit to prevent overflow
unsigned int updateFilterVbat(unsigned int new_value) {
    sumVbat -= bufferVbat[indexVbat];
    bufferVbat[indexVbat] = new_value;
    sumVbat += new_value;
    indexVbat = (indexVbat + 1) & (WINDOW_SIZE - 1);  // Efficient modulo for power of 2
    return sumVbat >> 4;  // Divide by 16
}	

void calculateVbatt(void){
	 voltage = adc_raw[5]; // Use the ADC 
		voltage=updateFilterVbat(voltage);
}
void calculateWideband(void) {
    unsigned char i;
    unsigned int afrLow, afrHigh;
    unsigned int adcLow, adcHigh;
    unsigned int afrInterpolated;
    unsigned int adcValue = adc_raw[7]; // 10-bit ADC value (0-1023)

    // Optional: Apply moving average filter if desired (uncomment to use)
     adcValue = updateFilterWideband(adc_raw[7]);

    // Handle boundary conditions
    if (adcValue <= WidebandADCTable[0]) {
        Wideband = (unsigned char)WidebandAFRTable[0];
        return;
    }
    if (adcValue >= WidebandADCTable[WidebandTableSize - 1]) {
        Wideband = (unsigned char)WidebandAFRTable[WidebandTableSize - 1];
        return;
    }

    // Find the bounding indices for ADC value
    for (i = 0; i < WidebandTableSize - 1; i++) {
        if ((adcValue >= WidebandADCTable[i] && adcValue <= WidebandADCTable[i + 1]) ||
            (adcValue <= WidebandADCTable[i] && adcValue >= WidebandADCTable[i + 1])) {
            break;
        }
    }

    // Get the bounding AFR and ADC values
    afrLow = WidebandAFRTable[i];
    afrHigh = WidebandAFRTable[i + 1];
    adcLow = WidebandADCTable[i];
    adcHigh = WidebandADCTable[i + 1];

    // Perform linear interpolation
    if (adcHigh != adcLow) {
        long afrDiff = (long)afrHigh - afrLow;
        long adcDiff = (long)adcValue - adcLow;
        long adcRange = (long)adcHigh - adcLow;
        afrInterpolated = afrLow + (unsigned int)((afrDiff * adcDiff) / adcRange);
    } else {
        afrInterpolated = afrLow;
    }

    Wideband = (unsigned char)afrInterpolated;
}

void calculateTPS(void){


	unsigned int raw_value = adc_raw[8];
    unsigned long scaled_value;

	if (TPSlearnTimer>0){
		if (raw_value >= TPSmax)TPSmax=raw_value;
		if (raw_value <= TPSmin)TPSmin=raw_value;
	}
	
    // Ensure raw_value is within bounds
    if (raw_value < TPSmin) raw_value = TPSmin;
    if (raw_value > TPSmax) raw_value = TPSmax;

    if (TPSmax <= TPSmin) { TPS = 0; return; }   /* PATCH: divide by zero on blank EEPROM / first learn sample */
    // Scale the value from TPSmin-TPSmax range to 0-255 range
    scaled_value = (unsigned long)(raw_value - TPSmin) * 255;
    scaled_value /= (TPSmax - TPSmin);

    TPS= (unsigned char)scaled_value;
	
}



const unsigned char MAPtableSize = sizeof(MAPkPaTable) / sizeof(MAPkPaTable[0]);
// Function to perform 2D lookup with interpolation
void calculateMAP(char sensorBars) {
    unsigned char i;
    unsigned int kPaLow, kPaHigh;
    unsigned int adcLow, adcHigh;
    unsigned int kPaInterpolated;
    unsigned int adcValue = adc_raw[0];
    const unsigned int *tableInUse;
    
	
		adcValue=updateFilter(adc_raw[0]);
	
	
	
    if (sensorBars == 1)      tableInUse = MAPkPaTable;
    else if (sensorBars == 2) tableInUse = MAPkPaTable1_15Bar;
    else if (sensorBars == 3) tableInUse = MAPkPaTable2Bar;
    else if (sensorBars == 4) tableInUse = MAPkPaTable2_5Bar;
    else if (sensorBars == 5) tableInUse = MAPkPaTable2_7Bar;
    else if (sensorBars == 6) tableInUse = MAPkPaTable3Bar;
    else return;  // Invalid sensorBars value
    
    if (adcValue <= MAPadcTable[0]) {
        KPA = tableInUse[0];
        return;
    }
    if (adcValue >= MAPadcTable[MAPtableSize - 1]) {
        KPA = tableInUse[MAPtableSize - 1];
        return;
    }
    
    for (i = 0; i < MAPtableSize - 1; i++) {
        if ((adcValue >= MAPadcTable[i] && adcValue <= MAPadcTable[i + 1]) ||
            (adcValue <= MAPadcTable[i] && adcValue >= MAPadcTable[i + 1])) {
            break;
        }
    }
    
    kPaLow = tableInUse[i];
    kPaHigh = tableInUse[i + 1];
    adcLow = MAPadcTable[i];
    adcHigh = MAPadcTable[i + 1];
    
    if (adcHigh != adcLow) {
        long kPaDiff = (long)kPaHigh - kPaLow;
        long adcDiff = (long)adcValue - adcLow;
        long adcRange = (long)adcHigh - adcLow;
        kPaInterpolated = kPaLow + (unsigned int)((kPaDiff * adcDiff) / adcRange);
    } else {
        kPaInterpolated = kPaLow;
    }
    
    KPA = kPaInterpolated;
}



unsigned char interpolateBoostDuty() {
    unsigned char x1, x2;
    unsigned char value1, value2;
    unsigned long interpolatedValue;
    long rpm_diff, rpm_range;
    
    // Find the bounding indices for RPM
    for (x1 = 0; x1 < 15; x1++) {  // 15 because BoostVsRPM has 16 elements (0-15)
        if ((RPM >= rpmScale[x1] && RPM <= rpmScale[x1 + 1]) ||
            (RPM <= rpmScale[x1] && RPM >= rpmScale[x1 + 1])) {
            x2 = x1 + 1;
            break;
        }
    }
    
    // If RPM is out of range, use the first or last value
    if ((rpmScale[0] < rpmScale[15] && RPM < rpmScale[0]) ||
        (rpmScale[0] > rpmScale[15] && RPM > rpmScale[0])) {
        return BoostVsRPM[0];
    } else if ((rpmScale[0] < rpmScale[15] && RPM > rpmScale[15]) ||
               (rpmScale[0] > rpmScale[15] && RPM < rpmScale[15])) {
        return BoostVsRPM[15];
    }
    
    // Get the values at the bounding indices
    value1 = BoostVsRPM[x1];
    value2 = BoostVsRPM[x2];
    
    // Perform linear interpolation
    rpm_diff = (long)RPM - rpmScale[x1];
    rpm_range = (long)rpmScale[x2] - rpmScale[x1];
    
    if (rpm_range != 0) {
        interpolatedValue = (unsigned long)value1 * (rpm_range - rpm_diff);
        interpolatedValue += (unsigned long)value2 * rpm_diff;
        interpolatedValue /= (rpm_range < 0) ? -rpm_range : rpm_range;
    } else {
        interpolatedValue = value1;
    }
    
    return (unsigned char)interpolatedValue;
}
