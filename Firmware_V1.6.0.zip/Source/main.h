#ifndef __MAIN_H__
#define __MAIN_H__

#define StartOfMapArea_ROM 0x70000
#define StartOfMapArea_RAM 0x384000
#define ignitionMap_loc 0x384200


/*
VE table at SRAM Base
VE (Boost) at SRAM Base + 0x600
Ign table at SRAM Base + 0x200
Ign (Boost) at SRAM BAse + 0xA00
AFR table at SRAM Base + 0x400
AFR (Boost) at SRAM Base + 0x600

RPM Scalar table at SRAM Base + 0xF00 [16 values that all tables use for RPM interpolation] 16bit
KPA Scalar table at SRAM Base + 0xF20 [16 values that all tables use for KPA interpolation] 16bit
KPA (Boost) Scalar table at SRAM Base + 0xF40 [16 values that Boost tables use for KPA interpolation] 16bit
Dwell table at SRAM Base + 0xF60 16bit, 8 interpolation points
InjDeadTime table at SRAM Base + 0xF70, 16bit, 8 interpolation points

Rev Limit at SRAM Base + 0xFF0 16bit value








*/




extern char WDTmodeListen; 
extern unsigned int TDCoffset; 
extern volatile unsigned char EEPROMbuffer[32];
extern unsigned int ReferenceTiming;
extern unsigned int RequestedTiming;
extern unsigned char validPacketReceived; //when =1, process the packet
extern unsigned int RPM;
extern unsigned int KPA;
extern unsigned char VE;
extern volatile unsigned char *STFC;
extern volatile unsigned char *STFC_Boost;
extern volatile unsigned char *ExtSettings;          /* v1.2.0: see memloc.c */
#define EXT_MARK_HI            0xB7
#define EXT_MARK_LO            0x44
#define EXT_OK()               (ExtSettings[0] == EXT_MARK_HI && ExtSettings[1] == EXT_MARK_LO)
/* v1.2.0: measured wideband delay = base + per1000 x 1000/rpm, 10 ms units.
   Stored for the tuner (accel enrichment analysis lines lean spikes up with the
   throttle moves that caused them); the firmware itself doesn't use it. */
#define EXT_WB_BASE            0x02
#define EXT_WB_PER1000         0x03
/* v1.3.0: accel enrichment table (extended settings) */
#define EXT_AE_MODE            0x04   /* 1 = table; anything else = the old formula */
#define EXT_AE_TAU             0x05   /* decay time constant, 10 ms units           */
#define EXT_AE_PCT             0x08   /* 8 x extra fuel, % of the fuel pulse         */
#define EXT_AE_BP              0x10   /* 8 x throttle rate, TPS counts per 10 ms    */
#define EXT_AE_RPM             0x18   /* 4 x rpm factor, % (1000/2000/4000/6000)    */
#define EXT_AE_CLT             0x1C   /* 4 x coolant factor, % (-10/20/50/80 C)     */
#define AE_TAU_DEF             30     /* 300 ms                                     */
/* v1.4.0: charge temperature. The air the fuel equation corrects for sits
   between intake-air and coolant temperature: close to coolant when it
   lingers in a hot port (low airflow), close to intake air when it rushes
   through. Blend % toward coolant, by airflow index = rpm x kPa / 1000. */
#define EXT_CT_MODE            0x20   /* 1 = blend; anything else = intake air only */
#define EXT_CT_BLEND           0x21   /* 6 x %, toward coolant                     */
#define EXT_CT_BP              0x28   /* 6 x airflow index / 4, must rise          */
signed int chargeTemp(void);
/* v1.6.0: small-pulse injector correction. Below ~2 ms an injector's needle
   never fully opens (or bounces), so the fuel isn't flow x (pulse - dead time).
   A signed time adjustment by commanded pulse puts it back on the line. */
#define EXT_SP_MODE            0x40   /* 1 = apply the correction               */
#define EXT_SP_BP              0x41   /* 8 x commanded pulse, 0.1 ms, must rise  */
#define EXT_SP_CORR            0x49   /* 8 x signed adjustment, 4 us units       */
extern unsigned char ToolNoSP;        /* CMD 0x20 bit4: measure the raw injector */
/* v1.5.0: learner confidence (see memloc.c) */
extern volatile unsigned char *LearnConf, *LearnConfBoost;
#define EXT_CONF_MODE          0x30   /* 1 = scale learning by confidence          */
#define CONF_K                 32     /* step x K/(K+conf): 32 conf = half speed   */
#define CONF_MIN_W             4      /* a cell needs 4/16 of the site's weight    */
#define CONF_BIG_ERR           (3 * IDLECL_DEADBAND)   /* beyond this, confidence drops... */
#define CONF_BIG_RUN           3      /* ...once it has lasted 3 samples (0.3 s) */
/* v1.3.0: accel event recorder, read by CMD 0x24 */
#define AE_EVT_MIN             2      /* counts per 10 ms (~80 %/s) starts an event  */
#define AE_EVT_WINDOW          100    /* 1 s watched from the start of each stab    */
#define AE_EVT_QUIET           5      /* 50 ms still, then a new opening is a new stab */
#define AE_EVT_N               12
#define AE_EVT_SIZE            17
extern unsigned char aeEvt[AE_EVT_N][AE_EVT_SIZE];
extern unsigned char aeEvtCount, aeEvtLost;
/* v1.2.0: wideband delay test - CMD 0x23 */
#define DT_STEP_PCT            110    /* +10% fuel for the step          */
#define DT_BASELINE_TICKS      20     /* 200 ms average before the step  */
#define DT_TIMEOUT_TICKS       300    /* 3 s                             */
extern volatile unsigned char DelayTestState;   /* 0 idle 1 baseline 2 stepping 3 done 4 timed out/aborted */
extern volatile unsigned int  DelayTestTicks;
extern volatile unsigned char DelayTestBase, DelayTestFuelStep;
extern unsigned int dtSum;
extern unsigned int TotalTiming;
extern unsigned char flags;
extern unsigned char SparkCut;
extern unsigned char FuelCut;
extern unsigned int RevLimitValue;
extern unsigned int totalInjectorPW;
extern unsigned int dwellUs;
extern unsigned int InjectorDeadTime;
extern unsigned int BaseFuel;
extern unsigned int InjFlow;
extern unsigned char MAPSensorType;

extern void ssc_init();
extern void init_adc();
extern void ASIC_init();
extern void Injector1_fire(unsigned int pulsewidth);
extern void Injector2_fire(unsigned int pulsewidth);
extern void Injector3_fire(unsigned int pulsewidth);
extern void Injector4_fire(unsigned int pulsewidth);
extern void calculateMAP(char sensorBars);
extern void copy_FH_to_memory();
extern void jump_to_FH();
extern void serialInit();
extern void processPacket();
extern void timer_init();
extern void eeprom_read(unsigned int address, unsigned char length);
extern void eeprom_write(unsigned int address, unsigned char length);
extern unsigned char interpolateTable(unsigned char *table,unsigned int rpm, unsigned int kpa,unsigned char boost);
extern unsigned int interpolate_dwell();
extern unsigned int interpolate_IDT();
extern unsigned int calculateFuel();
extern void calculateVbatt();
extern unsigned int calculateCrankPw();
extern unsigned char interpolate_AFR();
extern unsigned char interpolate_IATRetard();
extern 	unsigned char interpolate_IACvsTemp();
extern void IAC_Move(char Direction,char Active);
extern void readEEPROMsettings();

/*==========================================================================
  PATCH CONSTANTS AND DECLARATIONS
  Derived from ToothCount / DegreesPerTooth / DegreePrecision in reg167.h,
  which stay exactly as they were (36-1).
==========================================================================*/
#define TICKS_PER_TOOTH   (DegreesPerTooth * DegreePrecision)  /* 20 on 36-1  */
#define HALFDEG_PER_REV   (360 * DegreePrecision)              /* 720         */
#define FINE_TIMER_KHZ    1250UL   /* T1, T3, T4 at fCPU/16 = 1.25 MHz        */
#define MAX_DWELL_HD      (180 * DegreePrecision)
#define MAX_DWELL_US      10000    /* absolute ceiling on requested dwell. Your
                                      tables top out at 7500us (6000 + 1500), so
                                      this never engages in normal operation.  */
#define COIL_ON_TIMEOUT   3        /* 10ms ticks a coil may stay charging     */
#define SSC_TIMEOUT       20000
#define SERIAL_TIMEOUT    20000

extern void calculateSparkTiming(void);
extern void latchSparkSchedule(void);     /* tooth ISR only                  */
extern void sparkAllOff(void);
extern void injectorsAllOff(void);
extern unsigned char ssc_xfer(unsigned char data);
extern unsigned char TPSsavePending;
extern unsigned char SyncState;         /* 0 = waiting for first gap, 1 = synced, 2 = re-verifying */

/* ---- tuning constants for the second patch set (all chosen from your logs/tune) ---- */
#define ACCEL_DECAY_PER_10MS   7      /* your logs: ~1.5ms per loop pass while logging, and the old code
                                         decayed 1 count per pass, so this keeps the feel you tuned against */
#define ACCEL_ENRICH_MAX       12500  /* 10ms sanity ceiling; your fastest logged snap asks for 1.1ms */
#define MAX_INJ_PW_TOTAL       60000  /* 48ms; keeps fuel+deadtime+accel from wrapping 16 bits */
#define MIN_INJ_PW             20     /* 16us: shorter can miss its compare and hold an injector open 52ms */
#define MIN_REQ_AFRx10         30     /* your tune legitimately reaches 4.0 cold; this only catches wrap/zero */
#define MAX_REQ_AFRx10         250
#define FUEL_TEMP_REF_C        30     /* IAT your VE table was tuned at: logs show 27-34C boosted/cruise */
#define BOOST_TABLE_ON_KPA     102
#define BOOST_TABLE_OFF_KPA    98
#define IDLE_RESET_ABOVE_RPM   500    /* trim resets while rpm is still falling from above target+500 */
#define IDLE_FALLING_RPM       100    /* v0.9.4: rpm drop per second that counts as "still coming down
                                         from a blip". The trim itself only moves idle by 10-30 rpm/s,
                                         so it can't mistake its own work for a decay.               */
#define IDLE_STEP_SPLIT        150    /* v0.9.4: one extra step per 150 rpm of error                 */
#define IDLE_STEP_MAX          4      /* ...up to this many steps per second                         */
#define IDLE_DEADBAND_RPM      50
#define IDLE_TRIM_MIN          0      /* IACidlecontrol range; 50 = no trim */
#define IDLE_TRIM_MAX          100
#define STARTUP_IAC_DECAY_TICKS 5     /* 10ms ticks per step: your 30 step bump fades over 1.5s */
/* v0.9.5 IAC: the valve is driven by relative steps, not by chasing an absolute
   count, and no faster than the motor can actually follow. */
/* v0.9.8: paced off T7 (free running, 0.8us per count) instead of the 10ms tick,
   and checked every main-loop pass. Lower these to go faster. */
#define IAC_STEP_US            2500   /* default time between steps: 400 steps/s              */
/* v0.9.9: the step time is a setting now - EEPROM 0x0F, "IAC Step Time" in the
   XDF, in 0.1 ms. 0 or anything outside 0.3-20 ms means IAC_STEP_US. The tuner's
   IAC speed test measures it and writes it. Homing uses it too. */
#define IAC_STEP_MIN_US        300
#define IAC_STEP_MAX_US        20000
extern unsigned int IACstepUs;
/* v1.0.0: idle air added when the cooling fan comes on - EEPROM 0x07, "IAC Fan
   Kick" in the XDF, in steps. Anything over IAC_FAN_KICK_MAX counts as unset
   (0), so a blank 0xFF EEPROM can't open the valve wide. The relay waits
   FAN_LEAD_TICKS after the air goes in, so the load arrives after the air. */
#define IAC_FAN_KICK_MAX       60
#define FAN_LEAD_TICKS         30     /* 10ms ticks: 300 ms */
extern unsigned char IACfanSteps;
extern int ToolIACmove;               /* v0.9.9: test steps still to make (+ open, - close) */
extern unsigned int ToolIACperiodUs;  /* ...and the time between them                       */
#define IAC_SETTLE_US          20000  /* full current this long after the last step, then hold */
#define IAC_US_TO_T7(us)       ((unsigned int)(((unsigned long)(us) * 5UL) / 4UL))   /* 1.25 counts/us */
#define IAC_BLIP_TPS           12     /* ~5% throttle: past this it is not idle any more   */
#define IAC_BLIP_OPEN_STEPS    6      /* air put back in on the way off the throttle       */
/* v0.9.6: idle MBT sweep, driven by the tuner over serial (CMD 0x20). All of it
   lives in RAM, is zero at power-up, and lapses on its own if the tool stops
   refreshing it - a crashed laptop can't leave the timing locked. */
#define TOOL_LEASE_TICKS       500    /* 10ms ticks: 5 s without a refresh and it all lets go */
#define TOOL_SPARK_MAX_RPM     3000   /* the timing override is idle-only, whatever the tool asks */
#define TOOL_SPARK_MAX_HALFDEG 100    /* 50 deg */
extern unsigned char ToolFreezeIAC;
extern unsigned char ToolAltInject;   /* v0.9.7: fire every other revolution with the fuel doubled */
extern unsigned char ToolSparkOn;
extern unsigned int  ToolSpark;
extern volatile unsigned int ToolLease;

/* ---- v0.7: both features are OFF unless ticked in TunerPro (EEPROM 0x2002) ---- */
#define FLAG_IDLE_CL           0x04   /* "Enable STFC" flag = idle closed-loop fuel trim only (v0.9.1) */
#define FLAG_HW_CAPTURE        0x20   /* hardware tooth timestamps + spark latency correction */
#define FLAG_STFT_LEARN        0x40   /* v0.9.1: off-idle STFT table learning, its own checkbox */
#define FLAG_VE_LEARN          0x80   /* v0.9.2: DYNO ONLY. Learns straight into the VE / VE (Boost)
                                         tables in RAM. Overrides FLAG_STFT_LEARN: while it is set the
                                         STFT tables are neither learned nor applied (0% trim), so the
                                         VE table ends up correct on its own. No +/-15% cap - cells are
                                         limited only by the 8-bit table (VE_LEARN_MIN..255).        */
#define FLAG_ALPHA_N           0x10   /* "Alpha-N" checkbox (same bit as UseAlphaN in main.c)          */
#define VE_LEARN_MIN           1      /* never learn a cell down to 0 = no fuel at all                  */
#define IAC_TUNE_TPS_MAX       2      /* v0.9.2: closed-loop idle air only trims at TPS <= 2 counts
                                         (0.78%). 3 counts = 1.2%, the first reading at or above 1%.
                                         Between this and the 12-count reset the trim is frozen.       */

#define IDLECL_TPS_MAX         2      /* TPS counts, ~0.8%: "closed throttle" with noise margin */
#define IDLECL_RPM_MIN         400
#define IDLECL_RPM_MAX         1200
#define IDLECL_RESET_TPS       51     /* 20%: above this the learned trim is discarded */
#define IDLECL_WARMUP_TICKS    3000   /* 30s of running before learning (wideband warm-up) */
#define IDLECL_SETTLE_STEPS    20     /* 2s steady in the idle region before learning */
#define IDLECL_DEADBAND        2      /* +/-0.2 AFR: no correction inside this */
#define IDLECL_ERR_CLAMP       30     /* errors beyond 3.0 AFR are treated as 3.0 */
#define IDLECL_TRIM_MAX        1500   /* +15.00%  (trim units are 0.01%) */
#define IDLECL_TRIM_MIN        (-1500)/* -15.00% */
#define WB_VALID_MIN           75     /* your wideband table rails are 7.4 and 22.4 AFR;  */
#define WB_VALID_MAX           223    /* sitting on a rail = sensor not ready or faulted */
#define STFC_RAW_ZERO          128    /* XDF: 128 = 0% trim */
#define STFC_RAW_MIN           90     /* about +15% fuel  (lower raw = richer) */
#define STFC_RAW_MAX           166    /* about -15% fuel */
#define STFC_LEARN_TPS_MIN     3      /* off-idle: above closed-throttle noise */
#define STFC_DELTA_TPS_MAX     8      /* skip while the throttle is moving */
#define STFC_SETTLE_STEPS      10     /* 1s steady off-idle before a cell moves */
#define STFC_IDLE_SETTLE_STEPS 20     /* v0.9.4: 2s at idle - it wanders more, and the IAC is moving */
#define STFC_IDLE_SLOW         2      /* v0.9.4: idle steps at half rate; the wideband is further away
                                         from the valve at idle and the plant is slower             */
#define STFC_GAIN              2      /* v0.9.1: change at the operating point per 100ms, in 1/16 raw
                                         counts per 0.1 AFR of error. 2 = ~4.9%/s per 1.0 AFR.
                                         Simulated: no overshoot at 0.3-0.5s wideband delay,
                                         one small crossing at 1.0s. 3 starts to ring.        */
#define TEETH_BEFORE_GAP       2      /* real intervals needed after a stall before a gap is trusted */
#define CAPTURE_STALL_OVF      1      /* capture mode: stall after a full T1 period with no tooth */

extern unsigned char Wideband;
extern unsigned char EEPROMflags;
extern unsigned char CaptureMode;
extern int           IdleFuelTrim;       /* 0.01% units, + = more fuel */
extern unsigned char IdleCLActive;
extern unsigned char IdleCLStatus;
extern unsigned char SparkLatencyMax;    /* worst spark ISR latency since last log frame, 0.8us counts */
extern void selectToothCaptureMode(unsigned char want);
extern void calculateWideband(void);   /* PATCH: was called without a prototype (C140 / L20 warnings) */
extern void updateSTFC(void);          /* v0.9: off-idle STFT table learn */
extern signed char STFTapplied;
extern unsigned char veLearnMode;     /* v0.9.2: 1 = VE learn has the tables (STFT bypassed) */
extern unsigned char stftTipHold;     /* v0.9.1: 10ms ticks left before learning may resume after a real throttle move */

/* v0.9.1: what counts as real throttle movement for the learner.
   Your logs, steady part throttle, rise per 10ms: 1 count x469, 2 x110, 3 x36,
   4+ only a handful, real snaps 29-31. So 1-3 counts is TPS noise. The old gate
   blocked learning on ANY accel enrichment, which that noise re-armed every
   ~50ms, so the 1s settle could never complete. */
#define STFC_TIPIN_DTPS        24     /* DeltaTPS is counts*8 per 10ms: >24 = 4+ counts = real move  */
#define STFC_TIPIN_HOLD        100    /* 1s hold-off after a real move (10ms ticks)                    */
#define STFC_AE_IGNORE         320    /* accel enrichment up to this is noise-sized (0.26ms), ignore it */
#define STFC_TPS_STEADY        3      /* TPS may wander this much between 100ms samples while settling  */        /* v0.9.1: table trim at the operating point, 0.2% per count, logged */
extern unsigned char Coil1State, Coil2State;
extern unsigned char EngineStalled;
extern unsigned int  ShortToothInterval;

#endif
