#define StartOfMapArea_ROM 0x70000
#define StartOfMapArea_RAM 0x384000

#define VE_Table_Size (16*32*1) //16x32 bytes = 512bytes
#define Boost_VE_Table_Size (16*32*1) //16x32 bytes = 512bytes
#define Spark_Table_Size (16*32*1) //16x32 bytes = 512bytes
#define Boost_Spark_Table_Size (16*32*1) //16x32 bytes = 512bytes
#define AFR_Table_Size (16*32*1) //16x32 bytes = 512bytes
#define Boost_AFR_Table_Size (16*32*1) //16x32 bytes = 512bytes


volatile unsigned char *VE_ROM = (unsigned char *)StartOfMapArea_ROM; //last 64kbyte block of Flash

volatile unsigned char *VEMap = (unsigned char *)StartOfMapArea_RAM; //first 512byte table is the VE map -Verified

volatile unsigned char *ignitionMap = (unsigned char *)StartOfMapArea_RAM+0x200; //second 512byte table is the ign map - Verified

/* v1.1.0: 0x100, 0x500, 0x700 and 0x900 held four maps nothing ever used (two "VE learn",
   two AFR logger). Their pointers are gone; the space is free. */
volatile unsigned char *AFRMap = (unsigned char *)StartOfMapArea_RAM+0x400; //first 512byte table is the VE map - Verified

volatile unsigned char *VEMapBoost = (unsigned char *)StartOfMapArea_RAM+0x600; //first 512byte table is the VE map - Verified

volatile unsigned char *AFRMapBoost = (unsigned char *)StartOfMapArea_RAM+0x800; //first 512byte table is the VE map - Verified

volatile unsigned char *ignitionMapBoost = (unsigned char *)StartOfMapArea_RAM+0xA00; //second 512byte table is the ign map	-Verified


volatile unsigned int *DwellKPAMap =  (unsigned char *)StartOfMapArea_RAM+0xE00; // 16byte table is the ign map - Verified

volatile unsigned int *RPMScalar =  (unsigned char *)StartOfMapArea_RAM+0xF00; //second 32byte table is the ign map - Verified

volatile unsigned int *KPAScalar =  (unsigned char *)StartOfMapArea_RAM+0xF20; // 32byte table is the ign map - Verified

volatile unsigned int *KPAScalarBoost =  (unsigned char *)StartOfMapArea_RAM+0xF40; // 32byte table is the ign map - Verified

volatile unsigned char *DwellMap =  (unsigned char *)StartOfMapArea_RAM+0xF60; // 16byte table is the ign map - Verified

volatile unsigned char *InjectorDeadTimeMap =  (unsigned char *)StartOfMapArea_RAM+0xF70; // 16byte table is the ign map - Verified

volatile unsigned char *TempVsAFRMap =  (unsigned char *)StartOfMapArea_RAM+0xF80; // 16 byte table (-20 to 140c in 10c increments - 8bit afr values 147 etc. - Verified

volatile unsigned char *TempVsCrankPWMap =  (unsigned char *)StartOfMapArea_RAM+0xF90; // 32 byte table (-20 to 140c in 10c increments - 16bit fixed injector pw Verified

volatile unsigned char *IATretardMap =  (unsigned char *)StartOfMapArea_RAM+0xFB0; // 16 byte table (-20 to 140c in 10c increments - 8bit signed values - Verified

volatile unsigned char *TempVsIACMap =  (unsigned char *)StartOfMapArea_RAM+0xFC0; // 16 byte table (-20 to 140c in 10c increments - 8bit unsigned values - Verified

volatile unsigned char *BoostVsRPM =  (unsigned char *)StartOfMapArea_RAM+0xFD0; // 16 byte table 8bit duty cycle - Verified


volatile unsigned char *RevLimit =  (unsigned char *)StartOfMapArea_RAM+0xFF0; //2byte value - Verified
volatile unsigned char *BaseFuelmS =  (unsigned char *)StartOfMapArea_RAM+0xFF2; //2byte value - Verified
volatile unsigned char *CrankEnrichDecay =  (unsigned char *)StartOfMapArea_RAM+0xFF4; //1byte value - Verified
volatile  char *FanCutIn =  (unsigned char *)StartOfMapArea_RAM+0xFF5; //1byte value - Verified
volatile  char *FanCutOut =  (unsigned char *)StartOfMapArea_RAM+0xFF6; //1byte value - Verified

volatile  char *MapSensorType =  (unsigned char *)StartOfMapArea_RAM+0xFF7; //1byte value - Verified
volatile char *InjectionOffset1 = (unsigned char *)StartOfMapArea_RAM+0xFF8;
volatile char *InjectionOffset2 = (unsigned char *)StartOfMapArea_RAM+0xFF9;

volatile char *MinTPS4Boost = (unsigned char *)StartOfMapArea_RAM+0xFFA;
volatile unsigned char *TargetIdleRPM = (unsigned char *)StartOfMapArea_RAM+0xFFB;   /* PATCH: XDF defines it unsigned; conflicted with main.c */
volatile unsigned char *BoostSafetyKPA = (unsigned char *)StartOfMapArea_RAM+0xFFC;   /* PATCH: was plain char, which is
   signed in this project (CharAsUnsignedChar=0): any setting of 128 kPa or more read as negative and the
   overboost cut could never fire. Your 200 kPa read as -56. */

volatile unsigned char *AlphaNMAP = (unsigned char *)StartOfMapArea_RAM + 0x1000; //
volatile unsigned char *AlphaNLoadMAP = (unsigned char *)StartOfMapArea_RAM + 0x1100; //

volatile unsigned char *STFC = (unsigned char *)StartOfMapArea_RAM + 0x1200; //
/* v1.2.0: extended settings, in space the calibration never used (0xB00-0xDFF).
   Unused bytes in existing bins hold 0x38, so nothing here is trusted unless the
   block starts with the marker 0xB7 0x44 - otherwise every setting uses its
   default. The tuner writes the marker the first time one of these is set. */
volatile unsigned char *ExtSettings = (unsigned char *)StartOfMapArea_RAM + 0xB00;
/* v1.5.0: learner confidence, one byte per VE/STFT cell, in two of the blocks freed
   in v1.1.0. Only used when Learn Confidence Mode is on (the tuner zeroes both
   grids when it turns it on - existing bins hold 0x38 here). */
volatile unsigned char *LearnConf      = (unsigned char *)StartOfMapArea_RAM + 0x100;
volatile unsigned char *LearnConfBoost = (unsigned char *)StartOfMapArea_RAM + 0x700;
volatile unsigned char *STFC_Boost = (unsigned char *)StartOfMapArea_RAM + 0x1300; //

